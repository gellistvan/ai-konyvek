import numpy as np

def relu(x):
    return np.maximum(x, 0.0)

def build_lemma1(t, deltas, s0, f_a, a=0.0, with_identity=True):
    t = np.asarray(t, dtype=np.float32)
    deltas = np.asarray(deltas, dtype=np.float32)
    k = len(t)
    m = k + 2 if with_identity else k
    if not with_identity and s0 != 0.0:
        raise ValueError("identitás-egységek nélkül csak s0=0 állítható elő")
    W1 = np.zeros((m, 1), dtype=np.float32)
    b1 = np.zeros((m,), dtype=np.float32)
    if with_identity:
        W1[0, 0] = 1.0
        W1[1, 0] = -1.0
        offset = 2
    else:
        offset = 0
    W1[offset:offset + k, 0] = 1.0
    b1[offset:offset + k] = -t
    W2 = np.zeros((1, m), dtype=np.float32)
    if with_identity:
        W2[0, 0] = s0
        W2[0, 1] = -s0
    W2[0, offset:offset + k] = deltas
    b2 = np.array([f_a - s0 * a], dtype=np.float32)
    return W1, b1, W2, b2

def forward(x, W1, b1, W2, b2):
    h = relu(x @ W1.T + b1)
    return h @ W2.T + b2

# F2 g függvénye, 17 ponton ellenőrizve
t = np.array([0.2, 0.6], dtype=np.float32)
deltas = np.array([1.5, -1.5], dtype=np.float32)
s0, f_a, a = 0.0, 0.0, 0.0
W1, b1, W2, b2 = build_lemma1(t, deltas, s0, f_a, a)
x = np.linspace(0, 1, 17, dtype=np.float32).reshape(-1, 1)
g_true = np.where(x < 0.2, 0.0,
          np.where(x < 0.6, 1.5 * (x - 0.2), 0.6))
y = forward(x, W1, b1, W2, b2)
print("max abs hiba:", float(np.max(np.abs(y - g_true))))
assert W1.shape == (4, 1) and W2.shape == (1, 4)
assert float(np.max(np.abs(y - g_true))) < 1e-5
