import numpy as np

def relu(x):
    return np.maximum(x, 0.0)

def mlp_1hidden(x, W1, b1, W2, b2):
    h = relu(x @ W1.T + b1)          # (N,m)
    return h @ W2.T + b2             # (N,1)

def build_interpolating_mlp(f, a=0.0, b=1.0, n_intervals=10, width=12):
    x_nodes = np.linspace(a, b, n_intervals + 1, dtype=np.float32)
    interiors = x_nodes[1:-1]
    y_nodes = f(x_nodes).astype(np.float32)
    h = (b - a) / n_intervals
    slopes = np.diff(y_nodes) / h     # n_intervals meredekség
    s0 = slopes[0]
    deltas = np.diff(slopes)          # ugrás a belső pontokban
    m = width
    W1 = np.zeros((m, 1), dtype=np.float32)
    b1 = np.zeros((m,), dtype=np.float32)
    W1[0, 0] = 1.0                     # ReLU(x)
    W1[1, 0] = -1.0                    # ReLU(-x)
    W1[2:2 + len(interiors), 0] = 1.0
    b1[2:2 + len(interiors)] = -interiors
    W2 = np.zeros((1, m), dtype=np.float32)
    W2[0, 0] = s0
    W2[0, 1] = -s0
    W2[0, 2:2 + len(deltas)] = deltas
    b2 = np.array([f(a) - s0 * a], dtype=np.float32)
    return W1, b1, W2, b2

def mlp_2hidden(x, W1, b1, W2, b2, W3, b3):
    h1 = relu(x @ W1.T + b1)
    h2 = relu(h1 @ W2.T + b2)
    return h2 @ W3.T + b3

def build_random_two_hidden(seed=20261020):
    rng = np.random.default_rng(seed)
    W1 = rng.standard_normal((3, 1), dtype=np.float32) * 0.5
    b1 = rng.standard_normal((3,), dtype=np.float32) * 0.5
    W2 = rng.standard_normal((6, 3), dtype=np.float32) * 0.5
    b2 = rng.standard_normal((6,), dtype=np.float32) * 0.5
    W3 = rng.standard_normal((1, 6), dtype=np.float32) * 0.5
    b3 = rng.standard_normal((1,), dtype=np.float32) * 0.5
    return W1, b1, W2, b2, W3, b3

def main():
    target = lambda x: np.sin(2 * np.pi * x)
    a, b = 0.0, 1.0
    n_intervals = 10
    W1, b1, W2, b2 = build_interpolating_mlp(target, a, b, n_intervals, width=12)
    # A háló paraméterszáma: 12 + 12 + 12 + 1 = 37
    x_test = np.linspace(a, b, 1001, dtype=np.float32).reshape(-1, 1)
    y_true = target(x_test).astype(np.float32)
    y_A = mlp_1hidden(x_test, W1, b1, W2, b2)
    err_A = np.max(np.abs(y_A - y_true))
    # Elméleti garantált szupremumhiba: max|f''| = 4*pi^2, h = 0.1
    h = (b - a) / n_intervals
    bound = (h**2 / 8.0) * (4 * np.pi**2)
    # B kontraszt: 3+6 rejtett, paraméterszám 3+3+18+6+6+1 = 37
    W1b, b1b, W2b, b2b, W3b, b3b = build_random_two_hidden(seed=20261020)
    y_B = mlp_2hidden(x_test, W1b, b1b, W2b, b2b, W3b, b3b)
    err_B = np.max(np.abs(y_B - y_true))
    print(f"A konstrukciós hiba (1001 pontos rácson): {err_A:.6f}")
    print(f"Elméleti garantált szupremumhiba: {bound:.6f}")
    print(f"B véletlen hiba (1001 pontos rácson): {err_B:.6f}")
    assert err_A <= bound
    assert np.isfinite(err_A) and np.isfinite(err_B)
    assert W1.shape == (12, 1) and W2.shape == (1, 12)

if __name__ == "__main__":
    main()
