import numpy as np

def variance_check(G, m, R, seed=20261020):
    N = G.shape[0]
    rng = np.random.default_rng(seed)
    full = G.mean(axis=0)
    sigma2 = ((G - full) ** 2).sum() / N
    draws = np.empty((R, full.shape[0]))
    for r in range(R):
        idx = rng.choice(N, size=m, replace=False)
        draws[r] = G[idx].mean(axis=0)
    emp = ((draws - draws.mean(axis=0)) ** 2).sum() / (R - 1)
    theo = (N - m) / (m * (N - 1)) * sigma2
    return emp, theo

G = np.array([[2.0], [5.0], [-1.0]])
emp, theo = variance_check(G, m=2, R=100_000)
print(emp, theo)
assert abs(emp - theo) < 0.02 * theo
