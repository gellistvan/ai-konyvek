"""n023 labor: batchgradiens varianciája.

Futtatás: python n023_sgd_variance.py
"""
import numpy as np

rng = np.random.default_rng(20261020)
N, d, R = 12, 4, 20_000

# Szintetikus minta-gradiensek egy rögzített theta pontban.
# A labor csak a batchválasztás eloszlását méri.
G = rng.normal(size=(N, d)).astype(np.float64)
full = G.mean(axis=0)                      # teljes gradiens, (d,)
sigma2 = ((G - full) ** 2).sum() / N       # populációs variancianyom

def sample_trace(m):
    # m = N esetén a batchátlag determinisztikus, a variancia pontosan 0;
    # ezt a határesetet nem mérjük, hanem elméleti értékként jelöljük.
    assert 1 <= m < N
    draws = np.empty((R, d), dtype=np.float64)
    for r in range(R):
        idx = rng.choice(N, size=m, replace=False)
        draws[r] = G[idx].mean(axis=0)
    emp_mean = draws.mean(axis=0)
    emp = ((draws - emp_mean) ** 2).sum() / (R - 1)
    theo = (N - m) / (m * (N - 1)) * sigma2
    if theo > 0:
        rel = abs(emp - theo) / theo
    else:
        rel = 0.0 if emp == 0.0 else float("inf")
    return emp, theo, rel

for m in (1, 2, 4, 6):
    emp, theo, rel = sample_trace(m)
    print(f"m={m:2d}  emp={emp:.6f}  theo={theo:.6f}  rel={rel:.4f}")
    # R=20000-nél a relatív szórás Gauss-közelítéssel ~1%,
    # a 5%-os tűrés nagyjából öt szórás.
    assert rel < 0.05, "mintavételi vagy képlethiba jelölt értéknél"

print("m=12  elméleti határeset: VÁRT ÉRTÉK (levezetésből, nem mért): 0")
