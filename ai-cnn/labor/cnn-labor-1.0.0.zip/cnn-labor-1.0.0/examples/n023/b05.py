idx = torch.randperm(N)[:m]
g_batch = G[idx].mean(dim=0)
