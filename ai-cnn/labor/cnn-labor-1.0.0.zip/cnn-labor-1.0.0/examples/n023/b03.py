import torch

N, m = 3, 2
G = torch.tensor([[2.0], [5.0], [-1.0]])
idx = torch.randint(0, N, (m,))
g_batch = G[idx].mean(dim=0)
