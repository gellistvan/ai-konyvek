def central_diff3(i, eps=1e-6):
    up = u.copy(); up[i] += eps
    um = u.copy(); um[i] -= eps
    return (forward3(up, x1, x2, x3)[0] - forward3(um, x1, x2, x3)[0]) / (2.0*eps)

num3 = np.array([central_diff3(0), central_diff3(1)])
ana3 = backward3(forward3(u, x1, x2, x3)[1])
print("num3 =", num3)         # [5. -4.]
print("ana3 =", ana3)         # [5. -4.]
assert np.allclose(num3, ana3, atol=1e-7)
assert np.allclose(ana3, [5.0, -4.0], atol=1e-12)
