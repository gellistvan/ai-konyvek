# lab/n037_graph.py — munkakönyvtár: lab/
import numpy as np

u  = np.array([1.0, -1.0], dtype=np.float64)
x1 = np.array([1.0,  2.0], dtype=np.float64)
x2 = np.array([3.0,  1.0], dtype=np.float64)

def forward(u, x1, x2):
    """A 10.1.5 gráf forward-ja; visszaadja L-et és a mentett értékeket."""
    a = u @ x1
    b = u @ x2
    L = 0.5 * (a * a + b * b)
    return L, (a, b, x1, x2)

def backward_both(cache):
    """Helyes backward: mindkét ág hozzájárulását összeadjuk."""
    a, b, x1, x2 = cache
    return a * x1 + b * x2                     # dL/du

def backward_missing_second(cache):
    """Hibás kód: a második ág hozzájárulását elhagyjuk."""
    a, b, x1, x2 = cache
    return a * x1                              # hiányzik: b*x2

def central_diff(f, u, i, eps=1e-6):
    """Középső differencia az i-edik koordinátában (lépés: eps)."""
    up = u.copy(); up[i] += eps
    um = u.copy(); um[i] -= eps
    return (f(up)[0] - f(um)[0]) / (2.0 * eps)

L, cache = forward(u, x1, x2)
# A lambda rögzíti x1, x2-t, így a central_diff egy u-tól függő skalár függvényt kap.
# Az f(...)[0] indexelés azért kell, mert a forward (L, cache) párt ad vissza, nem csak L-t.
num   = np.array([central_diff(lambda v: forward(v, x1, x2), u, i)
                  for i in range(2)])
ana   = backward_both(cache)
wrong = backward_missing_second(cache)

def rel_err(a, b):
    denom = max(np.abs(a), np.abs(b), 1e-12)
    return np.abs(a - b) / denom

print("L      =", L)
print("numeric =", num)
print("analytic=", ana)
print("rel_err =", [float(rel_err(n, a)) for n, a in zip(num, ana)])
print("missing =", wrong)
print("err_miss=", wrong - ana)
assert np.isclose(L, 2.5, atol=1e-12)
assert np.allclose(num, ana, atol=1e-7)
assert np.allclose(wrong - ana, [-6.0, -2.0], atol=1e-12)
