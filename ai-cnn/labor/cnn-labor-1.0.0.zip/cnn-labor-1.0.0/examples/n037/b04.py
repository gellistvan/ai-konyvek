x3 = np.array([0.0, 1.0], dtype=np.float64)

def forward3(u, x1, x2, x3):
    a = u @ x1
    b = u @ x2
    c = 2.0 * (u @ x3)
    L = 0.5 * (a*a + b*b + c*c)
    return L, (a, b, c, x1, x2, x3)

def backward3(cache):
    a, b, c, x1, x2, x3 = cache
    # a c = 2*u@x3 ág Jacobi-mátrixa 2*x3^T, ezért a lokális VJP 2*c*x3
    return a*x1 + b*x2 + (2.0*c)*x3
