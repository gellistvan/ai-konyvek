import torch

w = torch.tensor(3.0, requires_grad=True)
L = 0.5 * w**2
L.backward()
print(w.item(), w.grad.item())   # 3.0 3.0

with torch.no_grad():
    w -= 0.1 * w.grad
print(w.item())                  # 2.700000047683716
