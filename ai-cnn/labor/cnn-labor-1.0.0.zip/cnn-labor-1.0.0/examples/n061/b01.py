# workdir: lab/n061
import numpy as np

def corr_valid(x, k):
    """Valid cross-correlation, N=1, C=1. x:(H,W), k:(kh,kw)."""
    H, W = x.shape
    kh, kw = k.shape
    out = np.zeros((H - kh + 1, W - kw + 1), dtype=np.float64)
    for i in range(out.shape[0]):
        for j in range(out.shape[1]):
            out[i, j] = np.sum(x[i:i+kh, j:j+kw] * k)
    return out

def corr_valid_stride(x, k, s):
    H, W = x.shape
    kh, kw = k.shape
    ho = (H - kh) // s + 1
    wo = (W - kw) // s + 1
    out = np.zeros((ho, wo), dtype=np.float64)
    for i in range(ho):
        for j in range(wo):
            out[i, j] = np.sum(x[i*s:i*s+kh, j*s:j*s+kw] * k)
    return out

def shift_zero(x, tau):
    """Eltolás; a felszabaduló sáv nullával töltött."""
    th, tw = tau
    y = np.zeros_like(x)
    H, W = x.shape
    y[th:, tw:] = x[:H-th, :W-tw]
    return y

def shift_crop(x, tau):
    """Eltolás a (2) definíció szerint; a kilógó részt eldobjuk, a kép mérete csökken."""
    th, tw = tau
    # a tartalom jobbra/lefelé tolódik, ezért az alsó és a jobb oldali sáv esik ki
    return x[:x.shape[0]-th, :x.shape[1]-tw]

def shift_circular(x, tau):
    """Körkörös eltolás (np.roll)."""
    th, tw = tau
    return np.roll(x, (th, tw), axis=(0, 1))

np.random.seed(20261020)
x = np.random.rand(8, 8).astype(np.float64)
k = np.array([[1.0, 2.0, 1.0],
              [2.0, 4.0, 2.0],
              [1.0, 2.0, 1.0]], dtype=np.float64)  # Gauss-szerű 3x3 kernel

tau = (1, 1)

# 1) zero-fill shift
F_x = corr_valid(x, k)
T_x = shift_zero(x, tau)
F_Tx = corr_valid(T_x, k)
T_Fx = np.zeros_like(F_x)
T_Fx[tau[0]:, tau[1]:] = F_x[:F_x.shape[0]-tau[0], :F_x.shape[1]-tau[1]]
# belső tartomány a tétel szerint: tau_h <= i < F_Tx.shape[0], stb.
diff_zero = np.abs(F_Tx - T_Fx)
print("zero-fill, belső max |diff|:", diff_zero[tau[0]:, tau[1]:].max())
print("zero-fill, teljes max |diff|:", diff_zero.max())
assert diff_zero[tau[0]:, tau[1]:].max() < 1e-12
assert diff_zero.max() > 0.0

# 2) crop shift
C_x = shift_crop(x, tau)  # 7x7: a zero-fill eltolt kép nem nulla sávja
F_Cx = corr_valid(C_x, k)  # 5x5
# A crop ugyanazt a tartalmat tartja meg, mint a zero-fill shift, csak a nullasáv
# nélkül; ezért F_Cx a F_x bal felső 5x5-ös blokkjával egyezik (F_x 6x6).
T_Fx_crop = F_x[:F_x.shape[0]-tau[0], :F_x.shape[1]-tau[1]]
diff_crop = np.abs(F_Cx - T_Fx_crop)
print("crop, közös tartomány max |diff|:", diff_crop.max())
assert diff_crop.max() < 1e-12

# 3) circular shift
C2_x = shift_circular(x, tau)
F_C2x = corr_valid(C2_x, k)
diff_circ = np.abs(F_C2x - T_Fx)
print("circular, belső max |diff|:", diff_circ[tau[0]:, tau[1]:].max())
print("circular, teljes max |diff|:", diff_circ.max())
assert diff_circ[tau[0]:, tau[1]:].max() < 1e-12
assert diff_circ.max() > 0.0

# 4) stride 2
s = 2
F_sx = corr_valid_stride(x, k, s)          # 3x3
# páros eltolás: tau = (2,0) -> kimeneti (1,0) eltolás
T2_x = np.zeros_like(x)
T2_x[2:, :] = x[:6, :]
F_sT2x = corr_valid_stride(T2_x, k, s)      # 3x3
T1_Fsx = np.zeros_like(F_sx)
T1_Fsx[1:, :] = F_sx[:F_sx.shape[0]-1, :]
diff_stride_even = np.abs(F_sT2x - T1_Fsx)
print("stride 2, páros eltolás belső max |diff|:",
      diff_stride_even[1:, :].max())
assert diff_stride_even[1:, :].max() < 1e-12

# nem s-többszörös (páratlan) eltolás: tau=(1,0) — nincs megfelelő kimeneti egész eltolás
T1_x = np.zeros_like(x)
T1_x[1:, :] = x[:7, :]
F_sT1x = corr_valid_stride(T1_x, k, s)
# referencia: F_sx eltolás nélkül; eltérés nem lehet nulla
diff_stride_odd = np.abs(F_sT1x - F_sx)
print("stride 2, páratlan eltolás teljes max |diff|:", diff_stride_odd.max())
assert diff_stride_odd.max() > 0.0
