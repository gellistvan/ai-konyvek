def check_equiv(F, shift, x, k, tau):
    """F: (x,k)->out cross-correlation. Visszaadja a teljes és belső max eltérést."""
    F_x = F(x, k)
    T_x = shift(x, tau)
    F_Tx = F(T_x, k)
    T_Fx = np.zeros_like(F_x)
    th, tw = tau
    T_Fx[th:, tw:] = F_x[:F_x.shape[0]-th, :F_x.shape[1]-tw]
    diff = np.abs(F_Tx - T_Fx)
    full = diff.max()
    interior = diff[th:, tw:].max()
    return full, interior

full, interior = check_equiv(corr_valid, shift_zero, x, k, (1, 1))
assert interior < 1e-12, f"belső eltérés {interior}"
print(f"teljes={full}, belső={interior}")
