# lab/check_preprocessing.py
import numpy as np
from pathlib import Path

BASE = Path(__file__).resolve().parent          # lab/
images = np.load(BASE / "data/images.npy")
assert images.dtype == np.float32
assert images.shape == (360, 1, 24, 24)
assert images.min() >= 0.0 and images.max() <= 1.0
print("Preprocessing-szerződés teljesül: [0,1], float32, NCHW, alak (360,1,24,24)")
