# lab/preprocess_check.py
import numpy as np

x = np.array([0.8, 0.4, 0.6], dtype=np.float32)
mu = np.array([0.485, 0.456, 0.406], dtype=np.float32)
sigma = np.array([0.229, 0.224, 0.225], dtype=np.float32)

x_norm = (x - mu) / sigma
print(x_norm)  # [1.3755..., -0.25, 0.8622...]
