# lab/preprocess_normalize.py
import numpy as np
from pathlib import Path

BASE = Path(__file__).resolve().parent          # lab/
images = np.load(BASE / "data/images.npy")
assert images.dtype == np.float32
assert images.min() >= 0.0 and images.max() <= 1.0
mu, sigma = 0.5, 0.25
norm = (images - mu) / sigma
assert norm.dtype == np.float32
print(f"Eredeti tartomány: [{images.min():.3f}, {images.max():.3f}]")
print(f"Normalizált tartomány: [{norm.min():.3f}, {norm.max():.3f}]")
np.save(BASE / "data/images_norm.npy", norm)
