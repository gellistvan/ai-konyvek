import torch
from torchvision import models

model = models.resnet18(weights=None)
model.load_state_dict(torch.load("weights.pth", weights_only=True))
model.eval()   # inference: a BatchNorm a futó buffert használja
# A felhasználó saját adatai NHWC formátumban, [0,255] uint8.
image = torch.randint(0, 256, (1, 224, 224, 3), dtype=torch.uint8)
image = image.permute(0, 3, 1, 2).float()
with torch.no_grad():
    logits = model(image)
