"""n045_train_eval.py -- train/eval üzemmód és súlyozott epoch-loss.
Futtatás a lab/ könyvtárból: python n045_train_eval.py.
Az adatokat a szkript a saját helyéhez képest oldja fel, ezért a
munkakönyvtár nem befolyásolja az útvonalakat.
A kód kimenete a könyvben rögzített futtatásból származik.
"""
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

DEVICE = "cpu"
SEED = 20261020
BATCH_SIZE = 64
DATA = Path(__file__).resolve().parent / "data"

torch.manual_seed(SEED)

images = np.load(DATA / "images.npy")      # (360,1,24,24) float32
labels = np.load(DATA / "labels.npy")      # (360,) int64
meta = pd.read_csv(DATA / "metadata.csv")

# A metadata sorrendje és az images/labels tömb sorrendje ugyanaz a szerződés.
expected_columns = ["index", "scene_id", "view_id", "label", "split",
                    "xmin", "ymin", "xmax", "ymax"]
assert list(meta.columns) == expected_columns, "váratlan metadata-fejléc"
assert len(meta) == len(images) == len(labels), "eltérő hosszúságú adat"
assert np.array_equal(meta["index"].to_numpy(), np.arange(len(images))), \
    "a metadata index oszlopa nem követi az images tömb sorrendjét"

train_idx = meta.loc[meta["split"] == "train", "index"].to_numpy()
val_idx = meta.loc[meta["split"] == "val", "index"].to_numpy()

X_train = torch.from_numpy(images[train_idx])
y_train = torch.from_numpy(labels[train_idx])
X_val = torch.from_numpy(images[val_idx])
y_val = torch.from_numpy(labels[val_idx])

train_loader = DataLoader(TensorDataset(X_train, y_train),
                          batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(TensorDataset(X_val, y_val),
                        batch_size=BATCH_SIZE, shuffle=False)

model = nn.Sequential(
    nn.Flatten(),
    nn.Linear(24 * 24, 64),
    nn.ReLU(),
    nn.Linear(64, 3),
)
loss_fn = nn.CrossEntropyLoss()
optimizer = torch.optim.SGD(model.parameters(), lr=0.05)

def train_one_epoch(model, loader, loss_fn, optimizer, device=DEVICE):
    model.train()
    total = 0.0
    n = 0
    for Xb, yb in loader:
        Xb = Xb.to(device)
        yb = yb.to(device)
        optimizer.zero_grad()
        loss = loss_fn(model(Xb), yb)
        loss.backward()
        optimizer.step()
        total += loss.item() * yb.size(0)
        n += yb.size(0)
    return total / n

def evaluate(model, loader, loss_fn, device=DEVICE):
    model.eval()
    total = 0.0
    n = 0
    correct = 0
    with torch.inference_mode():
        for Xb, yb in loader:
            Xb = Xb.to(device)
            yb = yb.to(device)
            logits = model(Xb)
            total += loss_fn(logits, yb).item() * yb.size(0)
            n += yb.size(0)
            correct += (logits.argmax(dim=1) == yb).sum().item()
    return total / n, correct / n

batch_sizes = []
# Külön, nem keverő loader: a train_loader puszta végigiterálása is
# elhasználná a shuffle permutációját, és megváltoztatná a tanítás sorrendjét.
check_loader = DataLoader(train_loader.dataset, batch_size=BATCH_SIZE,
                          shuffle=False)
for _, yb in check_loader:
    batch_sizes.append(yb.size(0))
print("train batch méretek:", batch_sizes)   # [64, 64, 64, 48]
assert batch_sizes == [64, 64, 64, 48]
assert sum(batch_sizes) == 240

for epoch in range(5):
    train_loss = train_one_epoch(model, train_loader, loss_fn, optimizer)
    val_loss, val_acc = evaluate(model, val_loader, loss_fn)
    print(f"epoch {epoch+1}: train_loss={train_loss:.4f} "
          f"val_loss={val_loss:.4f} val_acc={val_acc:.3f}")
