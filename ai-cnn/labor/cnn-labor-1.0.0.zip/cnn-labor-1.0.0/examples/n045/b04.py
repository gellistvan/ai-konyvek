def weighted_epoch_loss(batch_losses, batch_sizes):
    """Súlyozott epoch-loss a batch-veszteségek és batch-méretek listájából."""
    total = sum(l * n for l, n in zip(batch_losses, batch_sizes))
    return total / sum(batch_sizes)

result = weighted_epoch_loss([2.0, 5.0], [3, 2])
assert abs(result - 3.2) < 1e-6, result
print(f"súlyozott epoch-loss: {result:.6f}")  # 3.200000
