import math

P_hat_v_given_y_v = 0.9
P_hat_v_given_y_h = 0.05
P_y_v = 0.2
P_y_h = 0.8
P_hat_v = P_hat_v_given_y_v * P_y_v + P_hat_v_given_y_h * P_y_h
P_y_v_given_hat_v = P_hat_v_given_y_v * P_y_v / P_hat_v
print(P_y_v_given_hat_v)  # 0.8181818181818181
assert math.isclose(P_y_v_given_hat_v, 18 / 22, rel_tol=1e-12)
