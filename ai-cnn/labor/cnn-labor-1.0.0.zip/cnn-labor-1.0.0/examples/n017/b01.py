import numpy as np

def riemann_sum(func, a, b, n, endpoint="right"):
    """Jobb vagy bal végpontos Riemann-összeg."""
    dx = (b - a) / n
    if endpoint == "right":
        x = a + np.arange(1, n + 1) * dx
    elif endpoint == "left":
        x = a + np.arange(0, n) * dx
    else:
        raise ValueError("endpoint legyen 'left' vagy 'right'")
    return np.sum(func(x)) * dx

def f(x):
    return 2.0 * x

# Normalizálás ellenőrzése
print("Normalizálás, pontos érték: 1.0")
for n in [10, 100, 1000, 10000]:
    approx = riemann_sum(f, 0.0, 1.0, n)
    print(f"  n={n:5d}  jobb={approx:.6f}  hiba={abs(approx-1.0):.2e}")

# Intervallum valószínűsége, pontos érték: 0.1875
print("\nP(0.25<=X<=0.5), pontos érték: 0.1875")
for n in [100, 1000, 10000]:
    approx = riemann_sum(f, 0.25, 0.5, n)
    print(f"  n={n:5d}  jobb={approx:.6f}  hiba={abs(approx-0.1875):.2e}")

# Ellenőrzés: a jobb végpontos hiba ~1/n, a felülről közelítés iránya helyes
assert abs(riemann_sum(f, 0.0, 1.0, 10000) - 1.0) < 2e-4
assert abs(riemann_sum(f, 0.25, 0.5, 10000) - 0.1875) < 1e-5
assert riemann_sum(f, 0.0, 1.0, 100) > 1.0
print("\nellenorzes: a Riemann-hibak a varhato rendben, a jobb osszeg felulrol kozelit")
