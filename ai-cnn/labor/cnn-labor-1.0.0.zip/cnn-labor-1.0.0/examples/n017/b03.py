P_hat_v_given_y_v = 0.9
P_y_v = 0.2
P_y_h = 0.8
P_hat_v = 0.9 * 0.2   # hiba itt
P_y_v_given_hat_v = P_hat_v_given_y_v * P_y_v / P_hat_v
print(P_y_v_given_hat_v)
