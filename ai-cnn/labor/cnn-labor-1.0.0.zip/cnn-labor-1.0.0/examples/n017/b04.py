import numpy as np

def riemann_sum(func, a, b, n, endpoint="right"):
    """Jobb vagy bal végpontos Riemann-összeg."""
    dx = (b - a) / n
    if endpoint == "right":
        x = a + np.arange(1, n + 1) * dx
    elif endpoint == "left":
        x = a + np.arange(0, n) * dx
    else:
        raise ValueError("endpoint legyen 'left' vagy 'right'")
    return np.sum(func(x)) * dx

def f(x):
    return 2.0 * x

for n in [10, 100, 1000]:
    left = riemann_sum(f, 0.0, 1.0, n, "left")
    right = riemann_sum(f, 0.0, 1.0, n, "right")
    print(f"n={n:4d}  bal hiba={left-1.0:+.6f}  jobb hiba={right-1.0:+.6f}")
