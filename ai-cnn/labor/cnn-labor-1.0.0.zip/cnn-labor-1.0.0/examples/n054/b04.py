def hibas_forward(x, w, b):
    N, C, H, W = x.shape
    Cout, _, kh, kw = w.shape
    Hout = H - kh + 1
    Wout = W - kw + 1
    y = np.zeros((Cout, Hout, Wout), dtype=x.dtype)
    for o in range(Cout):
        for i in range(Hout):
            for j in range(Wout):
                # HIBAS: a 0. tengely a batch, nem a csatorna
                y[o, i, j] = np.sum(
                    x[:, :, i:i+kh, j:j+kw] * w[o, :, :, :],
                    axis=(0, 2, 3)
                ) + b[o]
    return y
