# fajl: n054_f3.py
import numpy as np

def conv2d_numpy_s1p0(x, weight, bias):
    N, C_in, H, W = x.shape
    C_out, C_in_w, kH, kW = weight.shape
    assert C_in_w == C_in
    H_out = H - kH + 1
    W_out = W - kW + 1
    y = np.zeros((N, C_out, H_out, W_out), dtype=x.dtype)
    for n in range(N):
        for o in range(C_out):
            for i in range(H_out):
                for j in range(W_out):
                    total = 0.0
                    for c in range(C_in):
                        total += np.sum(
                            x[n, c, i:i+kH, j:j+kW] * weight[o, c, :, :]
                        )
                    y[n, o, i, j] = total + bias[o]
    return y

x = np.array([[[[1, 2, 3], [4, 5, 6], [7, 8, 9]],
               [[9, 8, 7], [6, 5, 4], [3, 2, 1]]]], dtype=np.float64)
w = np.array([[[[1, 0], [0, -1]], [[0, 1], [-1, 0]]],
              [[[0, 1], [1, 0]], [[-1, 0], [0, 1]]]], dtype=np.float64)
b = np.array([1.0, -1.0], dtype=np.float64)
y = conv2d_numpy_s1p0(x, w, b)
assert np.array_equal(y[0, 0], [[-1, -1], [-1, -1]])
assert np.array_equal(y[0, 1], [[1, 3], [7, 9]])
print(y[0, 0])
print(y[0, 1])
