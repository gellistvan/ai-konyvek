y = np.zeros((N, C_out, H_out, W_out), dtype=x.dtype)
# ...
y[:, o, i, j] = np.sum(
    x[:, :, i:i+kh, j:j+kw] * w[o, :, :, :], axis=(1, 2, 3)
) + b[o]
