# munkakönyvtár: lab/n054
# fájl: n054_lab.py
import numpy as np
import torch
import torch.nn.functional as F

def conv2d_numpy(x, weight, bias, stride=1, padding=0, dilation=1):
    """NCHW keresztkorreláció, groups=1, szimmetrikus zero padding."""
    N, C_in, H, W = x.shape
    C_out, C_in_w, kH, kW = weight.shape
    if C_in_w != C_in:
        raise ValueError("A suly C_in tengelye nem egyezik a bemenettel")
    H_out = (H + 2 * padding - dilation * (kH - 1) - 1) // stride + 1
    W_out = (W + 2 * padding - dilation * (kW - 1) - 1) // stride + 1
    y = np.zeros((N, C_out, H_out, W_out), dtype=x.dtype)
    for n in range(N):
        for o in range(C_out):
            for i in range(H_out):
                for j in range(W_out):
                    total = 0.0
                    for c in range(C_in):
                        for u in range(kH):
                            for v in range(kW):
                                xi = i * stride - padding + u * dilation
                                xj = j * stride - padding + v * dilation
                                if 0 <= xi < H and 0 <= xj < W:
                                    total += x[n, c, xi, xj] * weight[o, c, u, v]
                    y[n, o, i, j] = total + bias[o]
    return y

# 1) A kezi peld a ellenorzese
x_manual = np.array([[[[1, 2, 3], [4, 5, 6], [7, 8, 9]],
                      [[9, 8, 7], [6, 5, 4], [3, 2, 1]]]], dtype=np.float64)
w_manual = np.array([[[[1, 0], [0, -1]], [[0, 1], [-1, 0]]],
                     [[[0, 1], [1, 0]], [[-1, 0], [0, 1]]]], dtype=np.float64)
b_manual = np.array([1.0, -1.0], dtype=np.float64)

y_manual = conv2d_numpy(x_manual, w_manual, b_manual)
assert np.array_equal(y_manual[0, 0], [[-1, -1], [-1, -1]])
assert np.array_equal(y_manual[0, 1], [[1, 3], [7, 9]])
print("Kezi pelda, o=0:\n", y_manual[0, 0])
print("Kezi pelda, o=1:\n", y_manual[0, 1])

x_t = torch.from_numpy(x_manual)
w_t = torch.from_numpy(w_manual)
b_t = torch.from_numpy(b_manual)
y_t = F.conv2d(x_t, w_t, b_t, stride=1, padding=0)
diff_manual = torch.max(torch.abs(y_t - torch.from_numpy(y_manual))).item()
print("PyTorch elteres a kezi peldan:", diff_manual)

# 2) Veletlen float64 osszevetes ket bemeneti csatornaval
rng = np.random.default_rng(20261020)
N, C_in, H, W = 2, 2, 5, 5
C_out, kH, kW = 3, 3, 3
stride, padding, dilation = 2, 1, 1

x = rng.standard_normal((N, C_in, H, W)).astype(np.float64)
w = rng.standard_normal((C_out, C_in, kH, kW)).astype(np.float64)
b = rng.standard_normal((C_out,)).astype(np.float64)

y_ref = conv2d_numpy(x, w, b, stride, padding, dilation)
y_torch = F.conv2d(torch.from_numpy(x),
                   torch.from_numpy(w),
                   torch.from_numpy(b),
                   stride=stride, padding=padding, dilation=dilation)

err = np.max(np.abs(y_ref - y_torch.numpy()))
assert y_ref.shape == (2, 3, 3, 3)
assert err < 1e-12
print("Alakok: x", x.shape, "w", w.shape, "b", b.shape,
      "-> y", y_ref.shape)
print("max abszolut elteres:", f"{err:.3e}")
