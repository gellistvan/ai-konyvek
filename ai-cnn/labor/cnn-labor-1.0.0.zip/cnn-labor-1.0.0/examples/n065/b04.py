import torch
import torch.nn as nn

torch.manual_seed(20261020)


class TinyLeNetGlyph(nn.Module):
    def __init__(self, in_channels=1, num_classes=3):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(in_channels, 6, kernel_size=5, stride=1, padding=0),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Conv2d(6, 16, kernel_size=5, stride=1, padding=0),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(16 * 3 * 3, 120),
            nn.ReLU(),
            nn.Linear(120, 84),
            nn.ReLU(),
            nn.Linear(84, num_classes),
        )

    def forward(self, x):
        return self.classifier(self.features(x))


x = torch.randn(2, 1, 24, 24, dtype=torch.float32)
model = TinyLeNetGlyph()
out = model(x)
n_params = sum(p.numel() for p in model.parameters())
assert out.shape == (2, 3)
assert n_params == 30391
print(tuple(out.shape), n_params)
# mért kimenet: (2, 3) 30391
