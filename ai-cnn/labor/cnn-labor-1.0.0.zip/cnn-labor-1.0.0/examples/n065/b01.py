# lab/tiny_lenet_check.py
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn

torch.manual_seed(20261020)
device = torch.device("cpu")
dtype = torch.float32
DATA = Path(__file__).resolve().parent / "data"

class TinyLeNetGlyph(nn.Module):
    """LeNet-szerű, de nem az 1998-as LeNet-5 pontos reprodukciója:
    teljes konvolúciós C3, ReLU, modern max-pool, három GlyphLab-osztály."""
    def __init__(self, in_channels=1, num_classes=3):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(in_channels, 6, kernel_size=5, stride=1, padding=0),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Conv2d(6, 16, kernel_size=5, stride=1, padding=0),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(16 * 3 * 3, 120),
            nn.ReLU(),
            nn.Linear(120, 84),
            nn.ReLU(),
            nn.Linear(84, num_classes),
        )

    def forward(self, x):
        return self.classifier(self.features(x))

images = np.load(DATA / "images.npy")  # (360,1,24,24), float32, [0,1]
labels = np.load(DATA / "labels.npy")  # (360,), int64
meta = pd.read_csv(DATA / "metadata.csv")
assert images.dtype == np.float32 and labels.dtype == np.int64
assert images.shape == (360, 1, 24, 24) and labels.shape == (360,)
assert images.min() >= 0.0 and images.max() <= 1.0
assert set(np.unique(labels)) <= {0, 1, 2}
assert meta["index"].tolist() == list(range(len(meta))), "a metadata index oszlopa nem sorrendi"
assert (meta["label"].to_numpy() == labels).all(), "a metadata és a labels.npy nem egyezik"

x = torch.from_numpy(images[:4].astype(np.float32)).to(device=device, dtype=dtype)
model = TinyLeNetGlyph().to(device=device, dtype=dtype)

with torch.no_grad():
    logits = model(x)  # a CrossEntropyLoss logitot vár, softmax nélkül

n_params = sum(p.numel() for p in model.parameters())
assert logits.shape == (4, 3), logits.shape
assert n_params == 30391, n_params
assert torch.isfinite(logits).all()

print("logits shape:", tuple(logits.shape))
print("parameter count:", n_params)
print("first-batch logits finite:", bool(torch.isfinite(logits).all()))
