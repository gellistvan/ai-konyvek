python n003_split_check.py
