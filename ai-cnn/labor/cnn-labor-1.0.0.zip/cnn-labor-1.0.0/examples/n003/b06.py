def split_by_scene(meta, rng):
    meta = meta.copy()
    scenes = meta["scene_id"].unique()
    perm = rng.permutation(len(scenes))
    split_map = {}
    for s in scenes[perm[:120]]:
        split_map[s] = "train"
    for s in scenes[perm[120:150]]:
        split_map[s] = "val"
    for s in scenes[perm[150:]]:
        split_map[s] = "test"
    meta["split_fixed"] = meta["scene_id"].map(split_map)
    return meta
