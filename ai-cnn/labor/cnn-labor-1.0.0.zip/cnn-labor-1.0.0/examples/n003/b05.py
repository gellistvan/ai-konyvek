def split_integrity(df, split_col):
    """Azon scene_id-k, amelyek több különböző splitben szerepelnek."""
    grouped = df.groupby("scene_id")[split_col].nunique()
    return grouped[grouped > 1].index.tolist()

meta_test = meta.copy()
meta_test["split_bad"] = meta_test["split"]
selected = meta_test["scene_id"].unique()[:2]
for sid in selected:
    row_id = meta_test.index[meta_test["scene_id"] == sid][0]
    old_split = meta_test.loc[row_id, "split_bad"]
    meta_test.loc[row_id, "split_bad"] = (
        "test" if old_split != "test" else "train"
    )

assert split_integrity(meta, "split") == []
bad = split_integrity(meta_test, "split_bad")
assert set(bad) == set(selected) and len(bad) == 2
