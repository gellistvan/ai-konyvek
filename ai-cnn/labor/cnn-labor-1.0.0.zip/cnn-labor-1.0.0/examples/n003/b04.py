import numpy as np

def split_by_view(meta, rng):
    meta = meta.copy()
    idx = rng.permutation(len(meta))
    split = np.full(len(meta), "train", dtype="<U5")
    split[idx[240:300]] = "val"
    split[idx[300:]] = "test"
    meta["split"] = split
    return meta
