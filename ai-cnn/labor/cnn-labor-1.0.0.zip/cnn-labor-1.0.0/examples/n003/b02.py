from __future__ import annotations

import math
import numpy as np
import pandas as pd
from pathlib import Path

DATA_DIR = Path("data")
meta = pd.read_csv(DATA_DIR / "metadata.csv")
# A metadata `index` oszlopa a képtömb sorindexe; a CSV fájlsorrend nem köt.
assert list(meta.columns) == ["index", "scene_id", "view_id", "label", "split",
                              "xmin", "ymin", "xmax", "ymax"], meta.columns
assert len(meta) == 360, len(meta)
assert meta["index"].tolist() == list(range(len(meta)))

def violating_scenes(df: pd.DataFrame, split_col: str) -> list[str]:
    """Azon scene_id-k, amelyek több különböző splitben szerepelnek."""
    nunique = df.groupby("scene_id")[split_col].nunique()
    return nunique[nunique > 1].index.tolist()

def scene_counts(df: pd.DataFrame, split_col: str) -> dict[str, int]:
    return df.groupby(split_col)["scene_id"].nunique().to_dict()

# 1. Jó split ellenőrzése a gyártó szerint
bad_good = violating_scenes(meta, "split")
counts_good = scene_counts(meta, "split")
print("Jó split:")
print("  split-számláló scene-ekre:", counts_good)
print("  szabálytalan scene-ek száma:", len(bad_good))
assert bad_good == [], bad_good
assert counts_good == {"train": 120, "val": 30, "test": 30}, counts_good

# 2. Szándékosan hibás, képszintű split
rng = np.random.default_rng(12345)  # a hibás split seedje
idx = rng.permutation(len(meta))
n_train, n_val = 240, 60
bad_split = np.full(len(meta), "unused", dtype="<U6")
bad_split[idx[:n_train]] = "train"
bad_split[idx[n_train:n_train + n_val]] = "val"
bad_split[idx[n_train + n_val:]] = "test"

meta_bad = meta.copy()
meta_bad["split_bad"] = bad_split
bad_bad = violating_scenes(meta_bad, "split_bad")
counts_bad = scene_counts(meta_bad, "split_bad")
print("Hibás split:")
print("  split-számláló scene-ekre:", counts_bad)
print("  szabálytalan scene-ek száma:", len(bad_bad))
assert len(bad_bad) > 0, "a képszintű splitnek szabálytalan scene-t kell adnia"

# 3. Várható szabálytalan scene-szám a hibás splithez
C = math.comb  # Python 3.8+: pontos egész binomiális együttható
p_same = (C(240, 2) + C(60, 2) + C(60, 2)) / C(360, 2)
print(f"Egy scene együtt maradásának valószínűsége: {p_same:.4f}")
print(f"Várható szabálytalan scene-szám: {180 * (1 - p_same):.2f}")
assert f"{180 * (1 - p_same):.2f}" == "90.25"
