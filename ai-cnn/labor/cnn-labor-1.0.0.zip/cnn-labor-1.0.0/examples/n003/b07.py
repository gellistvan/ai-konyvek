def stratified_scene_split(meta, rng):
    meta = meta.copy()
    scenes = meta.groupby("scene_id")["label"].first()
    split_map = {}
    for _, group in scenes.groupby(scenes):
        ids = group.index.to_numpy()[rng.permutation(len(group))]
        split_map.update({sid: "train" for sid in ids[:40]})
        split_map.update({sid: "val" for sid in ids[40:50]})
        split_map.update({sid: "test" for sid in ids[50:]})
    meta["split"] = meta["scene_id"].map(split_map)
    return meta
