import numpy as np
import torch
import torch.nn as nn

# A példa determinisztikus: rögzített bemenet, véletlen szám nem kell
device = "cpu"

# Input: N=4, K=3 logits, float32; target int64
logits32 = np.array([
    [ 500.0,  501.0, -501.0],
    [   2.0,    1.0,    0.0],
    [-500.0,  500.0,  500.0],
    [  10.0,  -10.0,   20.0],
], dtype=np.float32)
target_np = np.array([1, 0, 2, 2], dtype=np.int64)

# float64 kontroll: a float64 tartományban 500 még véges
z64 = logits32.astype(np.float64)
lse64 = np.log(np.exp(z64).sum(axis=1, keepdims=True))
logp64 = z64 - lse64
ref = -logp64[np.arange(logits32.shape[0]), target_np].mean()
print("float64 control:", ref)

def naive_nll(logits, target):
    # Szándékosan naiv: először softmax, majd log
    expz = np.exp(logits)                      # float32: túlcsordulás
    probs = expz / expz.sum(axis=1, keepdims=True)
    logp = np.log(probs)                       # 0-ból -inf
    return -logp[np.arange(logits.shape[0]), target].mean()

def stable_nll(logits, target):
    # log-sum-exp max-eltolással, közvetlen log-softmax
    m = logits.max(axis=1, keepdims=True)
    shifted = logits - m
    s = np.exp(shifted).sum(axis=1, keepdims=True)
    lse = m + np.log(s)
    logp = logits - lse
    return -logp[np.arange(logits.shape[0]), target].mean()

loss_fn = nn.CrossEntropyLoss()
t_logits = torch.from_numpy(logits32).to(device)
t_target = torch.from_numpy(target_np).to(device)
with torch.no_grad():
    torch_mean = loss_fn(t_logits, t_target).item()

naive_val = naive_nll(logits32, target_np)
stable_val = stable_nll(logits32, target_np)
print("naive  float32:", naive_val)
print("stable float32:", stable_val)
print("torch  float32:", torch_mean)
print("abs stable-ref:", abs(stable_val - ref))
print("abs torch-ref :", abs(torch_mean - ref))

# A stabil implementációk a float32 kerekítési hibán belül egyeznek a float64 kontrollal
assert np.isnan(naive_val)
assert abs(stable_val - ref) < 1e-5
assert abs(torch_mean - ref) < 1e-5
