p = torch.softmax(logits, dim=1)
loss = nn.CrossEntropyLoss()(p, target_float)
