import numpy as np

z = np.array([[-1000.0, 0.0, 1000.0]], dtype=np.float32)
y = np.array([[0.0, 0.5, 1.0]], dtype=np.float32)

def stable_bce_with_logits(z, y):
    # stabil softplus: max(t,0)+log1p(exp(-abs(t)))
    t = -z
    softplus = np.maximum(t, 0.0) + np.log1p(np.exp(-np.abs(t)))
    return (1.0 - y) * z + softplus

def ref_bce_with_logits(z, y):
    # float64 referencia a stabil alakból: logaddexp, elkerüli az exp/log-ot
    z64 = z.astype(np.float64)
    y64 = y.astype(np.float64)
    return (1.0 - y64) * z64 + np.logaddexp(0.0, -z64)

print(stable_bce_with_logits(z, y))
print(ref_bce_with_logits(z, y))
print(np.abs(stable_bce_with_logits(z, y) - ref_bce_with_logits(z, y)).max())
