probs = torch.softmax(logits, dim=1)  # ez már valószínűség, nem logit
loss_fn(probs, target)                # előírás megsértése
