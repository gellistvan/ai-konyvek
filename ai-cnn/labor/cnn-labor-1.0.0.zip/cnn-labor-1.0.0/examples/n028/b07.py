loss = nn.CrossEntropyLoss()(logits, target.long())
