python n028_stability.py
