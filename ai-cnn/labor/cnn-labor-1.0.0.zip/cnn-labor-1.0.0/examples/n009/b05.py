import numpy as np

def batched_norm(X):
    return np.sqrt(np.einsum("ij,ij->i", X, X))

def batched_cosine(X, Y):
    denom = batched_norm(X) * batched_norm(Y)
    num = np.einsum("ij,ij->i", X, Y)
    with np.errstate(divide="ignore", invalid="ignore"):
        return num / denom

X = np.array([[2.0, 1.0],
              [3.0, 0.0],
              [1.0, 1.0]], dtype=np.float64)
Y = np.array([[-1.0, 2.0],
              [0.0, 4.0],
              [2.0, 2.0]], dtype=np.float64)

print("X shape", X.shape, "Y shape", Y.shape)
print("norm", batched_norm(X))
print("cosine", batched_cosine(X, Y))

assert X.shape == (3, 2) and Y.shape == (3, 2)
assert np.allclose(batched_norm(X), [np.sqrt(5.0), 3.0, np.sqrt(2.0)])
assert np.allclose(batched_cosine(X, Y), [0.0, 0.0, 1.0])
