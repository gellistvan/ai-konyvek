import numpy as np

def cosine_buggy(a, b):
    return np.dot(a, b) / np.linalg.norm(a * b)
