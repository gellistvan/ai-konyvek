# labs/n009_vector_norm/vector_lab.py
import numpy as np

def dot(x, y):
    return float(np.dot(x, y))

def norm(x):
    return float(np.sqrt(np.dot(x, x)))

def cosine(x, y):
    # a laborpéldákban egyik vektor sem nullvektor
    return dot(x, y) / (norm(x) * norm(y))

x = np.array([3.0, 4.0], dtype=np.float64)
y = np.array([-4.0, 3.0], dtype=np.float64)

print("dot", dot(x, y))
print("norm_x", norm(x), "norm_y", norm(y))
print("cosine", cosine(x, y))
print("distance", norm(x - y))
print("triangle_lhs", norm(x + y), "triangle_rhs", norm(x) + norm(y))

assert abs(dot(x, y)) < 1e-12
assert abs(norm(x) - 5.0) < 1e-12
assert abs(norm(y) - 5.0) < 1e-12
assert abs(cosine(x, y)) < 1e-12
assert abs(norm(x - y) - np.sqrt(50.0)) < 1e-12
assert norm(x + y) <= norm(x) + norm(y) + 1e-12
