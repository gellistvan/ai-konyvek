def cosine_fixed(a, b):
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))
