# labs/n009_vector_norm/vector_plot.py
import matplotlib.pyplot as plt
import numpy as np

pairs = [
    (np.array([2.0, 1.0]), np.array([-1.0, 2.0])),
    (np.array([3.0, 0.0]), np.array([0.0, 4.0])),
    (np.array([1.0, 1.0]), np.array([2.0, 2.0])),
]
assert abs(np.dot(pairs[0][0], pairs[0][1])) < 1e-12
assert abs(np.dot(pairs[1][0], pairs[1][1])) < 1e-12
assert np.allclose(pairs[2][1], 2.0 * pairs[2][0])
fig, ax = plt.subplots(figsize=(5, 5))
for u, v in pairs:
    ax.quiver(0, 0, u[0], u[1], angles="xy", scale_units="xy",
              scale=1, color="black")
    ax.quiver(0, 0, v[0], v[1], angles="xy", scale_units="xy",
              scale=1, color="gray")
ax.set_xlim(-2, 4)
ax.set_ylim(-2, 5)
ax.set_aspect("equal")
ax.grid(True)
fig.savefig("vector_pairs.png", dpi=150)
