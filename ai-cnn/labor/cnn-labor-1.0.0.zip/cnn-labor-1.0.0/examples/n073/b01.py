# lab/n073_lab.py
# Futtatás: python n073_lab.py
# CPU, float32; a kimenet a képletekből számolt kontroll, nem futásidő-mérés.
import math
import torch
from torch import nn

def out_len(L, p, d, k, s):
    return math.floor((L + 2*p - d*(k-1) - 1)/s) + 1

def count_conv(conv, N, H, W):
    # Csak forward cross-correlation Conv2d; transposed conv nem tartozik ide.
    assert conv.in_channels % conv.groups == 0
    cin_per_group = conv.in_channels // conv.groups
    Ho = out_len(H, conv.padding[0], conv.dilation[0], conv.kernel_size[0], conv.stride[0])
    Wo = out_len(W, conv.padding[1], conv.dilation[1], conv.kernel_size[1], conv.stride[1])
    params = sum(p.numel() for p in conv.parameters())  # súly + bias
    mac = N * conv.out_channels * Ho * Wo * cin_per_group * conv.kernel_size[0] * conv.kernel_size[1]
    return params, mac, (Ho, Wo)

device = torch.device("cpu")
dtype = torch.float32

full = nn.Conv2d(3, 4, 3, stride=1, padding=0, dilation=1, groups=1, bias=True).to(device)
dw   = nn.Conv2d(3, 3, 3, stride=1, padding=0, dilation=1, groups=3, bias=True).to(device)
pw   = nn.Conv2d(3, 4, 1, stride=1, padding=0, dilation=1, groups=1, bias=True).to(device)

pF, mF, shapeF = count_conv(full, 1, 5, 5)
pD, mD, _ = count_conv(dw, 1, 5, 5)
pP, mP, _ = count_conv(pw, 1, 3, 3)   # a pw bemenete a depthwise 3x3-as kimenete
assert (pF, mF, shapeF) == (112, 972, (3, 3))
assert (pD, mD) == (30, 243)
assert (pP, mP) == (16, 108)
assert mD + mP == 351 and abs((mD + mP) / mF - 13/36) < 1e-12
print("full      ", pF, mF, shapeF)
print("dw        ", pD, mD)
print("pw        ", pP, mP)
print("sep össz  ", pD+pP, mD+mP)
print("MAC arány ", (mD+mP)/mF)
print("súlyarány bias nélkül ", (3*9 + 4*3)/(4*3*9))

# Független strukturális ellenőrzés: MAC = kimeneti pozíciók × kimeneti
# csatornák × a szűrőnkénti szorzások száma (a tényleges súlyalakból).
for name, layer, mac in [("full", full, mF), ("dw", dw, mD), ("pw", pw, mP)]:
    per_out = layer.out_channels * layer.weight[0].numel()
    assert mac == shapeF[0] * shapeF[1] * per_out, name

def naive_mac_conv(x, w, stride=1, pad=0):
    # Közvetlen leszámlálás: minden kimeneti elemhez minden kernelpozíció
    # és csoportbeli bemeneti csatorna egy szorzás-plusz-akkumulálás.
    N, _, H, W = x.shape
    cout, cg, kh, kw = w.shape
    Ho = (H + 2*pad - kh) // stride + 1
    Wo = (W + 2*pad - kw) // stride + 1
    mac = 0
    for _n in range(N):
        for _o in range(cout):
            for _i in range(Ho):
                for _j in range(Wo):
                    for _c in range(cg):
                        for _a in range(kh):
                            for _b in range(kw):
                                mac += 1
    return mac

x5 = torch.zeros(1, 3, 5, 5, dtype=dtype, device=device)
x3 = torch.zeros(1, 3, 3, 3, dtype=dtype, device=device)
assert naive_mac_conv(x5, full.weight) == mF
assert naive_mac_conv(x5, dw.weight) == mD
assert naive_mac_conv(x3, pw.weight) == mP

with torch.no_grad():
    Y = pw(dw(torch.zeros(1, 3, 5, 5, dtype=dtype, device=device)))
assert tuple(Y.shape) == (1, 4, 3, 3)
print("output shape:", tuple(Y.shape))
