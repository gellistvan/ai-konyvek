# lab/n073_f3.py — futtatás: python n073_f3.py
import math
import types
import torch
from torch import nn

def out_len(L, p, d, k, s):
    return math.floor((L + 2*p - d*(k-1) - 1)/s) + 1

def count_conv(conv, N, H, W):
    if conv.in_channels % conv.groups != 0:
        raise ValueError("in_channels nem osztható groups értékkel")
    cin_per_group = conv.in_channels // conv.groups
    Ho = out_len(H, conv.padding[0], conv.dilation[0], conv.kernel_size[0], conv.stride[0])
    Wo = out_len(W, conv.padding[1], conv.dilation[1], conv.kernel_size[1], conv.stride[1])
    params = sum(p.numel() for p in conv.parameters())
    mac = N * conv.out_channels * Ho * Wo * cin_per_group * conv.kernel_size[0] * conv.kernel_size[1]
    return params, mac, (Ho, Wo)

full = nn.Conv2d(3, 4, 3); dw = nn.Conv2d(3, 3, 3, groups=3); pw = nn.Conv2d(3, 4, 1)
assert count_conv(full, 1, 5, 5) == (112, 972, (3, 3))
assert count_conv(dw,   1, 5, 5) == (30, 243, (3, 3))
assert count_conv(pw,   1, 3, 3) == (16, 108, (3, 3))
g2 = nn.Conv2d(6, 4, 3, groups=2)
# H=W=10, k=3, p=0, s=1, d=1 -> Hout=Wout=8; N=2; out=4; cin/group=3
assert count_conv(g2, 2, 10, 10) == (112, 13824, (8, 8))

# A védőágat külön teszttel ellenőrizzük: a Conv2d(5,4,3,groups=2)
# már a konstruktorban elhasal, ezért SimpleNamespace-szel adjuk át a hibás metát.
bad = types.SimpleNamespace(in_channels=5, groups=2)
try:
    count_conv(bad, 1, 5, 5)
except ValueError:
    print("csoportos oszthatósági hiba helyesen elkapva")
else:
    raise AssertionError("a count_conv nem dobott hibát")
print("minden assert lefutott")
