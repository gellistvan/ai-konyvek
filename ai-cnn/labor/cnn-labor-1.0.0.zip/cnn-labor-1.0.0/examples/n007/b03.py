import json
import platform
import sys

import numpy as np

try:
    import torch
except ImportError:
    torch = None

cuda_available = bool(torch is not None and torch.cuda.is_available())
report = {
    "py_executable": sys.executable,
    "python_version": platform.python_version(),
    "python_implementation": platform.python_implementation(),
    "platform": platform.platform(),
    "numpy_version": np.__version__,
    "torch_version": torch.__version__ if torch is not None else None,
    "cuda_available": cuda_available,
    "device_contract": "cuda" if cuda_available else "cpu",
}
print(json.dumps(report, indent=2, sort_keys=True))
