cd lab
mkdir -p reports
uv run python version_report.py | tee reports/version_report_cli.json
