cd lab
uv venv --python 3.12
uv sync
uv run python --version
