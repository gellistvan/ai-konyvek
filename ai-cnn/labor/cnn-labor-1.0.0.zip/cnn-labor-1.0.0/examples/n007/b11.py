import argparse
import json
import platform
import sys

import numpy as np

try:
    import torch
except ImportError:
    torch = None

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    args = parser.parse_args()

    cuda_available = bool(torch is not None and torch.cuda.is_available())
    report = {
        "py_executable": sys.executable,
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "numpy_version": np.__version__,
        "torch_version": torch.__version__ if torch is not None else None,
        "cuda_available": cuda_available,
        "device_contract": args.device,
    }
    if args.device == "cuda" and not cuda_available:
        report["error"] = "CUDA requested but not available"
        print(json.dumps(report, indent=2, sort_keys=True), file=sys.stderr)
        return 1

    print(json.dumps(report, indent=2, sort_keys=True))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
