uv run --with ipykernel python -m ipykernel install --user --name cnn-labor --display-name "CNN labor (lab/.venv)"
