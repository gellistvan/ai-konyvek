import json
import numpy as np

baseline = json.load(open("conv_check_report.json", encoding="utf-8"))
fresh = json.load(open("reports/conv_check_local.json", encoding="utf-8"))

def check(a, b, path="report"):
    if isinstance(a, dict):
        assert set(a) == set(b), f"eltérő kulcsok: {path}"
        for key in a:
            check(a[key], b[key], f"{path}.{key}")
    elif isinstance(a, list):
        assert len(a) == len(b), f"eltérő hossz: {path}"
        for i, (x, y) in enumerate(zip(a, b)):
            check(x, y, f"{path}[{i}]")
    elif isinstance(a, str):
        if a != b:
            print(f"szöveges mező: {path}: {a!r} -> {b!r}")
    else:
        assert np.allclose(b, a, rtol=1e-9, atol=1e-11), f"numerikus eltérés: {path}"

check(baseline, fresh)
print("Minden numerikus mező a tűrésen belül egyezik.")
