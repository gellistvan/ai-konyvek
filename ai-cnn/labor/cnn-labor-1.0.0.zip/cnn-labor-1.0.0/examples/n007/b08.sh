cd lab
uv run python conv_reference.py --torch > reports/conv_check_local.json
