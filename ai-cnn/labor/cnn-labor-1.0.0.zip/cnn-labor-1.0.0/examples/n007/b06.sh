cd lab
uv run --with jupyter --with ipykernel jupyter notebook
