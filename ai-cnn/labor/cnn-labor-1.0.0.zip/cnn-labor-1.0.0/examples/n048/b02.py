# train_mlp_n048.py
import argparse, csv, json, os, sys
import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

class GlyphMLP(torch.nn.Module):
    def __init__(self, in_dim=576, hidden=32, classes=3, p=0.1):
        super().__init__()
        self.net = torch.nn.Sequential(
            torch.nn.Flatten(),
            torch.nn.Linear(in_dim, hidden),
            torch.nn.ReLU(),
            torch.nn.Dropout(p),
            torch.nn.Linear(hidden, classes),
        )

    def forward(self, x):
        return self.net(x)

class ArrayDataset(Dataset):
    def __init__(self, x, y):
        if not (x.ndim == 4 and x.shape[1] == 1):
            raise ValueError(f"váratlan képalak: {x.shape}")
        self.x = torch.from_numpy(np.asarray(x, dtype=np.float32))
        self.y = torch.from_numpy(np.asarray(y, dtype=np.int64))

    def __len__(self):
        return len(self.y)

    def __getitem__(self, i):
        return self.x[i], self.y[i]

def load_split(data_dir, n_images):
    # Csak a metadata.csv-ból bontunk; így a scene_id szerinti
    # függetlenséget ellenőrizni tudjuk. A rekordot az index mező
    # köti az images.npy sorához, nem a CSV sorszáma.
    with open(os.path.join(data_dir, "metadata.csv"), newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    if len(rows) != n_images:
        raise ValueError(
            f"a metadata sorainak száma ({len(rows)}) != images ({n_images})")
    idx = {"train": [], "val": [], "test": []}
    scenes = {"train": set(), "val": set(), "test": set()}
    for r in rows:
        s = r["split"]
        if s not in idx:
            raise ValueError(f"ismeretlen split: {s}")
        i = int(r["index"])
        if not 0 <= i < n_images:
            raise ValueError(f"index a tartományon kívül: {i}")
        idx[s].append(i)
        scenes[s].add(r["scene_id"])
    for a, b in (("train", "val"), ("train", "test"), ("val", "test")):
        if not scenes[a].isdisjoint(scenes[b]):
            raise ValueError(f"a {a} és {b} split scene-jei átfednek")
    return idx, rows

@torch.inference_mode()
def evaluate(model, loader):
    model.eval()
    total, correct, loss_sum = 0, 0, 0.0
    for x, y in loader:
        logits = model(x)
        loss_sum += torch.nn.functional.cross_entropy(
            logits, y, reduction="sum").item()
        correct += (logits.argmax(1) == y).sum().item()
        total += len(y)
    return loss_sum / total, correct / total

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data-dir", default="../data")
    p.add_argument("--out-dir", default="artifacts_n048")
    p.add_argument("--epochs", type=int, default=60)
    p.add_argument("--batch-size", type=int, default=32)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--weight-decay", type=float, default=1e-4)
    p.add_argument("--seed", type=int, default=20261020)
    args = p.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    torch.manual_seed(args.seed)

    images = np.load(os.path.join(args.data_dir, "images.npy"))
    labels = np.load(os.path.join(args.data_dir, "labels.npy"))
    if images.dtype != np.float32:
        raise ValueError(f"az images dtype-ja {images.dtype}, nem float32")
    if not np.all((images >= 0.0) & (images <= 1.0)):
        raise ValueError("az images nem esik a [0,1] tartományba")
    if len(labels) != len(images):
        raise ValueError(f"labels ({len(labels)}) != images ({len(images)})")
    idx, rows = load_split(args.data_dir, len(images))

    loaders = {}
    for split in ("train", "val", "test"):
        ds = ArrayDataset(images[idx[split]], labels[idx[split]])
        g = torch.Generator().manual_seed(args.seed)
        shuffle = split == "train"
        loaders[split] = DataLoader(
            ds, batch_size=args.batch_size, shuffle=shuffle, generator=g)

    model = GlyphMLP()
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    best_val = float("inf")
    best_path = os.path.join(args.out_dir, "best_model.pt")
    history = []

    for epoch in range(1, args.epochs + 1):
        model.train()
        total_loss, count = 0.0, 0
        for x, y in loaders["train"]:
            optimizer.zero_grad(set_to_none=True)
            loss = torch.nn.functional.cross_entropy(model(x), y)
            if not torch.isfinite(loss):
                raise RuntimeError(f"nem véges loss az epoch {epoch} során")
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(y)
            count += len(y)
        train_loss = total_loss / count
        val_loss, val_acc = evaluate(model, loaders["val"])
        if not (np.isfinite(val_loss) and np.isfinite(val_acc)):
            raise RuntimeError(
                f"nem véges validációs metrika az epoch {epoch} során")
        history.append({"epoch": epoch, "train_loss": train_loss,
                        "val_loss": val_loss, "val_acc": val_acc})
        if val_loss < best_val:
            best_val = val_loss
            torch.save(model.state_dict(), best_path)
        print(f"{epoch:03d} train={train_loss:.4f} "
              f"val={val_loss:.4f} acc={val_acc:.4f}")

    state = torch.load(best_path, map_location="cpu", weights_only=True)
    model.load_state_dict(state)
    model.eval()
    test_loss, test_acc = evaluate(model, loaders["test"])
    result = {
        "protocol": "n048-III-checkpoint",
        "seed": args.seed,
        "best_val_loss": best_val,
        "test_loss": test_loss,
        "test_accuracy": test_acc,
        "history_val_acc": [h["val_acc"] for h in history],
        "history_train_loss": [h["train_loss"] for h in history],
        "command": " ".join([sys.executable, *sys.argv]),
    }
    with open(os.path.join(args.out_dir, "results.json"), "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
