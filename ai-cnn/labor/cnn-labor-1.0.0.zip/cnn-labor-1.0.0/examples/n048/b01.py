# gradient_check_n048.py
import numpy as np
import torch

def stable_softmax(z):
    z = z - z.max(axis=1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=1, keepdims=True)

def mlp_forward_backward(x, y, w1, b1, w2, b2):
    # x: (N,d), y: (N,), w1: (H,d), b1: (H,),
    # w2: (K,H), b2: (K,)
    a = x @ w1.T + b1           # (N,H)
    h = np.maximum(a, 0.0)
    z = h @ w2.T + b2           # (N,K)
    p = stable_softmax(z)
    N = x.shape[0]
    y_onehot = np.zeros_like(p)
    y_onehot[np.arange(N), y] = 1.0
    G = (p - y_onehot) / N      # (N,K)
    d_w2 = G.T @ h              # (K,H)
    d_b2 = G.sum(axis=0)        # (K,)
    dh = (G @ w2) * (a > 0)     # (N,H), ReLU-maszk
    d_w1 = dh.T @ x             # (H,d)
    d_b1 = dh.sum(axis=0)       # (H,)
    loss = -np.log(p[np.arange(N), y]).mean()
    return (d_w1, d_b1, d_w2, d_b2), loss

x = np.array([[1.0, 2.0], [3.0, 4.0]], dtype=np.float64)
y = np.array([0, 1], dtype=np.int64)
w1 = np.array([[0.5, -0.25]], dtype=np.float64)
b1 = np.array([0.1], dtype=np.float64)
w2 = np.array([[0.2], [-0.3]], dtype=np.float64)
b2 = np.array([0.0, 0.1], dtype=np.float64)

np_grads, np_loss = mlp_forward_backward(x, y, w1, b1, w2, b2)

x_t = torch.tensor(x, dtype=torch.float64)
y_t = torch.tensor(y, dtype=torch.long)
w1_t = torch.tensor(w1, dtype=torch.float64, requires_grad=True)
b1_t = torch.tensor(b1, dtype=torch.float64, requires_grad=True)
w2_t = torch.tensor(w2, dtype=torch.float64, requires_grad=True)
b2_t = torch.tensor(b2, dtype=torch.float64, requires_grad=True)

z_t = torch.relu(x_t @ w1_t.T + b1_t) @ w2_t.T + b2_t
loss_t = torch.nn.functional.cross_entropy(z_t, y_t)
loss_t.backward()

for np_g, torch_g, name in [
    (np_grads[0], w1_t.grad, "w1"),
    (np_grads[1], b1_t.grad, "b1"),
    (np_grads[2], w2_t.grad, "w2"),
    (np_grads[3], b2_t.grad, "b2"),
]:
    np.testing.assert_allclose(np_g, torch_g.detach().numpy(),
                               rtol=1e-10, atol=1e-10,
                               err_msg=name)
    diff = np.max(np.abs(np_g - torch_g.detach().numpy()))
    print(f"{name}: NumPy={np_g} | autograd={torch_g.detach().numpy()} | "
          f"max_abs_diff={diff:.2e}")

np.testing.assert_allclose(np_loss, loss_t.item(), rtol=1e-10, atol=1e-10,
                           err_msg="loss")
print(f"loss: numpy={np_loss:.8f}, autograd={loss_t.item():.8f} | "
      f"abs_diff={abs(np_loss - loss_t.item()):.2e}")
