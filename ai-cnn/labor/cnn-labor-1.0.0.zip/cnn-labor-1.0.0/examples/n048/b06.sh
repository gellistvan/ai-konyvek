python predict_fresh_n048.py \
  --input ../data/corrupted_test.npy \
  --checkpoint artifacts_n048/best_model.pt \
  --out artifacts_n048/fresh_predictions.csv
