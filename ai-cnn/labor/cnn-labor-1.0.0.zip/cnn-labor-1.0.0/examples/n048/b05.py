# predict_fresh_n048.py
import argparse, csv
import numpy as np
import torch
from train_mlp_n048 import GlyphMLP

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", required=True)
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--out", required=True)
    args = p.parse_args()

    x = np.load(args.input)
    assert x.ndim == 4 and x.shape[1:] == (1, 24, 24), x.shape
    assert x.dtype == np.float32, x.dtype
    assert np.all(np.isfinite(x)) and np.all((x >= 0.0) & (x <= 1.0))

    model = GlyphMLP()
    state = torch.load(args.checkpoint, map_location="cpu", weights_only=True)
    model.load_state_dict(state)
    model.eval()

    with torch.inference_mode():
        logits = model(torch.from_numpy(x))
        prob = torch.softmax(logits, dim=1).numpy()
    pred = prob.argmax(axis=1)
    with open(args.out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["index", "predicted_class", "prob_0", "prob_1", "prob_2"])
        for i in range(len(x)):
            w.writerow([i, int(pred[i]), *[float(v) for v in prob[i]]])
    print(f"predikciók: {args.out}")

if __name__ == "__main__":
    main()
