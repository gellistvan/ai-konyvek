python train_mlp_n048.py --data-dir ../data --out-dir artifacts_n048 --epochs 60 --seed 20261020
