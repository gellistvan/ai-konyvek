# lab/n015/f3_solution.py
import numpy as np

def affine_grads(X, W, b, G):
    assert X.dtype == np.float64 and W.dtype == np.float64
    assert G.dtype == np.float64 and b.dtype == np.float64
    dX = G @ W
    dW = G.T @ X
    db = G.sum(axis=0)
    return dX, dW, db

X = np.array([[1.0, 0.0, 2.0],
              [0.0, 1.0, 1.0]], dtype=np.float64)
W = np.array([[1.0, 2.0, 0.0],
              [0.0, 1.0, 2.0]], dtype=np.float64)
b = np.array([-1.0, 1.0], dtype=np.float64)
G = np.array([[2.0, -1.0],
              [0.0, -3.0]], dtype=np.float64)

dX, dW, db = affine_grads(X, W, b, G)
print("dX ="); print(dX)
print("dW ="); print(dW)
print("db ="); print(db)

expected_dX = np.array([[2.0, 3.0, -2.0],
                        [0.0, -3.0, -6.0]])
expected_dW = np.array([[2.0, 0.0, 4.0],
                        [-1.0, -3.0, -5.0]])
expected_db = np.array([2.0, -4.0])
np.testing.assert_allclose(dX, expected_dX, atol=1e-12, rtol=1e-12)
np.testing.assert_allclose(dW, expected_dW, atol=1e-12, rtol=1e-12)
np.testing.assert_allclose(db, expected_db, atol=1e-12, rtol=1e-12)
assert dX.shape == (2, 3) and dW.shape == (2, 3) and db.shape == (2,)
