def buggy_dX(X, W, G):
    # X: N x d, W: m x d, G: N x m
    return W.T @ G
