expected_dX = np.array([[2.0, 3.0, -2.0],
                        [0.0, -3.0, -6.0]])
np.testing.assert_allclose(buggy_dX_corrected(X, W, G), expected_dX,
                           rtol=1e-12, atol=1e-12)
