def buggy_dX_corrected(X, W, G):
    return G @ W  # N x d
