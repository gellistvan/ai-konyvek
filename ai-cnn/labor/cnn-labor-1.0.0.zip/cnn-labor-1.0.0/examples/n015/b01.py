# lab/n015/vjp_lab.py
import torch

torch.manual_seed(20261020)  # a példa determinisztikus; véletlen nincs benne
DTYPE = torch.float64
DEVICE = torch.device("cpu")

x = torch.tensor([1.0, 2.0], dtype=DTYPE, device=DEVICE, requires_grad=True)
g = torch.tensor([1.0, -2.0, 3.0], dtype=DTYPE, device=DEVICE)

def f(u: torch.Tensor) -> torch.Tensor:
    return torch.stack([
        u[0],
        u[0] + u[1] ** 2,
        u[0] * u[1],
    ])

z = f(x)

# Az x = (1,2) pontban kézzel levezetett Jacobi-mátrix:
J = torch.tensor(
    [
        [1.0, 0.0],
        [1.0, 2.0 * x[1].item()],
        [x[1].item(), x[0].item()],
    ],
    dtype=DTYPE,
    device=DEVICE,
)

vjp_explicit = J.T @ g
# loss = g·f(x), ezért grad_x(loss) = J_f(x)^T g:
loss = torch.dot(z, g)
vjp_autograd, = torch.autograd.grad(loss, x)

print("J =")
print(J)
max_abs_diff = (vjp_explicit - vjp_autograd).abs().max().item()
print("vjp_explicit =", vjp_explicit)
print("vjp_autograd =", vjp_autograd)
print("max_abs_diff =", max_abs_diff)
expected = torch.tensor([5.0, -5.0], dtype=DTYPE, device=DEVICE)
assert max_abs_diff < 1e-12
assert torch.allclose(vjp_explicit, expected, atol=1e-12, rtol=1e-12)
