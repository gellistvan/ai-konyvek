import numpy as np

rng = np.random.default_rng(20261020)

def linear_forward(X, W, b):
    return X @ W.T + b

def linear_backward(G, X, W):
    dW = G.T @ X
    db = G.sum(axis=0)
    dX = G @ W
    return dX, dW, db

def relu_forward(Z):
    return np.maximum(0.0, Z), Z

def relu_backward(dA, cache):
    return dA * (cache > 0)

def unpack(theta, d, h, K):
    nW1, nb1, nW2 = d*h, h, h*K
    W1 = theta[:nW1].reshape(h, d)
    b1 = theta[nW1:nW1+nb1]
    W2 = theta[nW1+nb1:nW1+nb1+nW2].reshape(K, h)
    b2 = theta[nW1+nb1+nW2:]
    return W1, b1, W2, b2

def loss_and_grad(theta, X, d, h, K):
    W1, b1, W2, b2 = unpack(theta, d, h, K)
    Z1 = linear_forward(X, W1, b1)
    A1, cache = relu_forward(Z1)
    Z2 = linear_forward(A1, W2, b2)
    N, Kk = Z2.shape
    loss = np.mean(Z2**2)
    G2 = 2.0/(N*Kk) * Z2
    dA1, dW2, db2 = linear_backward(G2, A1, W2)
    dZ1 = relu_backward(dA1, cache)
    _, dW1, db1 = linear_backward(dZ1, X, W1)
    grad = np.concatenate([dW1.ravel(), db1, dW2.ravel(), db2])
    return loss, grad

def relu_mask(theta, X, d, h, K):
    W1, b1, _, _ = unpack(theta, d, h, K)
    return linear_forward(X, W1, b1) > 0          # aktív ReLU-k mintája

def numerical_grad(theta, X, d, h, K, eps):
    p = theta.size
    g = np.zeros_like(theta)
    kink = np.zeros(p, dtype=bool)                 # töréspontot átlépő koordináták
    ref = relu_mask(theta, X, d, h, K)
    for i in range(p):
        e = np.zeros_like(theta)
        e[i] = 1.0
        lp = loss_and_grad(theta + eps*e, X, d, h, K)[0]
        lm = loss_and_grad(theta - eps*e, X, d, h, K)[0]
        g[i] = (lp - lm) / (2*eps)
        kink[i] = (np.any(relu_mask(theta + eps*e, X, d, h, K) != ref)
                   or np.any(relu_mask(theta - eps*e, X, d, h, K) != ref))
    return g, kink

d, h, K, N = 3, 4, 2, 2
X = rng.normal(size=(N, d)).astype(np.float64)
epsilons = [1e-3, 1e-5, 1e-7, 1e-9, 1e-11]
for sigma in [0.1, 1.0, 10.0]:
    theta = (sigma * rng.normal(size=d*h + h + K*h + K)).astype(np.float64)
    loss, grad = loss_and_grad(theta, X, d, h, K)
    assert grad.shape == theta.shape == (d*h + h + K*h + K,)
    assert np.isfinite(grad).all()
    for eps in epsilons:
        num, kink = numerical_grad(theta, X, d, h, K, eps)
        ok = ~kink                                 # csak a sima tartományon hasonlítunk
        if not ok.any():                           # üres tömbön a np.max hibát dobna
            print(f"sigma={sigma:4.1f} eps={eps:8.0e} kink={int(kink.sum()):2d} "
                  "nincs összehasonlítható koordináta")
            continue
        abs_err = np.max(np.abs(num - grad)[ok])
        rel_err = np.max((np.abs(num - grad) /
                          np.maximum(np.maximum(np.abs(num), np.abs(grad)), 1e-12))[ok])
        print(f"sigma={sigma:4.1f} eps={eps:8.0e} kink={int(kink.sum()):2d} "
              f"max_abs={abs_err:8.2e} max_rel={rel_err:8.2e}")
