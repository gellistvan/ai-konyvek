import numpy as np

rng = np.random.default_rng(1)

def linear_forward(X, W, b):
    return X @ W.T + b

def linear_backward(G, X, W):
    return G @ W, G.T @ X, G.sum(axis=0)

def relu_forward(Z):
    return np.maximum(0.0, Z), Z

def relu_backward(dA, cache):
    return dA * (cache > 0)

d, h, K, N = 2, 3, 1, 1
X = rng.normal(size=(N, d)).astype(np.float64)
p = d*h + h + K*h + K
theta = rng.normal(size=p).astype(np.float64)

def unpack(theta):
    nW1, nb1, nW2 = d*h, h, K*h
    W1 = theta[:nW1].reshape(h, d)
    b1 = theta[nW1:nW1+nb1]
    W2 = theta[nW1+nb1:nW1+nb1+nW2].reshape(K, h)
    b2 = theta[nW1+nb1+nW2:]
    return W1, b1, W2, b2

def loss_only(theta):
    W1, b1, W2, b2 = unpack(theta)
    Z1 = linear_forward(X, W1, b1)
    A1, _ = relu_forward(Z1)
    Z2 = linear_forward(A1, W2, b2)
    return float(np.mean(Z2**2))

def loss_and_grad(theta):
    W1, b1, W2, b2 = unpack(theta)
    Z1 = linear_forward(X, W1, b1)
    A1, cache = relu_forward(Z1)
    Z2 = linear_forward(A1, W2, b2)
    loss = np.mean(Z2**2)
    G2 = 2.0/(N*K) * Z2
    dA1, dW2, db2 = linear_backward(G2, A1, W2)
    dZ1 = relu_backward(dA1, cache)
    _, dW1, db1 = linear_backward(dZ1, X, W1)
    return loss, np.concatenate([dW1.ravel(), db1, dW2.ravel(), db2])

def numerical(theta, eps):
    g = np.zeros_like(theta)
    for i in range(theta.size):
        e = np.zeros_like(theta)
        e[i] = 1.0
        g[i] = (loss_only(theta + eps*e) - loss_only(theta - eps*e)) / (2*eps)
    return g

_, grad = loss_and_grad(theta)
num = numerical(theta, 1e-6)
assert grad.shape == (p,) and num.shape == (p,)
print("grad shape:", grad.shape, "p:", p)
print("max abs error:", np.max(np.abs(grad - num)))
