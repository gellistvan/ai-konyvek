python gradcheck_lab.py
