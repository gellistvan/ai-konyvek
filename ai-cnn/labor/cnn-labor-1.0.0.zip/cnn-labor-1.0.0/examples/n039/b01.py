f = lambda x: x**3
x0, eps = 2.0, 1e-2
print(f"{(f(x0+eps)-f(x0))/eps:.6f}")          # 12.060100
print(f"{(f(x0+eps)-f(x0-eps))/(2*eps):.6f}")  # 12.000100
