import numpy as np

def accuracy(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    assert y_true.shape == y_pred.shape
    return float(np.mean(y_true == y_pred))

# Háromosztályos címkék; a konstans prediktor mindig a 0 osztályt adja.
y_train = np.zeros(100, dtype=np.int64)                  # minden címke 0
y_test = np.concatenate([np.ones(50, dtype=np.int64),     # 50 db 1
                         np.full(50, 2, dtype=np.int64)])  # 50 db 2
pred_train = np.zeros(100, dtype=np.int64)
pred_test = np.zeros(100, dtype=np.int64)

print("tanító accuracy:", accuracy(y_train, pred_train))  # 1.0
print("teszt accuracy:", accuracy(y_test, pred_test))     # 0.0
np.testing.assert_allclose(accuracy(y_train, pred_train), 1.0, atol=1e-12)
np.testing.assert_allclose(accuracy(y_test, pred_test), 0.0, atol=1e-12)
