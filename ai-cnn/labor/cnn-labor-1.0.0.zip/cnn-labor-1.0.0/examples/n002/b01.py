import numpy as np

y_train = np.concatenate([
    np.zeros(90, dtype=np.int64),
    np.ones(10, dtype=np.int64)
])
y_test = np.concatenate([
    np.zeros(10, dtype=np.int64),
    np.ones(90, dtype=np.int64)
])

def accuracy(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    assert y_true.shape == y_pred.shape
    return float(np.mean(y_true == y_pred))

pred = np.zeros_like(y_train)
print("train accuracy:", accuracy(y_train, pred))  # 0.9
print("test accuracy:", accuracy(y_test, pred))    # 0.1
np.testing.assert_allclose(accuracy(y_train, pred), 0.9, atol=1e-12)
np.testing.assert_allclose(accuracy(y_test, pred), 0.1, atol=1e-12)
