class FixedDropout:
    def __init__(self, p_keep):
        self.p_keep = p_keep
    def forward(self, x, rng, training=True):
        if not training:                 # eval: nincs maszk, nincs skálázás
            return x
        mask = (rng.random(x.shape) < self.p_keep).astype(float)
        return mask * x / self.p_keep    # inverted scaling
