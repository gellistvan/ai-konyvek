class WrongDropout:
    def __init__(self, p_keep):
        self.p_keep = p_keep
    def forward(self, x, rng):
        mask = (rng.random(x.shape) < self.p_keep).astype(float)
        return mask * x
