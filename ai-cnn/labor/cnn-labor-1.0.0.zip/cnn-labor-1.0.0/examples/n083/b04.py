import numpy as np

def inverted_dropout(x, p_keep, rng):
    assert x.dtype == np.float32, "float32 bemenet kötelező"
    assert np.isscalar(p_keep) and 0.0 < float(p_keep) <= 1.0
    mask = (rng.random(x.shape, dtype=np.float32) < np.float32(p_keep)).astype(np.float32)
    out = mask * x / np.float32(p_keep)
    assert out.shape == x.shape and out.dtype == np.float32
    return out

rng = np.random.default_rng(42)
x = np.array([2.0, -1.0, 3.0, 0.0], dtype=np.float32)
print(inverted_dropout(x, 0.5, rng))
# A labor futtatása (NumPy 2.5.4) ezt adja: [ 4. -0.  0.  0.]; a -0. onnan ered, hogy a -1*0 szorzat float32-ben negatív előjelű nullát ad
