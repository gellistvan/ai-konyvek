import numpy as np

rng = np.random.default_rng(20261020)
h = np.array([2.0, -1.0, 3.0, 0.0], dtype=np.float32)
p_keep = np.float32(0.5)                 # megtartási valószínűség
mask = (rng.random(h.shape, dtype=np.float32) < p_keep).astype(np.float32)
out = mask * h / p_keep
print(f"mask={mask}, out={out}")
# Kimenet (NumPy 2.5.4, seed 20261020):
# mask=[0. 0. 1. 1.], out=[ 0. -0.  6.  0.]
# Ellenőrzés: a 4. elem mindig 0, a skála 1/p_keep = 2.
# A seedelt maszk itt (0,0,1,1), nem az illusztráció m=(1,0,1,1) maszkja.
# PyTorch-megfelelő: torch.nn.Dropout(p=1 - p_keep), mert ott p a kihagyás.
