# munkakönyvtár: lab/
# futtatás: python regularization_ablation.py
import numpy as np, torch, torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

SEED = 20261020
device = torch.device("cpu")

images = np.load("data/images.npy").astype(np.float32)      # (360,1,24,24)
labels = np.load("data/labels.npy").astype(np.int64)        # (360,)
meta = np.genfromtxt("data/metadata.csv", delimiter=",", dtype=None,
                     names=True, encoding="utf-8")
# A sorrendre nem támaszkodunk: a saját index oszlopa adja a tömbindexet.
if not (len(meta) == len(images) == len(labels)):
    raise ValueError("a metadata.csv és a tömbök hossza eltér")
idx_all = meta["index"].astype(np.int64)
if not np.array_equal(np.sort(idx_all), np.arange(len(images))):
    raise ValueError("a metadata.csv index oszlopa nem permutációja a tömbindexeknek")
split = np.asarray(meta["split"]).astype(str)
train_idx = idx_all[split == "train"]
val_idx   = idx_all[split == "val"]
assert (len(train_idx), len(val_idx)) == (240, 60)

Xtr = torch.from_numpy(images[train_idx])
ytr = torch.from_numpy(labels[train_idx])
Xva = torch.from_numpy(images[val_idx])
yva = torch.from_numpy(labels[val_idx])

class TinyCNN(nn.Module):
    def __init__(self, p_drop=0.0):          # p_drop = nn.Dropout argumentuma
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1, 16, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(16, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2))
        self.head = nn.Sequential(nn.Flatten(), nn.Linear(32*6*6, 3))
        self.drop = nn.Dropout(p_drop) if p_drop > 0 else nn.Identity()
    def forward(self, x):
        z = self.features(x)
        z = self.drop(z)
        return self.head(z)

def evaluate(model, X, y):
    model.eval()
    with torch.no_grad():
        out = model(X)
        acc = (out.argmax(1) == y).float().mean().item()
    assert 0.0 <= acc <= 1.0
    return acc

def train_one(cfg, Xtr, ytr, Xva, yva):
    # cfg: (p_drop, wd, label_smooth, use_aug)
    # Minden konfiguráció azonos inicializálást és shuffle-sorrendet kap, és
    # mindegyik AdamW-t használ; a weight decay csak a wd értékében tér el.
    torch.manual_seed(SEED)
    rng = np.random.default_rng(SEED)
    model = TinyCNN(p_drop=cfg[0]).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=cfg[1])
    lossf = nn.CrossEntropyLoss(label_smoothing=cfg[2])
    ds = TensorDataset(Xtr, ytr)
    for ep in range(15):
        model.train()
        for xb, yb in DataLoader(ds, batch_size=32, shuffle=True):
            if cfg[3]:
                xb = xb + 0.02 * torch.randn_like(xb)  # kis zaj, címkemegőrző
                sh = rng.integers(-2, 3, size=2)       # egy batch-re érvényes eltolás
                xb = torch.roll(xb, shifts=tuple(sh), dims=(2, 3))
            opt.zero_grad()
            loss = lossf(model(xb), yb)
            loss.backward()
            opt.step()
    return evaluate(model, Xva, yva)

configs = {
    "baseline":      (0.0, 0.0,  0.0, False),
    "+dropout":      (0.5, 0.0,  0.0, False),
    "+weight_decay": (0.0, 1e-4, 0.0, False),
    "+label_smooth": (0.0, 0.0,  0.1, False),
    "+augment":      (0.0, 0.0,  0.0, True),
}
for name, cfg in configs.items():
    acc = train_one(cfg, Xtr, ytr, Xva, yva)
    print(f"{name:14s} val_acc={acc:.3f}")
