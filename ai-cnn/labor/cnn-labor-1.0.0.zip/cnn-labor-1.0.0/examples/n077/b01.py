for p in model.backbone.parameters():
    p.requires_grad_(False)
    p.grad = None                                  # régi gradiens törlése
optimizer = torch.optim.SGD(
    [p for p in model.parameters() if p.requires_grad], lr=1e-2)  # csak a tanítandók
