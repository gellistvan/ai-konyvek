def freeze_by_prefix(model, prefix):
    trainable = []
    for name, p in model.named_parameters():
        matches = prefix == "" or name == prefix or name.startswith(prefix + ".")
        if matches:
            p.requires_grad_(False)
        elif p.requires_grad:
            trainable.append((name, p))
    return trainable

m = nn.Sequential(nn.Linear(4, 3), nn.Linear(3, 2))
for n, p in m.named_parameters():
    assert p.requires_grad
tr = freeze_by_prefix(m, "0")
assert len(tr) == 2          # a második réteg weight és bias
assert not m[0].weight.requires_grad
assert m[1].weight.requires_grad
