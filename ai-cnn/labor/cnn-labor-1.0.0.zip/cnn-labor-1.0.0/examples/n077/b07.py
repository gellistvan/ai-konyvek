model.backbone.requires_grad_(False)
optimizer = Adam(model.head.parameters(), lr=1e-3)
for xb, yb in train_loader:      # a DataLoader nem állít módot
    model.train()                # az egész modellt train módba teszi
    loss = CE(model(xb), yb)
    loss.backward(); optimizer.step()
# később: model.eval(); eval_metrics(model, val_loader)
