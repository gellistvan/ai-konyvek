# lab/n077/pretrained_torchvision.py  (letöltést igényel; nem futtatott)
import torch, torch.nn as nn
from torchvision.models import resnet18, ResNet18_Weights

weights = ResNet18_Weights.DEFAULT                 # (1) enum: verziózott súlycsomag
model = resnet18(weights=weights)
preprocess = weights.transforms()                  # (2) resize + crop + normalizálás a csomag szerint

for p in model.parameters():                       # (4) a törzs fagyasztása
    p.requires_grad_(False)
model.fc = nn.Linear(model.fc.in_features, 3)      # új fej: 512 -> 3 (alapból requires_grad=True)

def to_model_input(x_gray):                        # x_gray: (N,1,24,24) float32, [0,1]
    x_rgb = x_gray.repeat(1, 3, 1, 1)              # (3) 1 csatorna -> 3 csatorna
    return preprocess(x_rgb)                       # (N,3,224,224), ImageNet-normalizált

trainable = [p for p in model.parameters() if p.requires_grad]
assert len(trainable) == 2                         # csak fc.weight és fc.bias
opt = torch.optim.SGD(trainable, lr=1e-2)
model.eval()                                       # a BatchNorm-statisztikák fagyasztva maradnak
