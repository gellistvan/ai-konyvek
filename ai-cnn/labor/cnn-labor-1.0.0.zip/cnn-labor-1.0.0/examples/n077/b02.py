# lab/n077/manual_check.py
import torch

dtype = torch.float64

x = torch.tensor([2.0, 1.0, -1.0, 1.0], dtype=dtype)
WB = torch.tensor([[1.0, 0.0, 2.0, -1.0],
                   [0.0, 1.0, -1.0, 1.0]], dtype=dtype)
WH = torch.tensor([[1.0, -1.0],
                   [2.0, 0.0],
                   [0.0, 1.0]], dtype=dtype, requires_grad=True)
y = torch.tensor(0)

def forward(wb, wh, freeze_backbone):
    wb = wb.detach()
    wb.requires_grad_(not freeze_backbone)
    h = wb @ x
    z = wh @ h
    loss = torch.nn.functional.cross_entropy(z.unsqueeze(0), y.unsqueeze(0))
    loss.backward()
    return h.detach(), loss.detach(), wb.grad, wh.grad

# Nem fagyasztott eset: mindkét gradiens létezik
h0, loss0, gWB0, gWH0 = forward(WB, WH.clone().detach().requires_grad_(True), False)
# Fagyasztott eset: csak a fej gradiense létezik
h1, loss1, gWB1, gWH1 = forward(WB, WH.clone().detach().requires_grad_(True), True)

assert torch.allclose(h0, torch.tensor([-1.0, 3.0], dtype=dtype), atol=1e-12)
assert torch.allclose(loss0, loss1, atol=1e-12)
p = torch.softmax(WH.detach() @ h0, dim=0)
g_h = WH.detach().T @ (p - torch.nn.functional.one_hot(y, 3).to(dtype))
expected_gWB = torch.outer(g_h, x)
assert gWB0 is not None
torch.testing.assert_close(gWB0, expected_gWB, rtol=1e-10, atol=1e-12)
# A pontos analitikus és autograd-gradiens alakja:
assert gWB0.shape == (2, 4) and gWB1 is None
assert gWH1 is not None and torch.allclose(gWH1, gWH0, atol=1e-12)
print("manual_check ok: frozen backbone -> WB.grad is None, WH.grad kept")

# (b) Fagyott backbone, de a bemenet gradienst igényel: a gradiens eljut x-ig.
xb = x.clone().requires_grad_(True)
zb = WH.detach() @ (WB @ xb)
torch.nn.functional.cross_entropy(zb.unsqueeze(0), y.unsqueeze(0)).backward()
torch.testing.assert_close(xb.grad, WB.T @ g_h, rtol=1e-10, atol=1e-12)
print("g_h =", [round(v, 5) for v in g_h.tolist()], " x.grad =", [round(v, 5) for v in xb.grad.tolist()])

# Ellenpélda: requires_grad_(False) után a régi .grad megmarad, és step() frissít.
w = torch.nn.Parameter(torch.tensor([1.0], dtype=dtype))
(w * 3.0).sum().backward()                      # w.grad = 3
w.requires_grad_(False)                         # "fagyasztás", de a grad nem törlődik
opt = torch.optim.SGD([w], lr=0.1)
opt.step()
print("fagyott w a step után:", w.item())       # 0.7: mégis változott
w.grad = None
opt.step()
assert abs(w.item() - 0.7) < 1e-12              # grad=None mellett már nem változik
