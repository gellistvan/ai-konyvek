# lab/n077/head_swap_lab.py
import random
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn

SEED = 20261020
LR = 1e-3
EPOCHS = 3
BASE = Path(__file__).resolve().parent      # lab/n077
DATA = BASE.parent / "data"                 # a közös GlyphLab adat: lab/data
CKPT = BASE / "mini_cnn_3class.pt"          # a labor saját kimenete

random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

class Block(nn.Module):
    def __init__(self, cin, cout):
        super().__init__()
        self.conv = nn.Conv2d(cin, cout, 3, padding=1)
        self.bn = nn.BatchNorm2d(cout)
        self.act = nn.ReLU()
        self.pool = nn.MaxPool2d(2)
    def forward(self, x):
        return self.pool(self.act(self.bn(self.conv(x))))

class MiniCNN(nn.Module):
    def __init__(self, num_classes=3):
        super().__init__()
        self.backbone = nn.Sequential(Block(1, 16), Block(16, 32))
        self.head = nn.Linear(32 * 6 * 6, num_classes)
    def forward(self, x):
        h = self.backbone(x).flatten(1)
        return self.head(h)

def load_glyphlab():
    for name in ("images.npy", "labels.npy", "metadata.csv"):
        if not (DATA / name).exists():
            raise FileNotFoundError(
                f"hiányzó GlyphLab adatfájl: {DATA / name}; "
                "a függelék A. szakasza szerinti data/ könyvtár kell")
    X = np.load(DATA / "images.npy").astype(np.float32)
    y = np.load(DATA / "labels.npy").astype(np.int64)
    meta = np.genfromtxt(DATA / "metadata.csv", delimiter=",", dtype=None,
                         names=True, encoding="utf-8")
    if X.shape != (len(y), 1, 24, 24):
        raise ValueError(f"várt képalak ({len(y)},1,24,24), kapott: {X.shape}")
    if not (len(meta) == len(X) == len(y)):
        raise ValueError("a metadata.csv és a tömbök hossza eltér")
    idx = meta["index"].astype(np.int64)
    if not np.array_equal(np.sort(idx), np.arange(len(X))):
        raise ValueError("a metadata.csv index oszlopa nem permutációja a tömbindexeknek")
    split = np.asarray(meta["split"]).astype(str)
    train_idx = idx[split == "train"]
    val_idx = idx[split == "val"]
    return X, y, train_idx, val_idx

def train_mini_cnn():
    X, y, tr, _ = load_glyphlab()
    model = MiniCNN()
    opt = torch.optim.Adam(model.parameters(), lr=LR)
    lossf = nn.CrossEntropyLoss()
    Xtr = torch.from_numpy(X[tr]); ytr = torch.from_numpy(y[tr])
    for ep in range(EPOCHS):
        model.train()
        for i in range(0, len(tr), 32):
            xb, yb = Xtr[i:i+32], ytr[i:i+32]
            opt.zero_grad()
            loss = lossf(model(xb), yb)
            loss.backward()
            opt.step()
    torch.save(model.state_dict(), CKPT)
    return model

def head_swap_probe():
    sd = torch.load(CKPT, weights_only=True)
    model = MiniCNN()
    model.load_state_dict(sd)               # teljes modell, 3 osztályos fej is
    # Fejcsere: a fejet újra inicializáljuk, a backbone súlyát megtartjuk.
    model.head = nn.Linear(32 * 6 * 6, 3)
    model.head.weight.data.normal_(0, 0.02)
    model.head.bias.data.zero_()
    # Backbone befagyasztás, optimizer csak a fejet látja.
    model.backbone.requires_grad_(False)
    opt = torch.optim.Adam(model.head.parameters(), lr=LR)
    print("optimizer param_groups:", len(opt.param_groups))
    print("trainable params:", sum(p.numel() for p in model.parameters() if p.requires_grad))
    # Buffer-kontroll: BatchNorm train módban frissül, eval módban nem.
    bn = model.backbone[0].bn
    bn.eval(); before = bn.running_mean.clone()
    _ = model.backbone(torch.zeros(1, 1, 24, 24))
    assert torch.equal(bn.running_mean, before), "eval mode: running buffer must not change"
    bn.train(); before = bn.running_mean.clone()
    _ = model.backbone(torch.zeros(1, 1, 24, 24))
    assert not torch.equal(bn.running_mean, before), "train mode: running buffer must change"
    # Gradiens-kontroll egyetlen lépésen; a befagyasztott backbone eval módban marad.
    model.train()
    model.backbone.eval()
    xb = torch.zeros(2, 1, 24, 24); yb = torch.tensor([0, 1])
    opt.zero_grad(); loss = nn.functional.cross_entropy(model(xb), yb); loss.backward()
    assert model.backbone[0].conv.weight.grad is None
    assert model.head.weight.grad is not None
    print("head_swap_probe ok: backbone frozen, head gradient exists, buffer rule verified")

if __name__ == "__main__":
    if not CKPT.exists():
        train_mini_cnn()
    head_swap_probe()
