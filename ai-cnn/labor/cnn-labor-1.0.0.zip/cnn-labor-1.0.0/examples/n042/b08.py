def forward(self, x):
    x = torch.relu(self.layers[0](x))
    return self.layers[1](x)
