# Az előző blokk m modelljére épül.
m.eval()
x0, n0 = m.ema_input_norm.clone(), int(m.n_seen)
m(torch.rand(4, 3))
assert torch.equal(m.ema_input_norm, x0) and int(m.n_seen) == n0   # eval alatt nem változik
