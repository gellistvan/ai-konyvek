# munkakönyvtár: lab/n042
import torch
import torch.nn as nn

class WeightedStats(nn.Module):
    """Affin réteg, amely az input normájának exponenciális
    mozgóátlagát pufferben tartja."""
    def __init__(self, d_in: int, d_out: int, alpha: float = 0.9):
        super().__init__()
        self.weight = nn.Parameter(torch.zeros(d_out, d_in))
        self.bias = nn.Parameter(torch.zeros(d_out))
        self.register_buffer('ema_input_norm', torch.tensor(0.0))
        self.register_buffer('n_seen', torch.tensor(0, dtype=torch.int64))
        self.alpha = alpha

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (N, d_in)
        z = torch.nn.functional.linear(x, self.weight, self.bias)  # (N, d_out)
        if self.training:   # a puffer csak tanítás közben frissül
            with torch.no_grad():
                mean_norm = x.norm(dim=1).mean()
                self.ema_input_norm.mul_(self.alpha).add_(mean_norm * (1.0 - self.alpha))
                self.n_seen += 1
        return z

m = WeightedStats(3, 2)
print([name for name, _ in m.named_parameters()])   # ['weight', 'bias']
print([name for name, _ in m.named_buffers()])      # ['ema_input_norm', 'n_seen']
print(sorted(m.state_dict().keys()))
# ['bias', 'ema_input_norm', 'n_seen', 'weight']
print(m.ema_input_norm.requires_grad)               # False
