import torch
import torch.nn as nn

class GatedScale(nn.Module):
    def __init__(self):
        super().__init__()
        self.logit_threshold = nn.Parameter(torch.tensor(0.0))
        self.register_buffer('pos_count', torch.tensor(0, dtype=torch.int64))

    def forward(self, x):
        # x: (N, 1)
        s = torch.sigmoid(self.logit_threshold)  # skalár tenzor
        y = x * s
        with torch.no_grad():
            if s.item() > 0.5:
                self.pos_count += 1
        return y

m = GatedScale()
x = torch.tensor([[1.0], [2.0]])
with torch.no_grad():
    y = m(x)
print(y)              # tensor([[0.5000], [1.0000]]), mert sigmoid(0)=0.5
print(m.pos_count)    # tensor(0), mert a feltétel hamis
print(len(list(m.parameters())))  # 1
print(sorted(m.state_dict().keys()))  # ['logit_threshold', 'pos_count']

# A sigma(t)>0,5 ág kontrollja: t=1,0 esetén sigma(1)≈0,731.
with torch.no_grad():
    m.logit_threshold.fill_(1.0)
    y2 = m(x)
print(m.pos_count)    # tensor(1)
assert int(m.pos_count) == 1
