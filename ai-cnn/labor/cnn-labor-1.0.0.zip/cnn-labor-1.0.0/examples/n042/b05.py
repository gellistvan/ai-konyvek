class Broken(nn.Module):
    def __init__(self):
        super().__init__()
        self.layers = [nn.Linear(3, 4), nn.Linear(4, 2)]

    def forward(self, x):
        for layer in self.layers:
            x = torch.relu(layer(x))
        return x
