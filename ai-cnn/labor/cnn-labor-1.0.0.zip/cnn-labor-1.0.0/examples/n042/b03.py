# munkakönyvtár: lab/n042
# futtatás: python n042_module_check.py
import torch
import torch.nn as nn

torch.manual_seed(0)
DEVICE = torch.device('cpu')
DTYPE = torch.float32

class MLP342(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(3, 4)
        self.fc2 = nn.Linear(4, 2)

    def forward(self, x):
        return self.fc2(torch.relu(self.fc1(x)))

model = MLP342().to(device=DEVICE, dtype=DTYPE)

n_params = sum(p.numel() for p in model.parameters())
print(n_params)                                    # 26
assert n_params == 26
print(model.state_dict()['fc1.weight'].shape)      # torch.Size([4, 3])
print(model.state_dict()['fc1.bias'].shape)        # torch.Size([4])
assert model.state_dict()['fc1.weight'].shape == (4, 3)
assert model.state_dict()['fc1.bias'].shape == (4,)
print(sorted(model.state_dict().keys()))
# ['fc1.bias', 'fc1.weight', 'fc2.bias', 'fc2.weight']
assert sorted(model.state_dict().keys()) == [
    'fc1.bias', 'fc1.weight', 'fc2.bias', 'fc2.weight']
print({str(p.device) for p in model.parameters()})  # {'cpu'}
print({p.dtype for p in model.parameters()})        # {torch.float32}
assert all(p.device == torch.device('cpu') for p in model.parameters())
assert all(p.dtype == torch.float32 for p in model.parameters())

optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
print([len(g['params']) for g in optimizer.param_groups])  # [4]
assert [len(g['params']) for g in optimizer.param_groups] == [4]

x = torch.ones(1, 3, device=DEVICE, dtype=DTYPE)
model.eval()
with torch.no_grad():
    y = model(x)
print(y.shape)                                     # torch.Size([1, 2])
assert y.shape == (1, 2)
print(model.training)                              # False
assert model.training is False

# train/eval eltérése egyetlen Dropout rétegen
drop = nn.Dropout(p=0.5)
drop.eval()
print(torch.equal(drop(x), x))                     # True
assert torch.equal(drop(x), x)
drop.train()
z = drop(x)
print(z.shape)                                     # torch.Size([1, 3])
assert z.shape == (1, 3)
# tanítási módban az aktív elemek 0 vagy 2; a pontos maszk seedfüggő
