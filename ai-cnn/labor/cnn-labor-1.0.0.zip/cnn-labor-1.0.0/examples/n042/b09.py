self.layers = [nn.Linear(3, 4), nn.Linear(4, 2)]
