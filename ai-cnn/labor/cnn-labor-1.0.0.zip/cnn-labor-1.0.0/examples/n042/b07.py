self.layers = nn.ModuleList([nn.Linear(3, 4), nn.Linear(4, 2)])
