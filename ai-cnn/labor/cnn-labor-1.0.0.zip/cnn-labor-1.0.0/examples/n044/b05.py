optimizer.zero_grad()
logits = model(x)
loss = criterion(logits, y)
loss.backward()
# néhány diagnosztikai nyomtatás
print(loss.item())
