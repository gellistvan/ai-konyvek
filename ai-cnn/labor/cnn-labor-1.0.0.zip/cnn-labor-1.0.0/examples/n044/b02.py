# lab/n044_train_step.py
import torch

torch.manual_seed(20261020)
torch.set_default_dtype(torch.float64)
device = torch.device("cpu")

d, K, N = 3, 2, 2
x = torch.tensor([[0.5, 1.0, -0.5],
                  [-1.0, 0.25, 2.0]], device=device)
y = torch.tensor([0, 1], dtype=torch.int64, device=device)

model = torch.nn.Linear(d, K, bias=True).to(device)
with torch.no_grad():
    model.weight.copy_(torch.tensor([[0.2, -0.4, 0.1],
                                      [0.3, 0.15, -0.2]], device=device))
    model.bias.copy_(torch.tensor([0.05, -0.05], device=device))
criterion = torch.nn.CrossEntropyLoss(reduction="mean")
optimizer = torch.optim.SGD(model.parameters(), lr=0.25)

# A lépés sorrendje
optimizer.zero_grad()
logits = model(x)
loss = criterion(logits, y)
loss.backward()

# Kézi gradiens a levezetett képletből
p = torch.softmax(logits, dim=1)
y_onehot = torch.nn.functional.one_hot(y, num_classes=K).to(torch.float64)
G = (p - y_onehot) / N

expected_grad_w = G.T @ x
expected_grad_b = G.sum(dim=0)

print(torch.allclose(model.weight.grad, expected_grad_w, rtol=1e-10, atol=1e-10))
print(torch.allclose(model.bias.grad, expected_grad_b, rtol=1e-10, atol=1e-10))

# Várt SGD-frissítés ellenőrzése
with torch.no_grad():
    w0 = model.weight.data.clone()
    b0 = model.bias.data.clone()
    expected_w = w0 - 0.25 * expected_grad_w
    expected_b = b0 - 0.25 * expected_grad_b

optimizer.step()

print(torch.allclose(model.weight.data, expected_w, rtol=1e-10, atol=1e-10))
print(torch.allclose(model.bias.data, expected_b, rtol=1e-10, atol=1e-10))

assert torch.allclose(model.weight.grad, expected_grad_w, rtol=1e-10, atol=1e-10)
assert torch.allclose(model.bias.grad, expected_grad_b, rtol=1e-10, atol=1e-10)
assert torch.allclose(model.weight.data, expected_w, rtol=1e-10, atol=1e-10)
assert torch.allclose(model.bias.data, expected_b, rtol=1e-10, atol=1e-10)

# Véges-gradiens védelem: a step előtt állítsuk meg a nem véges futást
def assert_finite_grad(model):
    for name, param in model.named_parameters():
        if param.grad is None:
            continue
        if not torch.isfinite(param.grad).all():
            raise RuntimeError(f"Nem véges gradiens a {name} paraméterben.")

model.zero_grad()
# Új forward gráf: a korábbi logits gráfját a backward már felszabadította,
# a model(x) * nan szorzás viszont differenciálható, ezért a bad_loss.backward()
# végrehajtható, és a gradiens NaN lesz.
bad_logits = model(x) * float("nan")
bad_loss = criterion(bad_logits, y)
bad_loss.backward()
try:
    assert_finite_grad(model)
    optimizer.step()
except RuntimeError as e:
    print("Tervezett leállás:", e)
