torch.set_default_dtype(torch.float64)
model = torch.nn.Linear(1, 2)
with torch.no_grad():
    model.weight.copy_(torch.tensor([[0.2], [-0.3]]))
    model.bias.copy_(torch.tensor([0.1, 0.0]))
x = torch.tensor([[0.5]])
y = torch.tensor([1], dtype=torch.int64)
criterion = torch.nn.CrossEntropyLoss(reduction="mean")
optimizer = torch.optim.SGD(model.parameters(), lr=0.5)

value = train_step(model, x, y, criterion, optimizer)
print(value)
print(model.weight.data.view(-1).tolist())
print(model.bias.data.view(-1).tolist())
