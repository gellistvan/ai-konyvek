def train_step(model, x, y, criterion, optimizer):
    optimizer.zero_grad()
    logits = model(x)
    loss = criterion(logits, y)
    loss.backward()
    for name, param in model.named_parameters():
        if param.grad is None:
            continue
        if not torch.isfinite(param.grad).all():
            raise RuntimeError(f"{name}: nem véges gradiens")
    optimizer.step()
    return loss.item()
