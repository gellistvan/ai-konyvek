w_before = model.weight.data.clone()
optimizer.zero_grad()
logits = model(x)
loss = criterion(logits, y)
loss.backward()
# NINCS optimizer.step()
print(model.weight.grad is not None)             # True, a gradiens kiszámult
print(torch.equal(w_before, model.weight.data))  # True, a súly változatlan
