N, K = 4, 3
logits = torch.randn(N, K, device="cpu", dtype=torch.float32)
target_onehot = torch.zeros(N, K, device="cpu", dtype=torch.float32)
target_onehot.scatter_(1, torch.randint(0, K, (N, 1), device="cpu"), 1.0)
loss = torch.nn.functional.binary_cross_entropy_with_logits(logits, target_onehot)
