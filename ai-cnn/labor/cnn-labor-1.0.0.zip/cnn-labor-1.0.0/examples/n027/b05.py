target_class = target_onehot.argmax(dim=1)  # int64, shape (N,)
loss = torch.nn.functional.cross_entropy(logits, target_class)
