import numpy as np

def softplus(z):
    # logaddexp stabilan, elágazás és túlcsordulás nélkül
    return np.logaddexp(0.0, z)

def bce_with_logits(z, y):
    # z, y: float64 tömbök; y elemei {0,1}
    return softplus(z) - y * z

# Ellenőrzés
for z, y in [(0.0, 1.0), (1.0, 0.0)]:
    val = bce_with_logits(np.array(z), np.array(y))
    print(z, y, val)  # 0.0 1.0 0.69314718; 1.0 0.0 1.31326169
