# labor/n027_shape_check.py
import torch

torch.manual_seed(20261020)
device = torch.device("cpu")
dtype = torch.float32

# Bináris: N=2
z_bin = torch.zeros(2, 1, device=device, dtype=dtype)
y_bin = torch.tensor([[1.0], [0.0]], device=device, dtype=dtype)
assert z_bin.shape == y_bin.shape == (2, 1)
assert z_bin.dtype == y_bin.dtype == torch.float32
loss_bin = torch.nn.functional.binary_cross_entropy_with_logits(z_bin, y_bin)
print("bináris loss, N=2:", loss_bin.item())  # mért: 0.6931

# Multilabel: N=1, K=2
z_ml = torch.tensor([[1.0, -2.0]], device=device, dtype=dtype)
y_ml = torch.tensor([[1.0, 0.0]], device=device, dtype=dtype)
assert z_ml.shape == y_ml.shape == (1, 2)
assert z_ml.dtype == y_ml.dtype == torch.float32
loss_ml = torch.nn.functional.binary_cross_entropy_with_logits(z_ml, y_ml)
print("multilabel loss, N=1, K=2:", loss_ml.item())  # mért: 0.2201

# Regresszió: N=1, d_out=2
z_reg = torch.tensor([[1.5, 4.5]], device=device, dtype=dtype)
y_reg = torch.tensor([[2.0, 4.0]], device=device, dtype=dtype)
assert z_reg.shape == y_reg.shape == (1, 2)
assert z_reg.dtype == y_reg.dtype == torch.float32
loss_reg = torch.nn.functional.mse_loss(z_reg, y_reg)
print("MSE loss, N=1, d_out=2:", loss_reg.item())  # mért: 0.25
assert abs(loss_bin.item() - 0.6931) < 1e-4
assert abs(loss_ml.item() - 0.2201) < 1e-4
assert abs(loss_reg.item() - 0.25) < 1e-6
print("shape- és dtype-ellenőrzés: rendben")
print("értékellenőrzés: a lossok a kézi példától 1e-4-en belül vannak")
