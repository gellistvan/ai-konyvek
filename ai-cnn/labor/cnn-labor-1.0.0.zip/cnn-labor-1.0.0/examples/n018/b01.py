# lab/n018_likelihood.py
# Futtatás: python lab/n018_likelihood.py
import numpy as np

rng = np.random.default_rng(20261020)

# --- 1. Kategorikus minta és MLE ---
p_true = np.array([0.5, 0.3, 0.2, 0.0], dtype=np.float64)
K = p_true.size
N = 200
y = rng.choice(K, size=N, p=p_true)          # int64 osztályindexek
counts = np.bincount(y, minlength=K)
p_hat = counts / N                           # MLE kategorikus modellre

print("counts     :", counts)
print("p_hat      :", p_hat)
print("sum        :", p_hat.sum())
print("nemnegativ :", np.all(p_hat >= 0.0))

# A generáló p negyedik komponense 0, ezért a minta sem tartalmazhatja.
assert counts[3] == 0
assert p_hat[3] == 0.0
assert np.isclose(p_hat.sum(), 1.0, atol=1e-12)

# --- 2. Stabil Bernoulli log-likelihood a szélekkel ---
def bernoulli_loglik(theta, s, n):
    if theta == 0.0:
        return 0.0 if s == 0 else -np.inf
    if theta == 1.0:
        return 0.0 if s == n else -np.inf
    return s * np.log(theta) + (n - s) * np.log(1.0 - theta)

# Szélső konvenciók ellenőrzése
assert bernoulli_loglik(0.0, 0, 10) == 0.0
assert bernoulli_loglik(1.0, 10, 10) == 0.0
assert bernoulli_loglik(0.0, 1, 10) == -np.inf

# A Bernoulli-MLE helyének ellenőrzése rácsmaximummal: s/N = 0.6
grid = np.linspace(0.0, 1.0, 1001)
ll_grid = np.array([bernoulli_loglik(t, 3, 5) for t in grid])
assert np.isclose(grid[np.argmax(ll_grid)], 0.6, atol=1e-3)

# --- 3. Egyenletes [0,1] momentumok: zárt képlet és midpoint Riemann ---
a_val, b_val = 0.0, 1.0
n_bins = 1000
h = (b_val - a_val) / n_bins
mid = a_val + (np.arange(n_bins, dtype=np.float64) + 0.5) * h
density = 1.0 / (b_val - a_val)

Ex_num = np.sum(mid * density * h)
Ex2_num = np.sum(mid**2 * density * h)
Ex_analytic = (a_val + b_val) / 2.0
Ex2_analytic = (a_val**2 + a_val * b_val + b_val**2) / 3.0
var_analytic = (b_val - a_val)**2 / 12.0

print("Ex numerikus  :", Ex_num)
print("Ex analitikus :", Ex_analytic)
print("Ex2 numerikus :", Ex2_num)
print("Ex2 analitikus:", Ex2_analytic)
print("abs hiba Ex   :", abs(Ex_num - Ex_analytic))
print("Var numerikus :", Ex2_num - Ex_num**2)
print("Var analitikus:", var_analytic)

# Ellenőrzés: a midpoint szabály lineárisra pontos, a varianciahiba ~1/n_bins^2
assert np.isclose(Ex_num, Ex_analytic, atol=1e-12, rtol=0.0)
assert np.isclose(Ex2_num, Ex2_analytic, atol=1e-6, rtol=0.0)
assert abs((Ex2_num - Ex_num**2) - var_analytic) < 1e-6
print("ellenorzes: a momentumok a kezi integraltol a megadott tolerancian belul vannak")
