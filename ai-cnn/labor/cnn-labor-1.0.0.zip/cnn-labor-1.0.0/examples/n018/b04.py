import numpy as np

def categorical_mle(y, K):
    y = np.asarray(y)
    if K <= 0:
        raise ValueError("K-nak pozitívnak kell lennie")
    if y.size == 0:
        raise ValueError("az y minta nem lehet ures")
    if not np.issubdtype(y.dtype, np.integer):
        raise TypeError("az y cimkei egesz szamok legyenek")
    if np.any(y < 0) or np.any(y >= K):
        raise ValueError("a cimkeknek 0 es K-1 koze kell esniuk")
    counts = np.bincount(y, minlength=K).astype(np.float64)
    return counts / counts.sum()

y = np.array([0, 0, 2], dtype=np.int64)
p = categorical_mle(y, 3)
assert p.shape == (3,)
assert np.all(p >= 0.0)
assert np.isclose(p.sum(), 1.0, atol=1e-12)
assert p[1] == 0.0 and np.isclose(p[0], 2.0 / 3.0)

# Hibas bemenetek: mindegyiknek kivetelt kell dobnia
for bad_y, bad_K in [(np.array([], dtype=np.int64), 3),
                     (np.array([0, 3], dtype=np.int64), 3),
                     (np.array([0, -1], dtype=np.int64), 3)]:
    try:
        categorical_mle(bad_y, bad_K)
    except ValueError:
        pass
    else:
        raise AssertionError("hibas bemenetre nem jelzett hibat")
