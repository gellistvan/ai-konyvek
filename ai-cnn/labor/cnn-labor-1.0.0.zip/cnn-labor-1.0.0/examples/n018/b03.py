def bad_mle(s, N):
    if s == 0:
        return 0.0
    if s == N:
        return 1.0
    return s / (N - s)   # HIBA
