# lab/n029_simulation.py
import numpy as np

rng = np.random.default_rng(20261020)

def p_y1(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-2.0 * x))

def sample(n: int, rng: np.random.Generator):
    x = rng.uniform(-2.0, 2.0, size=n)
    y = (rng.random(size=n) < p_y1(x)).astype(np.int64)
    return x, y

def loss01(yhat: np.ndarray, y: np.ndarray) -> float:
    return float(np.mean(yhat != y))

def best_threshold(x: np.ndarray, y: np.ndarray):
    """A 0-1 hibát minimalizáló tau küszöb, O(N log N) időben."""
    order = np.argsort(x)
    xs, ys = x[order], y[order]
    n = len(xs)
    # Két szélső eset: mindent 1-nek, illetve mindent 0-nak mondunk.
    # A visszaadott tau ilyenkor -inf, illetve +inf, ami a szélső döntést kódolja.
    best_tau = -np.inf
    best_loss = float(np.mean(ys == 0))  # mindent 1-nek mondunk
    loss_all0 = float(np.mean(ys == 1))  # mindent 0-nak mondunk
    if loss_all0 < best_loss:
        best_loss = loss_all0
        best_tau = np.inf
    # Rendezett minta: csak a szomszédos, különböző értékek közötti küszöbök
    # jelöltek. A hibát prefixösszegekkel számoljuk, minden jelölt O(1).
    pos_cum = np.cumsum(ys == 1)
    tot_pos = int(pos_cum[-1])
    pos_after = tot_pos - pos_cum[:-1]
    neg_after = (n - 1 - np.arange(n - 1)) - pos_after
    err = pos_cum[:-1] + neg_after
    distinct = xs[1:] > xs[:-1]
    err_masked = np.where(distinct, err, n + 1)
    i = int(np.argmin(err_masked))
    if err_masked[i] <= n:
        tau = 0.5 * (xs[i] + xs[i + 1])
        l = float(err_masked[i]) / n
        if l < best_loss:
            best_loss = l
            best_tau = tau
    return best_tau, best_loss

sizes = [10, 20, 50, 100, 200, 500]
reps = 200
Xtest, ytest = sample(20_000, rng)
assert Xtest.shape == (20_000,) and ytest.shape == (20_000,)
bayes_risk_est = float(np.mean(np.minimum(p_y1(Xtest), 1.0 - p_y1(Xtest))))
assert 0.0 <= bayes_risk_est <= 0.5
print(f"bayes_risk_est = {bayes_risk_est:.4f}")
for n in sizes:
    train_errs = []
    test_errs = []
    for _ in range(reps):
        Xtr, ytr = sample(n, rng)
        t, _ = best_threshold(Xtr, ytr)
        yhat_tr = (Xtr > t).astype(np.int64)
        yhat_te = (Xtest > t).astype(np.int64)
        train_errs.append(loss01(yhat_tr, ytr))
        test_errs.append(loss01(yhat_te, ytest))
    assert 0.0 <= np.mean(train_errs) <= 1.0
    assert 0.0 <= np.mean(test_errs) <= 1.0
    print(f"N={n:4d}  train_err={np.mean(train_errs):.4f} "
          f"test_err={np.mean(test_errs):.4f} "
          f"test_sd={np.std(test_errs):.4f}")
