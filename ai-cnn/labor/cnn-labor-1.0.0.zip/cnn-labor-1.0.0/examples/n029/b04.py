t, _ = best_threshold(Xtr, ytr)
yhat_te = (Xtest > t).astype(np.int64)
test_errs.append(loss01(yhat_te, ytest))
