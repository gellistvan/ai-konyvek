eps = 0.05
bound = 2.0 * np.exp(-2.0 * n * eps**2)
exceed = float(np.mean(np.abs(np.array(train_errs) - np.array(test_errs)) >= eps))
print(f"N={n:4d}  Hoeffding_bound={bound:.4f}  excess_freq={exceed:.4f}")
