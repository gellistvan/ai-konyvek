# lab/n043_dataset.py
import csv
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import Dataset

DATA_DIR = Path(__file__).resolve().parent / "data"

class GlyphLabDataset(Dataset):
    """GlyphLab: kép, label, mask és scene_id együtt, split szerint szűrve.

    transform: opcionális függvény, amely a (2,24,24) alakú, egymásra rakott
    [kép, maszk] tensort kapja és ugyanilyet ad vissza; így egy geometriai
    transzformáció a képet és a maszkot együtt, ugyanúgy alakítja át."""
    def __init__(self, root: str | Path = DATA_DIR, split: str | None = None,
                 transform=None):
        self.root = Path(root)
        self.transform = transform
        images = np.load(self.root / "images.npy")      # (360,1,24,24) float32
        labels = np.load(self.root / "labels.npy")      # (360,) int64
        masks = np.load(self.root / "masks.npy")        # (360,1,24,24) uint8
        self.images = images
        self.labels = labels
        self.masks = masks

        with open(self.root / "metadata.csv", newline="", encoding="utf-8") as f:
            rows = list(csv.reader(f))
        header = rows[0]
        expected = ["index", "scene_id", "view_id", "label", "split",
                    "xmin", "ymin", "xmax", "ymax"]
        if header != expected:
            raise ValueError("metadata fejléc nem egyezik")
        recs = rows[1:]
        if not (len(images) == len(labels) == len(masks) == len(recs)):
            raise ValueError("eltérő hosszúságú adattömb és metadata")
        idx = np.array([int(r[0]) for r in recs], dtype=np.int64)
        if not np.array_equal(idx, np.arange(len(images))):
            raise ValueError("a metadata indexe nem egyezik a tömb indexével")
        # a scene_id szöveg (pl. "G0-0003"); int64 kódot a rendezett egyedi értékek adnak
        self.scene_names = np.array([r[1] for r in recs], dtype=object)
        _, codes = np.unique(self.scene_names.astype(str), return_inverse=True)
        self.scene_ids = codes.astype(np.int64)
        self.splits = np.array([r[4] for r in recs], dtype=object)

        if split is not None:
            keep = self.splits == split
            self.images = self.images[keep]
            self.labels = self.labels[keep]
            self.masks = self.masks[keep]
            self.scene_ids = self.scene_ids[keep]
            self.scene_names = self.scene_names[keep]
            self.splits = self.splits[keep]

    def __len__(self):
        return len(self.images)

    def __getitem__(self, i):
        img = torch.from_numpy(self.images[i])
        lab = torch.tensor(self.labels[i], dtype=torch.int64)
        msk = torch.from_numpy(self.masks[i])
        sid = torch.tensor(self.scene_ids[i], dtype=torch.int64)
        if self.transform is not None:
            joint = self.transform(torch.cat([img, msk.to(img.dtype)], dim=0))  # (2,24,24)
            img, msk = joint[:1].contiguous(), joint[1:].round().to(torch.uint8)
        return img, lab, msk, sid
