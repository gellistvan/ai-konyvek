# lab/n043_check.py
import csv
from collections import defaultdict

import numpy as np
from torch.utils.data import DataLoader
from n043_dataset import DATA_DIR, GlyphLabDataset

if __name__ == "__main__":
    ds_train = GlyphLabDataset(DATA_DIR, split="train")
    ds_val = GlyphLabDataset(DATA_DIR, split="val")
    ds_test = GlyphLabDataset(DATA_DIR, split="test")
    print("hossz:", len(ds_train), len(ds_val), len(ds_test))
    assert (len(ds_train), len(ds_val), len(ds_test)) == (240, 60, 60)

    img, lab, msk, sid = ds_train[0]
    print("elem:", img.shape, img.dtype, lab.shape, lab.dtype,
          msk.shape, msk.dtype, sid.shape, sid.dtype)
    print("tartomány:", float(img.min()), float(img.max()),
          int(msk.min()), int(msk.max()))
    lo = min(float(ds.images.min()) for ds in (ds_train, ds_val, ds_test))
    hi = max(float(ds.images.max()) for ds in (ds_train, ds_val, ds_test))
    print("teljes pixel tartomány:", lo, hi)
    assert lo >= 0.0 and hi <= 1.0
    assert all(set(np.unique(ds.masks)) <= {0, 1}
               for ds in (ds_train, ds_val, ds_test))

    loader = DataLoader(ds_train, batch_size=4, shuffle=False)
    batch = next(iter(loader))
    for name, x in zip(["image", "label", "mask", "scene_id"], batch):
        print(name, tuple(x.shape), x.dtype)
    assert [tuple(x.shape) for x in batch] == [(4, 1, 24, 24), (4,),
                                               (4, 1, 24, 24), (4,)]

    scene_split = {}
    with open(DATA_DIR / "metadata.csv", newline="", encoding="utf-8") as f:
        for r in list(csv.reader(f))[1:]:
            s, sp = r[1], r[4]          # scene_id szövegként
            if s in scene_split and scene_split[s] != sp:
                raise SystemExit("INVARIANTS SÉRÜL")
            scene_split[s] = sp
    print("egyedi scene:", len(scene_split))
    assert len(scene_split) == 180
    splits = defaultdict(int)
    for s in scene_split.values():
        splits[s] += 1
    print("scene per split:", dict(splits))
    assert dict(splits) == {"train": 120, "val": 30, "test": 30}
