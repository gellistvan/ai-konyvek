def random_hflip(x, p=0.5):
    # véletlen vízszintes tükrözés a (2,24,24) [kép, maszk] tensoron
    return torch.flip(x, dims=(-1,)) if torch.rand(()) < p else x

val_ds = GlyphLabDataset(DATA_DIR, split="val", transform=random_hflip)
val_loader = DataLoader(val_ds, batch_size=4, shuffle=False)
