import random

import numpy as np
import torch
from torch.utils.data import DataLoader

g = torch.Generator()
g.manual_seed(20261020)

def seed_worker(worker_id):
    worker_seed = torch.initial_seed() % 2**32
    np.random.seed(worker_seed)
    random.seed(worker_seed)

# ds: a fent definiált GlyphLabDataset példány
loader = DataLoader(ds, batch_size=4, shuffle=True,
                    num_workers=2, generator=g,
                    worker_init_fn=seed_worker)
