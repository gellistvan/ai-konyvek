import torch
from torch.utils.data import Dataset, DataLoader

class VariableLength(Dataset):
    def __len__(self):
        return 3

    def __getitem__(self, i):
        return torch.arange(i + 1)   # 1, 2, 3 hosszú vektor

ds = VariableLength()
print(ds[0].shape, ds[1].shape, ds[2].shape)
# torch.Size([1]) torch.Size([2]) torch.Size([3])
list(DataLoader(ds, batch_size=2))
# RuntimeError: stack expects each tensor to be equal size,
# but got [1] at entry 0 and [2] at entry 1
