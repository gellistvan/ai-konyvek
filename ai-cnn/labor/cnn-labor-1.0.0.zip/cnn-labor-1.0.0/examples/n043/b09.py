torch.manual_seed(0)
bad = GlyphLabDataset(DATA_DIR, split="val", transform=random_hflip)
print(any(not torch.equal(bad[0][0], bad[0][0]) for _ in range(20)))   # True: véletlen
good = GlyphLabDataset(DATA_DIR, split="val")                              # javítva
print(all(torch.equal(good[0][0], good[0][0]) for _ in range(20)))     # True: determinisztikus
a = torch.cat([b[0] for b in DataLoader(good, batch_size=4)])
c = torch.cat([b[0] for b in DataLoader(good, batch_size=4)])
print(torch.equal(a, c))                                                  # True
