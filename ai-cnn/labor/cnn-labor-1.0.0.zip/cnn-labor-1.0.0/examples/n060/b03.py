# munkakönyvtár: lab/
# futtatás: python f3_hand_check.py
import torch

def conv_valid_2x2(X, K):
    Y = torch.zeros(2, 2, dtype=torch.float64)
    for i in range(2):
        for j in range(2):
            Y[i, j] = (X[i:i+2, j:j+2] * K).sum()
    return Y

X = torch.tensor([[1., 2., 3.], [4., 5., 6.], [7., 8., 9.]],
                  dtype=torch.float64)
K = torch.tensor([[0.5, -0.5], [1.0, 0.25]], dtype=torch.float64)
eps = 1e-6
L_of = lambda A: 0.5 * (conv_valid_2x2(A, K)**2).sum()
Xp = X.clone(); Xp[1, 1] += eps
Xm = X.clone(); Xm[1, 1] -= eps
grad = (L_of(Xp) - L_of(Xm)) / (2 * eps)
assert abs(grad - 7.8125) < 1e-5, f"eltérés: {grad - 7.8125}"
print(f"grad = {grad:.8f}, elvárt 7.8125")
