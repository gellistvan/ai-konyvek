# munkakönyvtár: lab/
# futtatás: python gradcheck_protocol.py
import json
import torch

torch.manual_seed(20261020)

def conv2d_forward(X, K, b, stride=1, pad=0, dilation=1):
    N, C, H, W = X.shape
    O, Ck, kH, kW = K.shape
    assert Ck == C, "a labor csak groups=1-et tamogat"
    Ho = (H + 2*pad - dilation*(kH - 1) - 1)//stride + 1
    Wo = (W + 2*pad - dilation*(kW - 1) - 1)//stride + 1
    Y = torch.zeros(N, O, Ho, Wo, dtype=torch.float64)
    for n in range(N):
        for o in range(O):
            for i in range(Ho):
                for j in range(Wo):
                    s = 0.0
                    for c in range(C):
                        for p in range(kH):
                            for q in range(kW):
                                ii = i*stride - pad + p*dilation
                                jj = j*stride - pad + q*dilation
                                if 0 <= ii < H and 0 <= jj < W:
                                    s += X[n, c, ii, jj].item() * K[o, c, p, q].item()
                    Y[n, o, i, j] = s + b[o].item()
    return Y

def conv2d_backward_input(Y, K, X_shape, stride=1, pad=0, dilation=1):
    N, O, Ho, Wo = Y.shape
    _, _, kH, kW = K.shape
    N, C, H, W = X_shape
    dX = torch.zeros(N, C, H, W, dtype=torch.float64)
    for n in range(N):
        for c in range(C):
            for i in range(H):
                for j in range(W):
                    s = 0.0
                    for o in range(O):
                        for p in range(kH):
                            for q in range(kW):
                                # Y_{n,o,r,s} járulék, ahol r*stride - pad + p*dilation == i
                                # r = (i + pad - p*dilation)/stride, ha egész
                                if (i + pad - p*dilation) % stride != 0:
                                    continue
                                r = (i + pad - p*dilation)//stride
                                if (j + pad - q*dilation) % stride != 0:
                                    continue
                                s_ = (j + pad - q*dilation)//stride
                                if 0 <= r < Ho and 0 <= s_ < Wo:
                                    s += Y[n, o, r, s_].item() * K[o, c, p, q].item()
                    dX[n, c, i, j] = s
    return dX

def conv2d_backward_weight(X, Y, K_shape, stride=1, pad=0, dilation=1):
    N, C, H, W = X.shape
    N, O, Ho, Wo = Y.shape
    O, Cg, kH, kW = K_shape
    assert Cg == C, "a labor csak groups=1-et tamogat"
    dK = torch.zeros(K_shape, dtype=torch.float64)
    db = torch.zeros(O, dtype=torch.float64)
    for o in range(O):
        for c in range(Cg):
            for p in range(kH):
                for q in range(kW):
                    s = 0.0
                    for n in range(N):
                        for i in range(Ho):
                            for j in range(Wo):
                                ii = i*stride - pad + p*dilation
                                jj = j*stride - pad + q*dilation
                                if 0 <= ii < H and 0 <= jj < W:
                                    s += X[n, c, ii, jj].item() * Y[n, o, i, j].item()
                    dK[o, c, p, q] = s
        db[o] = Y[:, o, :, :].sum().item()
    return dK, db

def loss_of(X, K, b, stride, pad, dilation):
    Y = conv2d_forward(X, K, b, stride, pad, dilation)
    return 0.5 * (Y**2).sum()

def finite_difference_flat(X, K, b, stride, pad, dilation, eps=1e-6):
    # a paraméterek lapított vektorán centrális differencia
    flat = torch.cat([X.reshape(-1), K.reshape(-1), b.reshape(-1)]).detach().clone()
    grad = torch.zeros_like(flat)
    for j in range(flat.numel()):
        orig = flat[j].item()
        flat[j] = orig + eps
        Lp = loss_of(flat[:X.numel()].reshape(X.shape),
                     flat[X.numel():X.numel()+K.numel()].reshape(K.shape),
                     flat[-b.numel():], stride, pad, dilation)
        flat[j] = orig - eps
        Lm = loss_of(flat[:X.numel()].reshape(X.shape),
                     flat[X.numel():X.numel()+K.numel()].reshape(K.shape),
                     flat[-b.numel():], stride, pad, dilation)
        flat[j] = orig
        grad[j] = (Lp - Lm)/(2*eps)
    return grad

def rel_err(a, n, atol=1e-12):
    a = float(a); n = float(n)
    return abs(a - n) / max(abs(a), abs(n), atol)

def run_case(shape, kshape, stride, pad, dilation, tag):
    N, C, H, W = shape
    O = kshape[0]
    X = torch.rand(N, C, H, W, dtype=torch.float64) * 2 - 1
    K = (torch.rand(*kshape, dtype=torch.float64) * 2 - 1) / (C * kshape[2] * kshape[3])**0.5
    b = torch.rand(O, dtype=torch.float64) * 0.2 - 0.1

    # 1. analitikus
    Y = conv2d_forward(X, K, b, stride, pad, dilation)
    dX = conv2d_backward_input(Y, K, X.shape, stride, pad, dilation)
    dK, db = conv2d_backward_weight(X, Y, K.shape, stride, pad, dilation)
    anal = torch.cat([dX.reshape(-1), dK.reshape(-1), db.reshape(-1)])

    # 2. numerikus
    num = finite_difference_flat(X, K, b, stride, pad, dilation)

    # 3. autograd
    Xa = X.clone().requires_grad_(True)
    Ka = K.clone().requires_grad_(True)
    ba = b.clone().requires_grad_(True)
    Ya = torch.nn.functional.conv2d(Xa, Ka, ba, stride=stride,
                                     padding=pad, dilation=dilation)
    La = 0.5 * (Ya**2).sum()
    grads = torch.autograd.grad(La, [Xa, Ka, ba])
    auto = torch.cat([g.reshape(-1) for g in grads])
    e_y = float((Y - Ya.detach()).abs().max())

    # relatív hibák
    e_an = max(rel_err(a, n) for a, n in zip(anal, num))
    e_aa = max(rel_err(a, n) for a, n in zip(anal, auto))
    e_na = max(rel_err(n, a) for n, a in zip(num, auto))
    return {"tag": tag, "shape": list(shape), "kernel_shape": list(kshape),
            "stride": stride, "padding": pad, "dilation": dilation,
            "max_abs_forward_vs_autograd": e_y,
            "max_rel_anal_vs_numeric": e_an,
            "max_rel_anal_vs_autograd": e_aa,
            "max_rel_numeric_vs_autograd": e_na,
            "checked_scalar_coordinates": X.numel() + K.numel() + b.numel()}

cases = [
    ((1, 1, 3, 3), (1, 1, 2, 2), 1, 0, 1, "small_stride1"),
    ((2, 2, 6, 6), (3, 2, 3, 3), 1, 1, 1, "padded_batch"),
    ((1, 1, 7, 7), (1, 1, 3, 3), 2, 0, 1, "stride2"),
    ((1, 1, 6, 6), (1, 1, 2, 2), 1, 0, 2, "dilation2"),
]

report = {"protocol_version": "1.0", "dtype": "float64",
          "finite_difference": "central", "eps": 1e-6,
          "relative_error_formula": "|a-n|/max(|a|,|n|,1e-12)",
          "cases": [run_case(*c) for c in cases]}
report["all_passed_tol_1e-5"] = all(
    max(c[k] for k in ("max_rel_anal_vs_numeric",
                       "max_rel_anal_vs_autograd",
                       "max_rel_numeric_vs_autograd")) < 1e-5
    and c["max_abs_forward_vs_autograd"] < 1e-12
    for c in report["cases"])
assert report["all_passed_tol_1e-5"], report["cases"]

with open("gradcheck_protocol.json", "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2, ensure_ascii=False)
print(json.dumps(report, indent=2, ensure_ascii=False)[:1200])
