import numpy as np
w = np.array([0.5, -0.5], dtype=np.float64)
b = 0.5
x = np.array([1.0, 2.0], dtype=np.float64)
y = 1.0
eta = 0.1
s = float(w @ x + b)
assert y * s <= 0.0
w += eta * y * x
b += eta * y
assert np.allclose(w, [0.6, -0.3], atol=1e-12)
assert np.isclose(b, 0.6, atol=1e-12)
