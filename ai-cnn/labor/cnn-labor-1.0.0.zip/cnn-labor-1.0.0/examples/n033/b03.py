import numpy as np
X_and = np.array([[0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]])
y_and = np.array([-1.0, -1.0, -1.0, 1.0])
w = np.zeros(2)
eta = 1.0
for _ in range(50):
    for x_i, y_i in zip(X_and, y_and):
        s = float(w @ x_i)      # bias hiányzik a score-ból
        if y_i * s <= 0.0:
            w += eta * y_i * x_i
            # b += eta * y_i   # a bias frissítése kimaradt
