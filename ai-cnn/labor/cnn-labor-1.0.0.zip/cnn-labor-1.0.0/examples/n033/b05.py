import numpy as np
X_and = np.array([[0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]])
y_and = np.array([-1.0, -1.0, -1.0, 1.0])
w = np.zeros(2)
b = 0.0
eta = 1.0
for _ in range(50):
    errors = 0
    for x_i, y_i in zip(X_and, y_and):
        s = float(w @ x_i + b)
        if y_i * s <= 0.0:
            w += eta * y_i * x_i
            b += eta * y_i
            errors += 1
    if errors == 0:
        break
pred = np.where(X_and @ w + b >= 0.0, 1.0, -1.0)
print(f"w={w}, b={b}, hiba={int(np.sum(pred != y_and))}")
assert np.array_equal(pred, y_and)
