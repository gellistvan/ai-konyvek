# lab/n033_perceptron/perceptron_lab.py
# Futtatás: python perceptron_lab.py
import numpy as np

def train_perceptron(X, y, eta=1.0, max_epochs=100, seed=20261020):
    """Perceptron-tanítás. X: (N,d) float64, y: (N,) float64 ±1."""
    rng = np.random.default_rng(seed)
    d = X.shape[1]
    w = np.zeros(d, dtype=X.dtype)
    b = 0.0
    for epoch in range(max_epochs):
        idx = rng.permutation(len(y))
        errors = 0
        for i in idx:
            x_i = X[i]
            y_i = y[i]
            s = float(np.dot(w, x_i) + b)
            # A határpontot is hibának tekintjük: y_i*s <= 0.
            if y_i * s <= 0.0:
                w += eta * y_i * x_i
                b += eta * y_i
                errors += 1
        if errors == 0:
            return w, b, epoch + 1, True
    return w, b, max_epochs, False

# AND: lineárisan szeparálható tanítóhalmaz
X_and = np.array(
    [[0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]],
    dtype=np.float64,
)
y_and = np.array([-1.0, -1.0, -1.0, 1.0], dtype=np.float64)

w_and, b_and, epochs_and, conv_and = train_perceptron(
    X_and, y_and, eta=1.0, max_epochs=50
)
pred_and = np.where(X_and @ w_and + b_and >= 0.0, 1.0, -1.0)
print(f"AND: w={w_and}, b={b_and}, konvergencia epoch={epochs_and}, "
      f"konvergens={conv_and}, hiba={int(np.sum(pred_and != y_and))}")
assert conv_and and epochs_and <= 50
assert np.array_equal(pred_and, y_and)

# XOR: nem szeparálható, a ciklus nem állhat meg
X_xor = np.array(
    [[0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]],
    dtype=np.float64,
)
y_xor = np.array([-1.0, 1.0, 1.0, -1.0], dtype=np.float64)

w_xor, b_xor, epochs_xor, conv_xor = train_perceptron(
    X_xor, y_xor, eta=1.0, max_epochs=100
)
pred_xor = np.where(X_xor @ w_xor + b_xor >= 0.0, 1.0, -1.0)
print(f"XOR: w={w_xor}, b={b_xor}, lefutott epoch={epochs_xor}, "
      f"konvergens={conv_xor}, hibák={int(np.sum(pred_xor != y_xor))}")
assert not conv_xor
assert epochs_xor == 100
assert int(np.sum(pred_xor != y_xor)) >= 1
