if groups != 1:
    raise NotImplementedError("a referencia jelenleg csak groups=1-et tamogat")
