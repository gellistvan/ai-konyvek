# munkakönyvtár: lab/
import torch

conv = torch.nn.Conv2d(3, 6, (2, 2), padding=0, groups=3, bias=False,
                       dtype=torch.float32)
with torch.no_grad():
    conv.weight.fill_(1.0)

x = torch.zeros(1, 3, 3, 3, dtype=torch.float32)
for c in range(3):
    x[0, c].fill_(float(c))

y = conv(x)
assert y.shape == (1, 6, 2, 2)
assert torch.equal(y[0, :, 0, 0], torch.tensor([0., 0., 4., 4., 8., 8.]))
print(y.shape)
print(y[0, :, 0, 0])

x_nonzero = x.clone()
x_nonzero[0, 0].fill_(5.0)          # csak a 0. bemeneti csatorna változik
y_nonzero = conv(x_nonzero)
assert torch.equal(y_nonzero[0, 2:], y[0, 2:])      # a 2..5 kimenet változatlan
assert not torch.equal(y_nonzero[0, :2], y[0, :2])  # a 0,1 kimenet változik
print(y_nonzero[0, :, 0, 0])
