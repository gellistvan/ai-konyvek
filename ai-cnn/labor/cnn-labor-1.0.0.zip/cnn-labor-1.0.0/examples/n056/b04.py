# munkakönyvtár: lab/
import torch

conv = torch.nn.Conv2d(3, 6, (2, 2), padding=0, groups=3, bias=False,
                       dtype=torch.float32)
with torch.no_grad():
    conv.weight.fill_(1.0)
x = torch.zeros(1, 3, 3, 3, dtype=torch.float32)
for c in range(3):
    x[0, c].fill_(float(c))
y = conv(x)
expected = torch.tensor([[[[0., 0.], [0., 0.]],
                          [[0., 0.], [0., 0.]],
                          [[4., 4.], [4., 4.]],
                          [[4., 4.], [4., 4.]],
                          [[8., 8.], [8., 8.]],
                          [[8., 8.], [8., 8.]]]])
assert y.shape == (1, 6, 2, 2)
assert torch.allclose(y, expected, atol=1e-6)

full = torch.nn.Conv2d(3, 6, 3, groups=1, bias=True, dtype=torch.float32)
grouped = torch.nn.Conv2d(3, 6, 3, groups=3, bias=True, dtype=torch.float32)
n_full = sum(p.numel() for p in full.parameters())
n_grp = sum(p.numel() for p in grouped.parameters())
print(n_full, n_grp, full.weight.shape, grouped.weight.shape)

try:
    torch.nn.Conv2d(5, 12, 3, groups=2)
except ValueError as e:
    print("elkapva", type(e).__name__)
