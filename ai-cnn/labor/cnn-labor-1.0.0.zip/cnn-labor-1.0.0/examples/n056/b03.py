# munkakönyvtár: lab/
import torch

def count_params(conv):
    return sum(p.numel() for p in conv.parameters())

def describe(name, cin, cout, k, groups):
    conv = torch.nn.Conv2d(cin, cout, (k, k), bias=True, groups=groups,
                           dtype=torch.float32)
    w = conv.weight
    expected_w = cout * (cin // groups) * k * k
    assert w.shape == (cout, cin // groups, k, k), w.shape
    assert expected_w + cout == count_params(conv)
    mac_one_output = (cin // groups) * k * k
    print(f"{name:22s} weight={tuple(w.shape)} params={count_params(conv):3d} "
          f"MAC/output={mac_one_output}")

describe("full g=1",         3, 12, 3, 1)
describe("grouped g=3",      3, 12, 3, 3)
describe("depthwise g=3",    3,  3, 3, 3)
describe("pointwise 1x1",    3, 12, 1, 1)

try:
    torch.nn.Conv2d(5, 12, 3, groups=2)
except ValueError as e:
    print("hibas_groups:", type(e).__name__, "oszthatosagi feltetel serult")
