assert conv.weight.shape == (6, 1, 2, 2)
