# lab/n080_residual_check.py
import torch

torch.manual_seed(20261020)

class BasicResidualBlock(torch.nn.Module):
    def __init__(self, C, k):
        super().__init__()
        assert k % 2 == 1
        self.conv1 = torch.nn.Conv2d(C, C, k, stride=1,
                                     padding=(k - 1) // 2, bias=False)
        self.conv2 = torch.nn.Conv2d(C, C, k, stride=1,
                                     padding=(k - 1) // 2, bias=False)

    def forward(self, x):
        return self.conv2(torch.relu(self.conv1(x))) + x

model = BasicResidualBlock(C=2, k=3)
n_params = sum(p.numel() for p in model.parameters())
assert n_params == 72, n_params
x = torch.randn(1, 2, 4, 4)
with torch.no_grad():
    y = model(x)
print("params:", n_params, "output shape:", tuple(y.shape))
assert y.shape == (1, 2, 4, 4)
