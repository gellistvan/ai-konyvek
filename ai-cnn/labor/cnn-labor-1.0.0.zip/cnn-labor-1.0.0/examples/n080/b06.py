n_params = sum(p.numel() for p in model.parameters())
assert count_tiny(8, 16) == n_params
