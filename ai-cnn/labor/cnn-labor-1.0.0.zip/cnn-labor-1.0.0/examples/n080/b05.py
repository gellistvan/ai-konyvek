def count_tiny(c1, c2, k=3, classes=3):
    p1 = 1 * c1 * k * k + c1 * c1 * k * k
    p2 = c1 * c2 * k * k + c2 * c2 * k * k
    head = c2 * classes + classes
    return p1 + p2 + head

assert count_tiny(8, 16) == 4155
