# lab/n080_decision_check.py
import torch

torch.manual_seed(20261020)

class TinyGlyphCNN(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.features = torch.nn.Sequential(
            torch.nn.Conv2d(1, 8, 3, padding=1, bias=False),
            torch.nn.ReLU(),
            torch.nn.Conv2d(8, 8, 3, padding=1, bias=False),
            torch.nn.ReLU(),
            torch.nn.MaxPool2d(2),
            torch.nn.Conv2d(8, 16, 3, padding=1, bias=False),
            torch.nn.ReLU(),
            torch.nn.Conv2d(16, 16, 3, padding=1, bias=False),
            torch.nn.ReLU(),
            torch.nn.MaxPool2d(2),
        )
        self.gap = torch.nn.AdaptiveAvgPool2d((1, 1))
        self.head = torch.nn.Linear(16, 3, bias=True)

    def forward(self, x):
        z = self.features(x)
        z = self.gap(z).flatten(1)
        return self.head(z)

model = TinyGlyphCNN()
n_params = sum(p.numel() for p in model.parameters())
assert n_params == 4155, n_params
x = torch.rand(2, 1, 24, 24, dtype=torch.float32)
with torch.no_grad():
    logits = model(x)
print("params:", n_params)
print("logits shape:", tuple(logits.shape))
assert logits.shape == (2, 3)
