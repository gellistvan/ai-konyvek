# lab/n068/train_compare.py
import json, argparse
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

def set_seed(seed):
    torch.manual_seed(seed); np.random.seed(seed)

class MiniDeep3(nn.Module):
    def __init__(self):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1,8,3,padding=1), nn.ReLU(),
            nn.Conv2d(8,8,3,padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(8,16,3,padding=1), nn.ReLU(),
            nn.Conv2d(16,16,3,padding=1), nn.ReLU(), nn.MaxPool2d(2))
        self.head = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(16,3))
    def forward(self, x):
        return self.head(self.features(x))

class MiniWide5(nn.Module):
    def __init__(self):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1,10,5,padding=2), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(10,16,5,padding=2), nn.ReLU(), nn.MaxPool2d(2))
        self.head = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(16,3))
    def forward(self, x):
        return self.head(self.features(x))

def param_count(model):
    return sum(p.numel() for p in model.parameters())

def evaluate(model, loader):
    model.eval()
    correct = total = 0
    with torch.no_grad():
        for x, y in loader:
            pred = model(x).argmax(dim=1)
            correct += (pred == y).sum().item(); total += y.numel()
    return correct / total

def fit(model, train_loader, val_loader, max_epochs=20, patience=5):
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
    loss_fn = nn.CrossEntropyLoss()
    best_loss, best_state, waited = float("inf"), None, 0
    for epoch in range(max_epochs):
        model.train()
        for x, y in train_loader:
            opt.zero_grad(); loss = loss_fn(model(x), y); loss.backward(); opt.step()
        model.eval(); val_loss = 0.0; count = 0
        with torch.no_grad():
            for x, y in val_loader:
                val_loss += loss_fn(model(x), y).item() * y.numel(); count += y.numel()
        val_loss /= count
        if val_loss < best_loss - 1e-6:
            best_loss, best_state, waited = val_loss, {k: v.clone() for k, v in model.state_dict().items()}, 0
        else:
            waited += 1
            if waited >= patience:
                break
    model.load_state_dict(best_state)
    return best_loss

def main(seeds, out_path):
    data_dir = "../data"
    X = np.load(f"{data_dir}/images.npy").astype(np.float32)
    y = np.load(f"{data_dir}/labels.npy").astype(np.int64)
    corrupt = np.load(f"{data_dir}/corrupted_test.npy").astype(np.float32)
    meta = pd.read_csv(f"{data_dir}/metadata.csv")
    assert list(meta.columns) == ["index", "scene_id", "view_id", "label", "split",
                                  "xmin", "ymin", "xmax", "ymax"], meta.columns
    assert len(meta) == len(X) == len(y) == 360, (len(meta), X.shape, y.shape)
    assert X.shape[1:] == (1, 24, 24), X.shape
    assert corrupt.shape[1:] == (1, 24, 24), corrupt.shape
    assert meta["index"].tolist() == list(range(len(meta)))
    assert param_count(MiniDeep3()) == 4203
    assert param_count(MiniWide5()) == 4327
    tr_idx = meta.loc[meta.split == "train", "index"].to_numpy()
    va_idx = meta.loc[meta.split == "val", "index"].to_numpy()
    te_idx = meta.loc[meta.split == "test", "index"].to_numpy()
    Xtr = torch.from_numpy(X[tr_idx]); ytr = torch.from_numpy(y[tr_idx])
    Xva = torch.from_numpy(X[va_idx]); yva = torch.from_numpy(y[va_idx])
    Xte = torch.from_numpy(X[te_idx]); yte = torch.from_numpy(y[te_idx])
    Xco = torch.from_numpy(corrupt)  # sorrend = metadata test sorrend
    assert len(corrupt) == len(te_idx), (corrupt.shape, len(te_idx))
    results = {}
    for name, build in [("MiniDeep3", MiniDeep3), ("MiniWide5", MiniWide5)]:
        results[name] = {"params": param_count(build()), "val_loss": [],
                         "val_acc": [], "test_acc": [], "corrupt_acc": []}
        for seed in seeds:
            set_seed(seed)
            gen = torch.Generator().manual_seed(seed)
            train_dl = DataLoader(TensorDataset(Xtr, ytr), batch_size=32, shuffle=True, generator=gen)
            val_dl = DataLoader(TensorDataset(Xva, yva), batch_size=64)
            test_dl = DataLoader(TensorDataset(Xte, yte), batch_size=64)
            corrupt_dl = DataLoader(TensorDataset(Xco, yte), batch_size=64)
            model = build()
            val_loss = fit(model, train_dl, val_dl)
            results[name]["val_loss"].append(val_loss)
            results[name]["val_acc"].append(evaluate(model, val_dl))
            results[name]["test_acc"].append(evaluate(model, test_dl))
            results[name]["corrupt_acc"].append(evaluate(model, corrupt_dl))
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, default=float)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=[0,1,2])
    ap.add_argument("--out", default="results_n068.json")
    args = ap.parse_args()
    main(args.seeds, args.out)
