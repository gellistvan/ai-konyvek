# hibás változat – a labor helyes kódjában ez a sor nem így szerepel
corrupt_dl = DataLoader(TensorDataset(Xco, yte), batch_size=64, shuffle=True)
