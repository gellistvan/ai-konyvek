def param_count_bias(model):
    total = bias = 0
    for name, p in model.named_parameters():
        total += p.numel()
        if name.endswith("bias"):
            bias += p.numel()
    return total - bias, total
