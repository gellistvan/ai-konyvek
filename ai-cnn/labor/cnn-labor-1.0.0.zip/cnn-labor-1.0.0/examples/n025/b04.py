def ce(p, q):
    return -np.mean(p * np.log(q))
