import numpy as np

def info_measures(p, q, tol=1e-12):
    p = np.asarray(p, dtype=np.float64)
    q = np.asarray(q, dtype=np.float64)
    assert p.ndim == q.ndim == 1 and p.shape == q.shape
    assert np.all(p >= 0) and np.all(q >= 0)
    assert abs(p.sum() - 1.0) < tol and abs(q.sum() - 1.0) < tol
    with np.errstate(divide="ignore", invalid="ignore"):
        H = -np.sum(np.where(p > 0, p * np.log(p), 0.0))
        ce = -np.sum(np.where(p > 0, p * np.log(q), 0.0))
    kl = ce - H
    if np.any((p > 0) & (q == 0)):
        ce = np.inf
        kl = np.inf
    return H, ce, kl

p = np.array([0.5, 0.0, 0.5])
q = np.array([0.4, 0.3, 0.3])
print(info_measures(p, q))
# Várható (NumPy 2): (np.float64(0.6931471805599453),
# np.float64(1.0601317681000455), np.float64(0.3669845875401002))
