# lab/n025_entropy_lab.py
import numpy as np

DTYPE = np.float64
# DEVICE = "CPU" (NumPy, nincs külön eszközkezelés)

def _xlogy(a, b):
    """a*log(b), a=0 esetén 0; a ki nem választott ágat nem értékeli ki."""
    out = np.zeros(np.broadcast(a, b).shape, dtype=DTYPE)
    a, b = np.broadcast_arrays(a, b)
    m = a > 0
    out[m] = a[m] * np.log(b[m])
    return out

def entropy(p):
    p = np.asarray(p, dtype=DTYPE)
    return -np.sum(_xlogy(p, p))

def cross_entropy(p, q):
    p = np.asarray(p, dtype=DTYPE)
    q = np.asarray(q, dtype=DTYPE)
    return -np.sum(_xlogy(p, q))

def kl_divergence(p, q):
    p = np.asarray(p, dtype=DTYPE)
    q = np.asarray(q, dtype=DTYPE)
    if np.any((p > 0) & (q == 0)):
        return np.inf
    m = p > 0
    return np.sum(p[m] * np.log(p[m] / q[m]))

# 1) Nemszimmetria
p = np.array([0.2, 0.8], dtype=DTYPE)
q = np.array([0.7, 0.3], dtype=DTYPE)
kl_pq = kl_divergence(p, q)
kl_qp = kl_divergence(q, p)
print(f"KL(p||q) = {kl_pq:.9f}")
print(f"KL(q||p) = {kl_qp:.9f}")
print(f"különbség = {abs(kl_pq - kl_qp):.9f}")

# 2) Support-csapda: supp(p) ⊆ supp(q), de nem fordítva
p = np.array([0.5, 0.0, 0.5], dtype=DTYPE)
q = np.array([0.4, 0.3, 0.3], dtype=DTYPE)
print(f"KL(p||q) = {kl_divergence(p, q):.9f}")
print(f"KL(q||p) = {kl_divergence(q, p)}")

# Ellenőrzés a tételre
print(f"H(p,q)-H(p) = {cross_entropy(p, q) - entropy(p):.9f}")

# Ellenőrzés: nemszimmetria, support-csapda és a felbontási tétel
assert not np.isclose(kl_pq, kl_qp)
assert np.isinf(kl_divergence(q, p))
assert np.isclose(cross_entropy(p, q) - entropy(p), kl_divergence(p, q),
                  atol=1e-12, rtol=1e-12)
print("ellenorzes: nemszimmetria, support-csapda es felbontas rendben")
