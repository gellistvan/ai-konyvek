python n025_entropy_lab.py
