import numpy as np
X = np.arange(1, 10, dtype=float).reshape(3, 3)
K = np.array([[1, 2], [3, 4.]])
Xp = np.pad(X, 1)                                  # 5x5
Y = np.array([[(Xp[i:i+2, j:j+2] * K).sum() for j in range(4)] for i in range(4)])
dY = np.zeros_like(Y); dY[0, 0] = 1.0
gXp = np.zeros_like(Xp)
for i in range(4):
    for j in range(4):
        gXp[i:i+2, j:j+2] += dY[i, j] * K          # scatter-add
gX = gXp[1:-1, 1:-1]                               # crop
assert Y[0, 0] == 4.0 and gXp[:2, :2].tolist() == K.tolist() and gX[0, 0] == 4.0
