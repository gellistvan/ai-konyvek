import numpy as np

def conv2d_valid_correct(X, K):
    H, W = X.shape
    kh, kw = K.shape
    K_rot = np.rot90(K, 2)
    out = np.zeros((H - kh + 1, W - kw + 1))
    for i in range(H - kh + 1):
        for j in range(W - kw + 1):
            out[i, j] = np.sum(K_rot * X[i:i+kh, j:j+kw])
    return out
