import torch
import torch.nn.functional as F

Xt = torch.tensor(X.reshape(1, 1, 3, 3), dtype=torch.float32)
Kt = torch.tensor(K.reshape(1, 1, 2, 2), dtype=torch.float32)

Yc_torch = F.conv2d(Xt, Kt)                     # NCHW, stride=1, padding=0
Kt_flipped = torch.flip(Kt, dims=[2, 3])
Yf_torch = F.conv2d(Xt, Kt_flipped)             # matematikai konvolúció

print("torch Yc:", Yc_torch.squeeze())
print("torch Yf:", Yf_torch.squeeze())
assert np.allclose(Yc, Yc_torch.squeeze().numpy(), atol=1e-6)
assert np.allclose(Yf, Yf_torch.squeeze().numpy(), atol=1e-6)
