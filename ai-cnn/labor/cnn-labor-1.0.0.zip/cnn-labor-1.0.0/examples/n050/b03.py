# lab/n050/check_convs.py
import numpy as np

X = np.array([[0.2, 0.5, 0.1],
              [0.8, 0.3, 0.6],
              [0.4, 0.9, 0.7]], dtype=np.float32)
K = np.array([[1.0, 0.0],
              [-2.0, 3.0]], dtype=np.float32)

def corr2d_valid(X, K):
    H, W = X.shape
    kh, kw = K.shape
    out = np.zeros((H - kh + 1, W - kw + 1), dtype=np.float32)
    for i in range(H - kh + 1):
        for j in range(W - kw + 1):
            for a in range(kh):
                for b in range(kw):
                    out[i, j] += K[a, b] * X[i + a, j + b]
    return out

def conv2d_valid(X, K):
    return corr2d_valid(X, np.rot90(K, 2))   # 180 fokos forgatás

Yc = corr2d_valid(X, K)
Yf = conv2d_valid(X, K)
print("cross-correlation:\n", Yc)
print("convolution:\n", Yf)
# mért (float32): cross-correlation [[-0.49999994, 1.7],
#                                   [2.6999998, 0.5999999]]
# mért (float32): convolution       [[-0.09999996, 1.9],
#                                   [2.7, 0.39999998]]
assert np.allclose(Yc, [[-0.5, 1.7], [2.7, 0.6]], atol=1e-6)
assert np.allclose(Yf, [[-0.1, 1.9], [2.7, 0.4]], atol=1e-6)
