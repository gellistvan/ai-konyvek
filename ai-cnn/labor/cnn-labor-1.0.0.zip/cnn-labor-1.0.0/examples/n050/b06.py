def conv2d_valid_bad(X, K):
    H, W = X.shape
    kh, kw = K.shape
    out = np.zeros((H - kh + 1, W - kw + 1))
    for i in range(H - kh + 1):
        for j in range(W - kw + 1):
            out[i, j] = np.sum(K * X[i:i+kh, j:j+kw])
    return out
