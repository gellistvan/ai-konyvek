import numpy as np

def corr2d_valid(X, K):
    H, W = X.shape
    kh, kw = K.shape
    out = np.zeros((H - kh + 1, W - kw + 1), dtype=np.float64)
    for i in range(H - kh + 1):
        for j in range(W - kw + 1):
            out[i, j] = np.sum(K * X[i:i+kh, j:j+kw])
    return out

X = np.array([[1, 4, 2],
              [0, 3, 1],
              [2, 5, 3],
              [1, 1, 2]], dtype=np.float64)
K = np.array([[2, -1],
              [0,  1]], dtype=np.float64)
Y = corr2d_valid(X, K)
assert Y.shape == (3, 2)
assert np.allclose(Y, np.array([[1., 7.],
                                [2., 8.],
                                [0., 9.]]))
print(Y)
