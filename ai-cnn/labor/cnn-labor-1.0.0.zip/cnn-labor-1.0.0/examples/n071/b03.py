import torch
import torch.nn as nn

torch.manual_seed(123)
X = torch.randn(2, 8, 4, 4, dtype=torch.float32)

bn = nn.BatchNorm2d(8, momentum=0.1)
gn = nn.GroupNorm(2, 8)
ln = nn.LayerNorm([8, 4, 4])

bn.train(); gn.train(); ln.train()
Y_bn_batch  = bn(X)
Y_bn_single = bn(X[:1])
Y_gn_batch  = gn(X)
Y_gn_single = gn(X[:1])
Y_ln_batch  = ln(X)
Y_ln_single = ln(X[:1])

train_bn_same = torch.allclose(Y_bn_batch[0], Y_bn_single[0], atol=1e-6)
train_gn_same = torch.allclose(Y_gn_batch[0], Y_gn_single[0], atol=1e-6)
train_ln_same = torch.allclose(Y_ln_batch[0], Y_ln_single[0], atol=1e-6)
print("train, batch==single?", train_bn_same, train_gn_same, train_ln_same)  # várt: False True True
assert not train_bn_same and train_gn_same and train_ln_same

# A BN train forwardok a futó puffert is frissítik, ezért a hívások sorrendje számít.
print("BN bemeneti csatornaátlag (batch):", X.mean(dim=(0, 2, 3)).tolist())
print("BN bemeneti csatornaátlag (single):", X[:1].mean(dim=(0, 2, 3)).tolist())
print("BN kimeneti csatornaátlag (batch):", Y_bn_batch.mean(dim=(0, 2, 3)).tolist())
print("BN kimeneti csatornaátlag (single):", Y_bn_single.mean(dim=(0, 2, 3)).tolist())

bn.eval(); gn.eval(); ln.eval()
Y_bn_ev_batch  = bn(X)
Y_bn_ev_single = bn(X[:1])
Y_gn_ev_batch  = gn(X)
Y_gn_ev_single = gn(X[:1])
Y_ln_ev_batch  = ln(X)
Y_ln_ev_single = ln(X[:1])

eval_bn_same = torch.allclose(Y_bn_ev_batch[0], Y_bn_ev_single[0], atol=1e-6)
eval_gn_same = torch.allclose(Y_gn_ev_batch[0], Y_gn_ev_single[0], atol=1e-6)
eval_ln_same = torch.allclose(Y_ln_ev_batch[0], Y_ln_ev_single[0], atol=1e-6)
print("eval, batch==single?", eval_bn_same, eval_gn_same, eval_ln_same)  # várt: True True True
assert eval_bn_same and eval_gn_same and eval_ln_same
