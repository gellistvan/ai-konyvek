import torch
import torch.nn as nn
import torch.nn.functional as F

class PreActBlock(nn.Module):
    def __init__(self, C):
        super().__init__()
        self.bn1 = nn.BatchNorm2d(C)
        self.conv1 = nn.Conv2d(C, C, 3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(C)
        self.conv2 = nn.Conv2d(C, C, 3, padding=1, bias=False)

    def forward(self, x):
        out = self.conv1(F.relu(self.bn1(x)))
        out = self.conv2(F.relu(self.bn2(out)))
        return x + out

torch.manual_seed(7)
block = PreActBlock(3)
x = torch.randn(2, 3, 8, 8, dtype=torch.float32)
y = block(x)
print(y.shape)  # Várt: torch.Size([2, 3, 8, 8])
assert tuple(y.shape) == (2, 3, 8, 8)
