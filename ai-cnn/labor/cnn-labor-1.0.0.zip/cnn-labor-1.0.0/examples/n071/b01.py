import torch
import torch.nn as nn

torch.manual_seed(0)

# N=2, C=2, H=1, W=2
x0 = torch.tensor([[[[1.0, 3.0]], [[5.0, 7.0]]]])
x1 = torch.tensor([[[[-3.0, -1.0]], [[-7.0, -5.0]]]])
X = torch.cat([x0, x1], dim=0)

bn = nn.BatchNorm2d(2, eps=1e-5, momentum=0.1)
ln = nn.LayerNorm([2, 1, 2], eps=1e-5)
gn = nn.GroupNorm(1, 2, eps=1e-5)  # G=1: mintánkénti normalizálás

bn.train()
print("BN train:")
print(bn(X))
print("running_mean:", bn.running_mean.tolist())
print("running_var :", bn.running_var.tolist())

ln.eval()  # a LayerNormnek nincs train/eval különbsége
print("LN:")
print(ln(X))

gn.eval()  # a GroupNormnek sincs train/eval különbsége
print("GN, G=1:")
print(gn(X))

# Eval BatchNorm: a running pufferrel normalizál
bn.eval()
print("BN eval, első minta:")
print(bn(X[:1]))
