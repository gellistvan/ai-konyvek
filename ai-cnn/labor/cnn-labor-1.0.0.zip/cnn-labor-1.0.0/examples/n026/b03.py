loss = nn.CrossEntropyLoss()(torch.softmax(logits, dim=1), target)
