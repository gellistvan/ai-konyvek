import numpy as np

def stable_ce_grad(z, y):
    z = np.asarray(z, dtype=np.float64)
    c = np.max(z)
    log_norm = c + np.log(np.sum(np.exp(z - c)))
    loss = -z[y] + log_norm
    e_y = np.zeros_like(z)
    e_y[y] = 1.0
    p = np.exp(z - c) / np.sum(np.exp(z - c))
    return loss, p - e_y

# teszt
z = np.array([1000.0, 999.0, 1000.5])
y = 2
loss, grad = stable_ce_grad(z, y)
print(loss, grad)
