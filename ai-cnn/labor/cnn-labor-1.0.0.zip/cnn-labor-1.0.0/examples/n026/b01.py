# lab/n026/check_ce_grad.py
import numpy as np

def lse(z):
    c = np.max(z)
    return c + np.log(np.sum(np.exp(z - c)))

def softmax(z):
    s = np.exp(z - np.max(z))
    return s / np.sum(s)

def ce_loss(z, y):
    return -z[y] + lse(z)

def ce_grad(z, y):
    e_y = np.zeros_like(z)
    e_y[y] = 1.0
    return softmax(z) - e_y

z = np.array([2.0, -1.0, 0.5], dtype=np.float64)
y = 2
print("z =", z)
print("softmax =", softmax(z))
print("loss =", ce_loss(z, y))
g = ce_grad(z, y)
print("analytical grad =", g)

eps = 1e-5
num = np.zeros_like(z)
for i in range(z.shape[0]):
    e_i = np.zeros_like(z)
    e_i[i] = 1.0
    num[i] = (ce_loss(z + eps * e_i, y) - ce_loss(z - eps * e_i, y)) / (2.0 * eps)
print("numerical grad =", num)
print("max abs diff =", np.max(np.abs(num - g)))

shift = 1000.0
zs = z + shift
print("shifted loss =", ce_loss(zs, y))
print("shifted softmax =", softmax(zs))
print("shifted grad =", ce_grad(zs, y))

# Ellenőrzés: gradiens, eltolás-invariancia és a loss stabilitása
assert np.max(np.abs(num - g)) < 1e-9
assert np.allclose(softmax(zs), softmax(z), atol=1e-12, rtol=0.0)
assert np.isclose(ce_loss(zs, y), ce_loss(z, y), atol=1e-12, rtol=0.0)
print("ellenorzes: gradiens, eltolas-invariancia es veszteseg rendben")
