def is_safe(eta, L=6.0):
    return 0.0 < eta < 2.0 / L
