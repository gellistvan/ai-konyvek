# labs/n022/n022_lab.py
import numpy as np

def f(x):
    return x[0]**2 + 3.0 * x[1]**2

def grad_f(x):
    return np.array([2.0 * x[0], 6.0 * x[1]], dtype=np.float64)

L = 6.0  # f az L=6 sima függvény

def run_steps(eta, x0, steps=4):
    x = x0.astype(np.float64).copy()
    x_prev = x.copy()
    f_prev = f(x_prev)
    g_prev = grad_f(x_prev)
    valid = 0.0 < eta < 2.0 / L
    print(f"\neta = {eta:g}, L = {L:g}, 2/L = {2.0/L:.6f}")
    print(f"{'t':>2} {'x1':>12} {'x2':>12} {'f(x)':>14} {'descent-felso':>14}")
    # 0. lépés: nincs még felső korlát, magát a pontot írjuk ki
    for t in range(steps + 1):
        if t == 0:
            upper_str = "-"
        else:
            upper = (
                f_prev
                - eta * (1.0 - 0.5 * L * eta)
                * float(np.dot(g_prev, g_prev))
            )
            upper_str = f"{upper:.8f}" if valid else "nem alkalmazhato"
        # a t. iterált kiírása
        print(f"{t:>2} {x[0]:>12.8f} {x[1]:>12.8f} {f(x):>14.8f} {upper_str:>14}")
        if t < steps:
            x_prev = x.copy()
            f_prev = f(x_prev)
            g_prev = grad_f(x_prev)
            x = x_prev - eta * g_prev
    return x

x0 = np.array([2.0, -1.0], dtype=np.float64)
x_stable = run_steps(0.25, x0, steps=4)   # stabil: 0.25 < 1/3
x_div = run_steps(0.50, x0, steps=4)      # túl nagy lépés: 0.50 > 1/3

# Ellenőrzés: a négy lépés utáni pontok a kézi számítással egyeznek
assert np.allclose(x_stable, [0.125, -0.0625], atol=1e-12, rtol=0.0)
assert np.allclose(x_div, [0.0, -16.0], atol=1e-12, rtol=0.0)
assert f(x_div) == 768.0
print("\nellenorzes: a stabil es a divergalo palya a kezi szamitassal egyezik")
