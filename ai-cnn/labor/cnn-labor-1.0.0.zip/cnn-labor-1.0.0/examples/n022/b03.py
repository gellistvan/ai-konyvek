def is_safe(eta, L=6.0):
    return eta < 2.0
