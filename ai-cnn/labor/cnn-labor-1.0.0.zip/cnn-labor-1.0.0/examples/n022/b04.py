# labs/n022/feladat_f3.py
import numpy as np

def check_descent(f, grad_f, x0, eta, L, steps):
    x0 = np.asarray(x0, dtype=np.float64)
    x = x0.copy()
    trace = [(0, x.copy(), f(x))]
    valid_eta = 0.0 < eta < 2.0 / L
    bounds_ok = []
    for t in range(1, steps + 1):
        x_prev = x.copy()
        g = grad_f(x_prev)
        upper = f(x_prev) - eta * (1.0 - 0.5 * L * eta) * float(np.dot(g, g))
        x = x_prev - eta * g
        actual = f(x)
        trace.append((t, x.copy(), actual))
        if valid_eta:
            tol = 1e-12 * max(1.0, abs(upper))
            bounds_ok.append(bool(actual <= upper + tol))
        else:
            bounds_ok.append(None)  # a lemma nem alkalmazható, nincs korlát
    return trace, valid_eta, bounds_ok

def f(x):
    return x[0]**2 + 3.0 * x[1]**2

def grad_f(x):
    return np.array([2.0 * x[0], 6.0 * x[1]], dtype=np.float64)

x0 = np.array([2.0, -1.0], dtype=np.float64)
for eta in (0.25, 0.5):
    trace, valid, ok = check_descent(f, grad_f, x0, eta, L=6.0, steps=4)
    print(f"eta={eta:g}, eta_ervenyes={valid}, korlatok={ok}")
    print("  utolso iteralt:", trace[-1][1], "f:", trace[-1][2])
