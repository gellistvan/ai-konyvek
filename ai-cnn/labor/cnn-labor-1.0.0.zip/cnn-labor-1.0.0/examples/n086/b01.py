# lab/n086_rotation_check.py — munkakönyvtár: lab/
import csv
import numpy as np

images = np.load("data/images.npy")          # (360,1,24,24) float32
labels = np.load("data/labels.npy")          # (360,) int64
with open("data/metadata.csv", newline="") as f:
    rows = list(csv.DictReader(f))
rows.sort(key=lambda r: int(r["index"]))
split = np.array([r["split"] for r in rows])
train = split == "train"
for want in (0, 1):                           # vertical, horizontal
    i = int(np.flatnonzero(train & (labels == want))[0])
    img = images[i, 0]
    rot = np.rot90(img, k=3)                  # 90 fok, óramutató szerint
    assert rot.shape == img.shape
    col0, row0 = img.sum(axis=0), img.sum(axis=1)
    col1, row1 = rot.sum(axis=0), rot.sum(axis=1)
    assert abs(col0.max() - row1.max()) < 1e-4
    assert abs(row0.max() - col1.max()) < 1e-4
    axis = ("oszlopkoncentrált (vertical)" if col1.max() > row1.max()
            else "sorkoncentrált (horizontal)")
    print(f"eredeti címke={want}: colmax={col0.max():.2f} rowmax={row0.max():.2f}")
    print(f"rotált:            colmax={col1.max():.2f} rowmax={row1.max():.2f} -> {axis}")
