import torch

def horizontal_flip_nchw_torch(X):
    # X: torch.Tensor, N x C x H x W
    return torch.flip(X, dims=(-1,))
