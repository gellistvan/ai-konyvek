import numpy as np

def horizontal_flip_nchw(X):
    # X: ndarray, N x C x H x W
    return X[..., ::-1].copy()

x = np.arange(24, dtype=np.float32).reshape(2, 1, 3, 4)
# A feladat panelje: [0,1,2,3], [4,5,6,7], [8,9,10,11]
x[0,0] = [[0,1,2,3],[4,5,6,7],[8,9,10,11]]
x[1,0] = [[12,13,14,15],[16,17,18,19],[20,21,22,23]]
y = horizontal_flip_nchw(x)
print(y[0,0].tolist())
# [[3.0, 2.0, 1.0, 0.0], [7.0, 6.0, 5.0, 4.0], [11.0, 10.0, 9.0, 8.0]]
