def correct_max_stretch(A):
    import numpy as np
    return float(np.linalg.svd(A, compute_uv=False)[0])
