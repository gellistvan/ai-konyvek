import numpy as np

A = np.array([[3.0, 0.0],
              [4.0, 0.0]], dtype=np.float64)
print(np.linalg.svd(A, compute_uv=False))
print(np.linalg.matrix_rank(A))

assert np.allclose(np.linalg.svd(A, compute_uv=False), [5.0, 0.0])
assert np.linalg.matrix_rank(A) == 1
