def wrong_max_stretch(A):
    import numpy as np
    return float(np.max(np.abs(np.linalg.eigvals(A))))
