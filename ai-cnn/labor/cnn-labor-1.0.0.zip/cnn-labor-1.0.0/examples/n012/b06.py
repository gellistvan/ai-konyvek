import numpy as np

def ratio_and_check(A, X, rtol=1e-12, atol=1e-15):
    A = np.asarray(A, dtype=np.float64)
    X = np.asarray(X, dtype=np.float64)
    if X.ndim != 2:
        raise ValueError("X legyen (n, d) alakú.")
    denom = np.linalg.norm(X, axis=1)
    if np.any(denom == 0.0):
        raise ValueError("A nullvektorhoz nincs nyújtási arány.")
    ratios = np.linalg.norm(X @ A.T, axis=1) / denom
    bound = np.linalg.norm(A, 2) * (1.0 + rtol) + atol
    if np.any(ratios > bound):
        raise AssertionError(
            f"Spektrálisnorma-sértés: max={ratios.max():.16f}, bound={bound:.16f}"
        )
    return float(np.max(ratios))

A = np.array([[3.0, 0.0],
              [4.0, 0.0]], dtype=np.float64)
X = np.array([[1.0, 0.0],
              [0.0, 1.0],
              [1.0/np.sqrt(2.0), 1.0/np.sqrt(2.0)]], dtype=np.float64)

ratios = np.linalg.norm(X @ A.T, axis=1) / np.linalg.norm(X, axis=1)
assert np.allclose(ratios, [5.0, 0.0, 5.0 / np.sqrt(2.0)])
print(ratios)
print(ratio_and_check(A, X))
# A futtatott kimenet:
# [5.         0.         3.53553391]
# 5.0
# Az első sor a három arány (5.0, 0.0 és 5/sqrt(2) ~= 3.5355339059327378),
# a második a függvény visszatérési értéke, a három arány maximuma.
