"""n012_shape_stretch.py

A négyzet és kör maximális véges-mintás nyújtása két lineáris
transzformáció alatt, összevetve a spektrális normával.

Munkakönyvtár: lab/n012
Futtatás:      python n012_shape_stretch.py

A kimeneti 'shape_under_transforms.png' a torzított alakzatokat menti.
A kimenet rögzített környezetben futtatott eredmény (Python 3.12.3,
NumPy 2.5.4, matplotlib 3.11.2, CPU, egy szál).
"""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

WORK = Path("lab/n012")
WORK.mkdir(parents=True, exist_ok=True)
DTYPE = np.float64

# Két vizsgált lineáris transzformáció.
A1 = np.array([[2.0, 0.0],
               [0.0, 0.5]], dtype=DTYPE)
A2 = np.array([[1.5, 0.5],
               [0.5, 1.0]], dtype=DTYPE)


def unit_circle(n: int = 512) -> np.ndarray:
    """Az egységkörvonal n darab pontja, shape (n, 2)."""
    theta = np.linspace(0.0, 2.0 * np.pi, n, endpoint=False, dtype=DTYPE)
    return np.column_stack((np.cos(theta), np.sin(theta)))


def unit_square() -> np.ndarray:
    """A [-1,1]^2 zárt négyzet csúcsai és oldalfelező pontjai; az első pont ismétlődik."""
    return np.array([[-1.0, -1.0],
                     [ 0.0, -1.0],
                     [ 1.0, -1.0],
                     [ 1.0,  0.0],
                     [ 1.0,  1.0],
                     [ 0.0,  1.0],
                     [-1.0,  1.0],
                     [-1.0,  0.0],
                     [-1.0, -1.0]], dtype=DTYPE)


def max_finite_stretch(A: np.ndarray, X: np.ndarray) -> float:
    """A véges ponthalmaz pontjaiban mért maximális ||Ax||/||x|| arány."""
    AX = X @ A.T
    return float(np.max(np.linalg.norm(AX, axis=1)
                        / np.linalg.norm(X, axis=1)))


def spectral_norm(A: np.ndarray) -> float:
    """A spektrális norma, azaz a legnagyobb szinguláris érték."""
    return float(np.linalg.svd(A, compute_uv=False)[0])


def main() -> None:
    square = unit_square()
    circle = unit_circle()

    results = []
    for name, A in [("A1", A1), ("A2", A2)]:
        sigma = spectral_norm(A)
        square_stretch = max_finite_stretch(A, square)
        circle_stretch = max_finite_stretch(A, circle)
        print(f"{name}: sigma={sigma:.16f}, "
              f"square_max={square_stretch:.16f}, "
              f"circle_max={circle_stretch:.16f}")
        results.append((A, sigma, square_stretch, circle_stretch))

    # A1: mindkét szinguláris irány szerepel a négyzet mintapontjai között is,
    # ezért a négyzetminta is pontosan eléri a spektrális normát.
    (_, sigma1, square1, circle1) = results[0]
    np.testing.assert_allclose(square1, sigma1, rtol=0.0, atol=1e-12)
    np.testing.assert_allclose(circle1, sigma1, rtol=0.0, atol=1e-12)

    # A2: a négyzetminta általában nem tartalmazza a legnagyobb nyújtás
    # irányát, tehát csak alsó becslés; a sűrű körvonal az irányt közelíti.
    (_, sigma2, square2, circle2) = results[1]
    assert square2 <= sigma2 * (1.0 + 1e-12) + 1e-15
    np.testing.assert_allclose(circle2, sigma2, rtol=5e-4, atol=5e-4)

    fig, axes = plt.subplots(1, 2, figsize=(10, 5))
    for ax, (A, _, _, _) in zip(axes, results):
        ax.plot(square[:, 0], square[:, 1], "--", label="eredeti négyzet")
        ax.plot((square @ A.T)[:, 0], (square @ A.T)[:, 1],
                label="transzformált négyzet")
        ax.plot(circle[:, 0], circle[:, 1], ":", label="eredeti kör")
        ax.plot((circle @ A.T)[:, 0], (circle @ A.T)[:, 1],
                label="transzformált kör", linewidth=2.0)
        ax.set_aspect("equal")
        ax.set_title(f"A = {A.tolist()}")
        ax.legend(loc="upper left")
        ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(WORK / "shape_under_transforms.png", dpi=150)
    print(f"Ábra: {WORK / 'shape_under_transforms.png'}")


if __name__ == "__main__":
    main()
