import numpy as np

def nchw_to_nhwc_checked(x):
    if x.ndim != 4:
        raise ValueError(f"négy dimenzió kell, kapott {x.ndim}")
    if x.dtype not in (np.float32, np.float64):
        raise TypeError(f"float32/float64 kell, kapott {x.dtype}")
    return np.transpose(x, (0, 2, 3, 1))

rng = np.random.default_rng(0)
x = rng.random((2, 3, 4, 5)).astype(np.float32)
y = nchw_to_nhwc_checked(x)
assert y.shape == (2, 4, 5, 3)
assert np.array_equal(y[1, 0, 2, :], x[1, :, 0, 2])
assert np.shares_memory(x, y)
vissza = np.transpose(y, (0, 3, 1, 2))
max_abs = float(np.max(np.abs(x - vissza)))
assert max_abs == 0.0
try:
    nchw_to_nhwc_checked(np.zeros((3, 4, 5), dtype=np.float32))
except ValueError:
    print("3D bemenet elutasítva: ValueError")
try:
    nchw_to_nhwc_checked(np.zeros((1, 3, 2, 2), dtype=np.uint8))
except TypeError:
    print("uint8 elutasítva: explicit float dtype-kérés")
print(f"Rendben: shape {y.shape}, dtype {y.dtype}, max abs hiba {max_abs:.1e}")
