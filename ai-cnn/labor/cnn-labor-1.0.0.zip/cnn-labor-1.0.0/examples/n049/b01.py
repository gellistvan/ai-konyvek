# munkakönyvtár: lab/n049_layout
import numpy as np

X = np.zeros((1, 3, 2, 2), dtype=np.float32)      # NCHW, [0,1]
X[0, 0, 0, 0], X[0, 0, 0, 1] = 0.1, 0.2           # R sor
X[0, 0, 1, 0], X[0, 0, 1, 1] = 0.3, 0.4
X[0, 1, 0, 0], X[0, 1, 0, 1] = 0.5, 0.6           # G sor
X[0, 1, 1, 0], X[0, 1, 1, 1] = 0.7, 0.8
X[0, 2] = [[0.9, 1.0], [1.0, 1.0]]                # B csatorna, explicit mátrix

Y = np.transpose(X, (0, 2, 3, 1))                 # NCHW -> NHWC
print("NCHW:", X.shape, "NHWC:", Y.shape)
print("pixel (0,1):", Y[0, 0, 1, :])              # várt: [0.2 0.6 1. ]
# ugyanazon pixel három csatornája a transzponálás előtt és után
assert np.array_equal(X[0, :, 0, 1], Y[0, 0, 1, :])
print("G csatorna (0,1) NCHW lapított címe:", (1*2 + 0)*2 + 1)   # 5
print("G csatorna (0,1) NHWC lapított címe:", ((0*2 + 0)*2 + 1)*3 + 1)  # 4
