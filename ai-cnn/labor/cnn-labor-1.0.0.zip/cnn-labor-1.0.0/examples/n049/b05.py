from PIL import Image
import numpy as np, torch

x = np.asarray(Image.open("glyph.png")).astype(np.float32)  # (H, W) szürke tömb
logits = model(torch.as_tensor(x))                          # modell 4D (N,C,H,W)-t vár
