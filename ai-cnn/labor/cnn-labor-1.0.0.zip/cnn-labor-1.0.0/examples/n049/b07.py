img = Image.open("glyph.png").convert("L")                  # 8-bites szürke
x = np.asarray(img, dtype=np.float32) / 255.0               # (H, W), [0,1]
t = torch.from_numpy(x).unsqueeze(0).unsqueeze(0)           # (1, 1, H, W)
assert t.shape == (1, 1, x.shape[0], x.shape[1])
assert float(t[0, 0, 0, 0]) == float(x[0, 0])
logits = model(t)
