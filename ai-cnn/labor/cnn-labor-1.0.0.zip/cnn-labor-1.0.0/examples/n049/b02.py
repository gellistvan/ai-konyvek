# lab/n049_layout/lab_n049.py
import numpy as np
from pathlib import Path

out = Path(__file__).resolve().parent
PROJECT_ROOT = out.parents[1]
out.mkdir(parents=True, exist_ok=True)

H, W = 6, 7

X = np.zeros((2, 1, H, W), dtype=np.float32)       # NCHW, [0,1], CPU
X[0, 0, :, 2] = 1.0                                # 0. kép: függőleges vonal
X[1, 0, 3, :] = np.array([0.2, 0.4, 0.6, 0.8, 1.0, 1.0, 0.8],
                         dtype=np.float32)         # 1. kép: vízszintes sáv

assert X.shape == (2, 1, H, W)
assert X.dtype == np.float32
assert X.min() >= 0.0 and X.max() <= 1.0

Y = np.transpose(X, (0, 2, 3, 1))                 # NHWC nézet
assert Y.shape == (2, H, W, 1)
assert np.shares_memory(X, Y)                     # transzponálás: nézet, nem másolat

# NCHW offset kézzel: off(n,0,h,w)=((n*1+0)*H+h)*W+w
def off(n, h, w):
    return ((n * 1 + 0) * H + h) * W + w

flat = X.reshape(-1)
assert flat[off(1, 3, 4)] == X[1, 0, 3, 4]        # lapított cím ellenőrzése
assert Y[1, 3, 4, 0] == X[1, 0, 3, 4]             # ugyanaz a pixel NHWC-ben

X2 = np.transpose(Y, (0, 3, 1, 2))
assert np.array_equal(X, X2)                      # kettős transzponálás = identitás

np.savez(out / "mini_images.npz", x_nchw=X, x_nhwc=Y)
vissza = np.load(out / "mini_images.npz")
assert np.array_equal(vissza["x_nchw"], X)          # írás-újraolvasás kontroll
assert np.array_equal(vissza["x_nhwc"], Y)
print("NCHW:", X.shape, X.dtype, "min/max:", X.min(), X.max())
print("NHWC:", Y.shape)
print("ellenőrzött pixel X[1,0,3,4] =", X[1, 0, 3, 4])
print("mentve:", (out / "mini_images.npz").relative_to(PROJECT_ROOT))
