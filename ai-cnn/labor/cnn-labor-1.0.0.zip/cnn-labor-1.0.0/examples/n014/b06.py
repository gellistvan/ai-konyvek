def javitott_grad(w):
    w = np.asarray(w, dtype=np.float64)
    return np.array([2.0 * (w[0] - 1.0),
                     4.0 * (w[1] + 1.0)], dtype=np.float64)
