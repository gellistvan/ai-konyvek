# lab/n014_grad_demo.py
# Futtatás: python lab/n014_grad_demo.py
import numpy as np
import matplotlib.pyplot as plt

def f(w):
    w = np.asarray(w, dtype=np.float64)
    return (w[0] - 1.0) ** 2 + 2.0 * (w[1] + 1.0) ** 2

def grad_f(w):
    w = np.asarray(w, dtype=np.float64)
    return np.array([2.0 * (w[0] - 1.0),
                     4.0 * (w[1] + 1.0)], dtype=np.float64)

w0 = np.array([2.0, -2.0], dtype=np.float64)
eta = 0.1
g0 = grad_f(w0)
w_next = w0 - eta * g0
print("w0 =", w0, " f(w0) =", f(w0))
print("grad f(w0) =", g0)
print("w_next =", w_next, " f(w_next) =", f(w_next))

assert abs(f(w0) - 3.0) < 1e-12
assert np.allclose(g0, np.array([2.0, -4.0], dtype=np.float64))
assert abs(f(w_next) - 1.36) < 1e-12

# Szintvonalak és a lépés számított ábrázolása
w1_vals = np.linspace(-1.0, 3.0, 101)
w2_vals = np.linspace(-3.0, 1.0, 101)
W1, W2 = np.meshgrid(w1_vals, w2_vals)
F = (W1 - 1.0) ** 2 + 2.0 * (W2 + 1.0) ** 2
plt.contour(W1, W2, F, levels=[0.25, 0.5, 1.0, 2.0, 4.0])
plt.quiver(w0[0], w0[1], -eta * g0[0], -eta * g0[1],
           angles='xy', scale_units='xy', scale=1,
           color='tab:red', width=0.012)
plt.scatter([w0[0], w_next[0]], [w0[1], w_next[1]], color='black', s=25)
plt.gca().set_aspect('equal')
plt.xlabel('w1')
plt.ylabel('w2')
plt.title('Gradiens lépés: számított szemléltetés')
plt.savefig('lab/n014_grad_step.png', dpi=120)
