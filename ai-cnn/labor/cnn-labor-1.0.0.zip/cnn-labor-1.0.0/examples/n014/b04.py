import numpy as np

def f(w):
    w = np.asarray(w, dtype=np.float64)
    return (w[0] - 1.0) ** 2 + 2.0 * (w[1] + 1.0) ** 2

def numerical_grad(f, w, h=1e-5):
    w = np.asarray(w, dtype=np.float64)
    g = np.zeros_like(w)
    for i in range(w.size):
        e = np.zeros_like(w)
        e[i] = 1.0
        g[i] = (f(w + h * e) - f(w - h * e)) / (2.0 * h)
    return g

w = np.array([2.0, -2.0], dtype=np.float64)
g_num = numerical_grad(f, w)
g_an = np.array([2.0, -4.0], dtype=np.float64)
print("numerikus:", g_num)
print("abszolút hiba:", np.abs(g_num - g_an))
