# labor/n059_adjoint_check.py
import numpy as np
import torch
import torch.nn.functional as F

def make_valid_cc_matrix(n_in: int, k: np.ndarray) -> np.ndarray:
    """1D valid, stride=1, padding=0 cross-correlation matrix."""
    k = np.asarray(k, dtype=np.float64)
    n_out = n_in - k.size + 1
    C = np.zeros((n_out, n_in), dtype=np.float64)
    for i in range(n_out):
        C[i, i:i + k.size] = k
    return C

torch.manual_seed(0)          # nincs véletlen input; a seed a napló része
dtype = torch.float64
device = torch.device("cpu")

k = np.array([2.0, -1.0])
n_in = 4
C = make_valid_cc_matrix(n_in, k)

# upstream gradiens a forward kimeneti terében
g = np.array([-1.0, 6.0, -2.0])
manual = C.T @ g              # (4,)

g_t = torch.tensor(g, dtype=dtype, device=device).view(1, 1, -1)
w_t = torch.tensor(k, dtype=dtype, device=device).view(1, 1, -1)
# stride=1, padding=0, dilation=1, output_padding=0 explicit
library = F.conv_transpose1d(
    g_t, w_t, bias=None, stride=1, padding=0,
    output_padding=0, groups=1, dilation=1,
).cpu().numpy().reshape(-1)

max_abs_diff = float(np.max(np.abs(manual - library)))
assert max_abs_diff < 1e-12, max_abs_diff
print("C^T g manual :", manual)
print("conv_transpose :", library)
print("max_abs_diff   :", max_abs_diff)
print("PASS" if np.allclose(manual, library, atol=1e-12, rtol=0) else "FAIL")
