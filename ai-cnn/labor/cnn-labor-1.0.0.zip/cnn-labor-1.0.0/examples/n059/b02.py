# n059_manual_example.py
import numpy as np

k = np.array([2.0, -1.0])
x = np.array([1.0, 3.0, 0.0, 2.0])
C = np.zeros((3, 4))
C[0, 0:2] = k
C[1, 1:3] = k
C[2, 2:4] = k

y = C @ x                      # [-1, 6, -2]
g = np.array([-1.0, 6.0, -2.0])
dx = C.T @ g                   # [-2, 13, -10, 2]
lhs = float(y @ g)             # 41
rhs = float(x @ dx)            # 41
assert np.allclose(y, [-1.0, 6.0, -2.0])
assert np.allclose(dx, [-2.0, 13.0, -10.0, 2.0])
assert abs(lhs - rhs) == 0.0
print("y =", y)
print("C^T g =", dx)
print("adjoint difference =", abs(lhs - rhs))
