# tasks/n059_f3.py
import numpy as np
import torch
import torch.nn.functional as F

def make_valid_cc_matrix(n_in: int, k: np.ndarray) -> np.ndarray:
    k = np.asarray(k, dtype=np.float64)
    n_out = n_in - k.size + 1
    C = np.zeros((n_out, n_in), dtype=np.float64)
    for i in range(n_out):
        C[i, i:i + k.size] = k
    return C

def check_adjoint(k, n_in=8):
    C = make_valid_cc_matrix(n_in, k)
    n_out = C.shape[0]
    g = np.arange(1.0, n_out + 1.0)
    manual = C.T @ g
    g_t = torch.tensor(g, dtype=torch.float64).view(1, 1, -1)
    w_t = torch.tensor(k, dtype=torch.float64).view(1, 1, -1)
    library = F.conv_transpose1d(
        g_t, w_t, stride=1, padding=0, output_padding=0
    ).numpy().reshape(-1)
    return C, manual, library

for k in ([2.0, -1.0], [0.5, 0.25, 0.5]):
    C, manual, library = check_adjoint(np.array(k))
    ok = np.allclose(manual, library, atol=1e-13, rtol=0)
    assert ok, (k, manual, library)
    print("kernel ", k)
    print("C shape ", C.shape)
    print("max_abs_diff", float(np.max(np.abs(manual - library))))
    print("PASS" if ok else "FAIL")
