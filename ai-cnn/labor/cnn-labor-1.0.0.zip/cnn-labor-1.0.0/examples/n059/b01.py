import torch

torch.manual_seed(20261020)
dt = torch.float64
fwd = torch.nn.Conv2d(2, 3, kernel_size=(2, 3), stride=2, padding=1,
                      bias=False, dtype=dt)
adj = torch.nn.ConvTranspose2d(3, 2, kernel_size=(2, 3), stride=2,
                               padding=1, bias=False, dtype=dt)
print("Conv2d súly:", tuple(fwd.weight.shape))
# (C_out, C_in, kh, kw) = (3, 2, 2, 3)
print("ConvTranspose2d súly:", tuple(adj.weight.shape))
# (in_channels, out_channels/groups, kh, kw) = (3, 2, 2, 3)
with torch.no_grad():
    adj.weight.copy_(fwd.weight)                         # ugyanaz a tensor, csere nélkül

x = torch.randn(1, 2, 7, 6, dtype=dt)                    # C: R^(2*7*6) -> R^(3*H'*W')
y_shape = fwd(x).shape
y = torch.randn(y_shape, dtype=dt)
ct_y = adj(y, output_size=x.shape[-2:])                  # C^T y, a bemenet alakjára
lhs = (fwd(x) * y).sum()                                 # <Cx, y>
rhs = (x * ct_y).sum()                                   # <x, C^T y>
print("<Cx,y> =", lhs.item(), " <x,C^T y> =", rhs.item())
assert torch.allclose(lhs, rhs, rtol=1e-12, atol=1e-12)
