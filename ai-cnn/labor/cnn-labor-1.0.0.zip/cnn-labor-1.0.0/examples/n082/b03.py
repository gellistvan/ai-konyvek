import math

def cosine_lr(step, T, eta_max, eta_min, warmup=0):
    if step < warmup:
        return eta_max * step / warmup if warmup > 0 else eta_max
    t = step - warmup
    T_eff = T - warmup
    if T_eff <= 0:
        raise ValueError("warmup < T szükséges")
    return eta_min + 0.5 * (eta_max - eta_min) * (1 + math.cos(math.pi * t / T_eff))
