# lab/n082_schedule_compare.py
# CPU-futás rögzített seeddel; a kimenet a lenti, mért blokk.
import math
import numpy as np
import torch
from torch import nn
from torch import optim

SEED = 20261020
device = torch.device("cpu")

X = np.load("data/images.npy")          # (360,1,24,24) float32
y = np.load("data/labels.npy")          # (360,) int64
# metadata.csv: split oszlop; a pontos string-feldolgozást a 11.3. alfejezet mutatja.
meta = np.genfromtxt("data/metadata.csv", delimiter=",", dtype=None,
                     names=True, encoding="utf-8")
# A sorrendre nem támaszkodunk: a saját index oszlopa adja a tömbindexet.
if not (len(meta) == len(X) == len(y)):
    raise ValueError("a metadata.csv és a tömbök hossza eltér")
idx_all = meta["index"].astype(np.int64)
if not np.array_equal(np.sort(idx_all), np.arange(len(X))):
    raise ValueError("a metadata.csv index oszlopa nem permutációja a tömbindexeknek")
split = np.asarray(meta["split"]).astype(str)
train_idx = idx_all[split == "train"]
val_idx   = idx_all[split == "val"]
test_idx  = idx_all[split == "test"]

B = 32
STEPS_PER_EPOCH = math.ceil(len(train_idx) / B)   # 8
assert STEPS_PER_EPOCH == 8
EPOCHS = 40
TOTAL_STEPS = EPOCHS * STEPS_PER_EPOCH
WARMUP_STEPS = 3 * STEPS_PER_EPOCH

def make_model():
    return nn.Sequential(nn.Flatten(), nn.Linear(576, 32), nn.ReLU(),
                         nn.Dropout(0.05), nn.Linear(32, 3)).to(device)

def make_lr_lambda(kind):
    if kind == "const":
        return lambda step: 1.0
    if kind == "cosine":
        def f(step):
            if step < WARMUP_STEPS:
                return (step + 1) / WARMUP_STEPS
            t = step - WARMUP_STEPS
            T = TOTAL_STEPS - WARMUP_STEPS
            return 0.5 * (1 + math.cos(math.pi * t / T))
        return f
    raise ValueError(kind)

init_sig = None

def run(kind):
    # Mindkét schedule azonos inicializálást és shuffle-sorrendet kap.
    global init_sig
    torch.manual_seed(SEED)
    model = make_model()
    sig = float(model[1].weight.detach().double().sum())
    if init_sig is None:
        init_sig = sig
    assert sig == init_sig, "a két schedule inicializálása eltér"
    opt = optim.AdamW(model.parameters(), lr=1e-3, weight_decay=0.01)
    sched = optim.lr_scheduler.LambdaLR(opt, make_lr_lambda(kind))
    lossf = nn.CrossEntropyLoss()
    best_val = math.inf
    Xt = torch.from_numpy(X[train_idx])
    yt = torch.from_numpy(y[train_idx])
    Xv = torch.from_numpy(X[val_idx])
    yv = torch.from_numpy(y[val_idx])
    for epoch in range(EPOCHS):
        model.train()
        perm = torch.randperm(len(yt))
        for i in range(0, len(yt), B):
            xb = Xt[perm[i:i+B]]
            yb = yt[perm[i:i+B]]
            opt.zero_grad()
            lossf(model(xb), yb).backward()
            opt.step()
            sched.step()
        model.eval()
        with torch.no_grad():
            val_loss = lossf(model(Xv), yv).item()
        if val_loss < best_val:
            best_val = val_loss
            torch.save({"model": model.state_dict(), "opt": opt.state_dict(),
                        "sched": sched.state_dict(), "epoch": epoch},
                       f"best_{kind}.pt")
    return best_val

const_best = run("const")
cosine_best = run("cosine")
assert math.isfinite(const_best) and math.isfinite(cosine_best)
print("const  best_val_loss:", const_best)
print("cosine best_val_loss:", cosine_best)

def test_eval(kind):
    ckpt = torch.load(f"best_{kind}.pt", weights_only=True)
    model = make_model()
    model.load_state_dict(ckpt["model"])
    model.eval()
    xe = torch.from_numpy(X[test_idx])
    ye = torch.from_numpy(y[test_idx])
    with torch.no_grad():
        logits = model(xe)
        loss = nn.functional.cross_entropy(logits, ye).item()
        acc = (logits.argmax(1) == ye).float().mean().item()
    return loss, acc

for kind in ("const", "cosine"):
    test_loss, test_acc = test_eval(kind)
    print(f"{kind:6s} test_loss: {test_loss:.6f} test_acc: {test_acc:.4f}")
