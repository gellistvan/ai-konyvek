def rossz_adam(theta, m, v, g, t, lr, beta1, beta2, eps):
    m = beta1 * m + (1-beta1) * g
    v = beta2 * v + (1-beta2) * g * g
    m_hat = m / (1 - beta1 ** t)
    theta = theta - lr * m_hat / (np.sqrt(v) + eps)
    return theta, m, v
