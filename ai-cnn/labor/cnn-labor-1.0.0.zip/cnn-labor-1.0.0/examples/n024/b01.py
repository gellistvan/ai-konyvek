#!/usr/bin/env python3
# lab/n024/optim_steps.py
import numpy as np

def adamw_step_scalar(theta, m, v, g, lr, beta1, beta2, lam, t, eps):
    m = beta1 * m + (1.0 - beta1) * g
    v = beta2 * v + (1.0 - beta2) * g * g
    m_hat = m / (1.0 - beta1 ** t)
    v_hat = v / (1.0 - beta2 ** t)
    theta_new = (
        theta
        - lr * lam * theta
        - lr * m_hat / (np.sqrt(v_hat) + eps)
    )
    return theta_new, m, v

def adam_l2_step_scalar(theta, m, v, g, lr, beta1, beta2, lam, t, eps):
    grad = g + lam * theta
    m = beta1 * m + (1.0 - beta1) * grad
    v = beta2 * v + (1.0 - beta2) * grad * grad
    m_hat = m / (1.0 - beta1 ** t)
    v_hat = v / (1.0 - beta2 ** t)
    theta_new = theta - lr * m_hat / (np.sqrt(v_hat) + eps)
    return theta_new, m, v

def main():
    theta0 = np.float64(2.0)
    g = np.float64(1.0)
    lr = np.float64(0.1)
    beta1 = np.float64(0.5)
    beta2 = np.float64(0.5)
    lam = np.float64(0.5)
    eps = np.float64(0.0)

    # AdamW két lépés
    theta = theta0
    m = np.float64(0.0)
    v = np.float64(0.0)
    for t in (1, 2):
        theta, m, v = adamw_step_scalar(
            theta, m, v, g, lr, beta1, beta2, lam, t, eps
        )
        print(f"AdamW step {t}: theta={theta:.12f}, m={m:.12f}, v={v:.12f}")
        expected = {1: 1.8, 2: 1.61}[t]
        assert np.isclose(theta, expected, rtol=0.0, atol=1e-12)

    # Naiv L2 Adam két lépés
    theta = theta0
    m = np.float64(0.0)
    v = np.float64(0.0)
    for t in (1, 2):
        theta, m, v = adam_l2_step_scalar(
            theta, m, v, g, lr, beta1, beta2, lam, t, eps
        )
        print(f"L2 Adam step {t}: theta={theta:.12f}, m={m:.12f}, v={v:.12f}")
        expected = {1: 1.9, 2: 1.800007181071}[t]
        assert np.isclose(theta, expected, rtol=0.0, atol=1e-12)

if __name__ == "__main__":
    main()
