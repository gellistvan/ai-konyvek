import numpy as np

def sgd_momentum_step(theta, buf, g, lr, beta):
    buf = beta * buf + g
    theta = theta - lr * buf
    return theta, buf

theta = np.float64(0.5)
buf = np.float64(0.0)
g = np.float64(0.2)
lr = np.float64(0.1)
beta = np.float64(0.9)

for _ in range(2):
    theta, buf = sgd_momentum_step(theta, buf, g, lr, beta)

print(f"theta={theta:.12f}")
assert np.isclose(theta, 0.442, rtol=0.0, atol=1e-12)
