python optim_steps.py
