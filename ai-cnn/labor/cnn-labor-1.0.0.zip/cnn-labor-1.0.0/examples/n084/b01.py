# munkakönyvtár: lab/
# futtatás: python imbalance_lab.py
import numpy as np, torch, torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset, WeightedRandomSampler

SEED_BASE = 20261020
SEEDS = list(range(SEED_BASE, SEED_BASE + 5))
device = torch.device("cpu")

images = np.load("data/images.npy").astype(np.float32)   # (360,1,24,24)
labels = np.load("data/labels.npy").astype(np.int64)     # (360,)
meta = np.genfromtxt("data/metadata.csv", delimiter=",", dtype=None,
                     names=True, encoding="utf-8")
order = meta["index"].astype(np.int64)
if not np.array_equal(np.sort(order), np.arange(len(images))):
    raise ValueError("a metadata.csv index oszlopa nem permutációja a tömbindexeknek")
split = np.asarray(meta["split"]).astype(str)
cls = np.asarray(meta["label"]).astype(np.int64)
scene = np.asarray(meta["scene_id"]).astype(str)

train_rows = np.where(split == "train")[0]
scenes_of = {k: sorted(set(scene[train_rows[cls[train_rows] == k]])) for k in range(3)}
keep = set(scenes_of[0][:40]) | set(scenes_of[1][:5]) | set(scenes_of[2][:5])
imb_rows = np.array([i for i in train_rows if scene[i] in keep])
val_rows = np.where(split == "val")[0]
test_rows = np.where(split == "test")[0]
Xtr, ytr = images[order[imb_rows]], labels[order[imb_rows]]
Xva, yva = images[order[val_rows]], labels[order[val_rows]]
Xte, yte = images[order[test_rows]], labels[order[test_rows]]
assert (len(Xtr), len(Xva), len(Xte)) == (100, 60, 60)
assert np.bincount(ytr, minlength=3).tolist() == [80, 10, 10]
# A teszt split betöltve, de a modellválasztásban nem szerepel.

counts = np.bincount(ytr, minlength=3).astype(np.float32)
class_w = torch.tensor(len(ytr) / (3.0 * counts))           # N/(K*n_k)
sample_w = torch.tensor(1.0 / counts[ytr])                  # példánkénti húzási súly
w_val = torch.tensor(np.array([0.8, 0.1, 0.1]) / (1.0 / 3.0), dtype=torch.float32)

class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        # padding nélküli konvolúció: 24 -> 22 -> 11 -> 9 -> 4, ezért 16*4*4
        self.net = nn.Sequential(
            nn.Conv2d(1, 8, 3), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(8, 16, 3), nn.ReLU(), nn.MaxPool2d(2),
            nn.Flatten(), nn.Linear(16 * 4 * 4, 3))
    def forward(self, x):
        return self.net(x)

def predict(model, X):
    model.eval()
    with torch.no_grad():
        logits = model(X)
        probs = torch.softmax(logits, dim=1)
    return logits, probs

def class_recalls(pred, y):
    return np.array([(pred[y == k] == k).mean() if (y == k).any() else 0.0
                     for k in range(3)])

def macro_f1(pred, y):
    f1 = []
    for k in range(3):
        tp = np.sum((pred == k) & (y == k))
        fp = np.sum((pred == k) & (y != k))
        fn = np.sum((pred != k) & (y == k))
        f1.append(2 * tp / (2 * tp + fp + fn))
    return float(np.mean(f1))

def ece(probs, y, n_bins=8):
    conf = probs.max(1)
    correct = (probs.argmax(1) == y).astype(float)
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    total = 0.0
    for b in range(n_bins):
        hi = edges[b + 1]
        m = (conf >= edges[b]) & (conf <= hi if b == n_bins - 1 else conf < hi)
        if m.sum() == 0:
            continue
        total += m.mean() * abs(correct[m].mean() - conf[m].mean())
    return total

def run(mode, seed):
    torch.manual_seed(seed)
    model = SmallCNN().to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=0.0)
    if mode == "weighted":
        lossf = nn.CrossEntropyLoss(weight=class_w)
    else:
        lossf = nn.CrossEntropyLoss()
    ds = TensorDataset(torch.from_numpy(Xtr), torch.from_numpy(ytr))
    if mode == "sampler":
        gen = torch.Generator().manual_seed(seed)
        sampler = WeightedRandomSampler(sample_w, num_samples=len(sample_w),
                                        replacement=True, generator=gen)
        loader = DataLoader(ds, batch_size=24, sampler=sampler)
    else:
        loader = DataLoader(ds, batch_size=24, shuffle=True)
    best_acc, best_state, last_loss = -1.0, None, None
    for ep in range(30):
        model.train()
        total, nb = 0.0, 0
        for xb, yb in loader:
            opt.zero_grad()
            loss = lossf(model(xb), yb)
            loss.backward()
            opt.step()
            total += loss.item()
            nb += 1
        last_loss = total / nb
        _, probs = predict(model, torch.from_numpy(Xva))
        acc = class_recalls(probs.argmax(1).numpy(), yva).mean()
        if acc > best_acc:
            best_acc = acc
            best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
    model.load_state_dict(best_state)
    _, probs = predict(model, torch.from_numpy(Xva))
    pred = probs.argmax(1).numpy()
    recalls = class_recalls(pred, yva)
    weights = w_val[yva].numpy()
    return {
        "loss": last_loss,
        "wacc": float((weights * (pred == yva)).sum() / weights.sum()),
        "bacc": float(recalls.mean()),
        "f1": macro_f1(pred, yva),
        "ece": ece(probs.numpy(), yva),
        "correct": (pred == yva).astype(float),
    }

def scene_ci(diff_per_image, scenes, n_boot=10000, seed=7):
    uniq = sorted(set(scenes))
    per_scene = np.array([diff_per_image[scenes == s].mean() for s in uniq])
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(per_scene), size=(n_boot, len(per_scene)))
    means = per_scene[idx].mean(1)
    return np.percentile(means, [2.5, 97.5])

val_scenes = scene[val_rows]
res = {m: [] for m in ("base", "weighted", "sampler")}
for mode in res:
    for seed in SEEDS:
        r = run(mode, seed)
        res[mode].append(r)
        print(f"{mode:8s} seed={seed} loss={r['loss']:.4f} "
              f"wacc={r['wacc']:.3f} bacc={r['bacc']:.3f} "
              f"f1={r['f1']:.3f} ece={r['ece']:.3f}")

print()
for mode, rows in res.items():
    for key in ("loss", "wacc", "bacc", "f1", "ece"):
        v = np.array([r[key] for r in rows])
        print(f"{mode:8s} {key:5s} {v.mean():.4f} +- {v.std(ddof=1):.4f}")

print()
base_correct = np.array([r["correct"] for r in res["base"]])
for mode in ("weighted", "sampler"):
    other = np.array([r["correct"] for r in res[mode]])
    diff = (other - base_correct).mean(0)   # seedekre átlagolt képenkénti különbség
    lo, hi = scene_ci(diff, val_scenes)
    print(f"{mode:8s} bacc diff vs base: {diff.mean():+.4f} "
          f"95% CI [{lo:+.4f}, {hi:+.4f}]")
