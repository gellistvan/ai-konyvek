# lab/f3_weighted_ce.py — futtatható lokálisan
import torch
import torch.nn.functional as F

torch.manual_seed(0)
logits = torch.randn(6, 3, dtype=torch.float32)  # N x K
target = torch.tensor([0, 0, 0, 0, 1, 2], dtype=torch.int64)
train_counts = torch.tensor([80, 10, 10], dtype=torch.float32)
K = 3
# A súlyokat a TRAIN teljes osztálygyakorisága, nem ez a mini-batch adja.
w = train_counts.sum() / (K * train_counts)  # shape (3,)

# 1) gradient scaling konvenció
loss_each = F.cross_entropy(logits, target, reduction='none')  # shape (6,)
L_gradscale = torch.mean(w[target] * loss_each)

# 2) PyTorch beépített mean reduction súllyal
L_torch = F.cross_entropy(logits, target, weight=w, reduction='mean')

# Ellenőrzés: L_torch = sum(w_i*l_i) / sum(w_i)
L_numerator = torch.sum(w[target] * loss_each)
L_denom = torch.sum(w[target])
L_expected = L_numerator / L_denom

print(f"Gradient scaling : {L_gradscale.item():.6f}")
print(f"PyTorch mean     : {L_torch.item():.6f}")
print(f"Elvárt torch mean: {L_expected.item():.6f}")
print(f"Arány           : {L_gradscale.item() / L_torch.item():.6f}")
print(f"Batch súlyösszeg : {L_denom.item():.6f}")
