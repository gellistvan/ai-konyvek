# target_train: az imbalanced dataset minden példájához tartozó osztályindex
sample_weights = 1.0 / class_counts[target_train]
sampler = WeightedRandomSampler(weights=sample_weights, num_samples=len(dataset), replacement=True)
loss_fn = nn.CrossEntropyLoss(weight=1.0 / class_counts)
