# lab/n075/n075_scale_bench.py
import statistics
import time
import torch
from torch import nn

torch.set_num_threads(1)

def make_cnn(width, base=(16, 32, 64, 128), num_classes=10):
    ch = [max(1, int(c * width)) for c in base]
    layers, prev = [], 3
    for c in ch:
        layers += [nn.Conv2d(prev, c, 3, padding=1),
                   nn.BatchNorm2d(c), nn.ReLU()]
        prev = c
    layers += [nn.AdaptiveAvgPool2d(1), nn.Flatten(),
               nn.Linear(prev, num_classes)]
    return nn.Sequential(*layers)

def count_params(model):
    return sum(p.numel() for p in model.parameters())

def bench_forward(model, x, warmup=5, iters=30):
    """Egy forward átlaga, mediánja és szórása ezredmásodpercben."""
    model.eval()
    with torch.no_grad():
        for _ in range(warmup):
            model(x)
        times = []
        for _ in range(iters):
            t0 = time.perf_counter()
            model(x)
            times.append(1000.0 * (time.perf_counter() - t0))
    return (statistics.mean(times), statistics.median(times),
            statistics.stdev(times))

torch.manual_seed(0)
x = torch.randn(4, 3, 24, 24, dtype=torch.float32)
expected = {1.0: 99_210, 1.4: 190_731}
for w in (1.0, 1.4):
    m = make_cnn(w)
    assert count_params(m) == expected[w]
    m.eval()
    with torch.no_grad():
        assert tuple(m(x).shape) == (4, 10)
    mean, med, sd = bench_forward(m, x)
    print(f"width={w:.1f} params={count_params(m):,} "
          f"mean={mean:.2f} ms median={med:.2f} ms std={sd:.2f} ms")
