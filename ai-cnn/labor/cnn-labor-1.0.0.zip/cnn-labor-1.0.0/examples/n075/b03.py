def scale_estimate(M0, w, d, r):
    return d * (w ** 2) * (r ** 2) * M0

out = scale_estimate(172800, 2.0, 1.0, 2.0)
assert abs(out - 2_764_800) / 2_764_800 < 1e-3

# Független ellenőrzés: a stem–body bontásból számolt MAC, ahol a stem
# w-vel (egy bemeneti csatorna), a body d*w^2-tel, és mindkettő r^2-tel skálázódik.
exact = 2 * 6912 * 2**2 + 1 * 2**2 * 165_888 * 2**2
assert exact == 2_709_504
assert abs(out - exact) / exact < 0.03
