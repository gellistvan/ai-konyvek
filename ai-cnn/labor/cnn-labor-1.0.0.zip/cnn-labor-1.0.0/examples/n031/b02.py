# munkakönyvtár: lab/
# Futtatható labor; a mért kimenet a kód után látható.
import copy
import csv
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

seed = 20261020
torch.manual_seed(seed)
np.random.seed(seed)
device = torch.device("cpu")
torch.set_num_threads(1)
dtype = torch.float32

DATA = Path(__file__).resolve().parent / "data"

images = np.load(DATA / "images.npy").astype(np.float32)
labels = np.load(DATA / "labels.npy").astype(np.int64)
# Fejléc szerinti oszlopnevek; a sorok sorrendje az images tömb sorrendje.
with open(DATA / "metadata.csv", newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    assert reader.fieldnames == ["index", "scene_id", "view_id", "label",
                                 "split", "xmin", "ymin", "xmax", "ymax"], \
        "váratlan metadata-fejléc"
    meta_rows = list(reader)
assert len(images) == len(labels) == len(meta_rows), "eltérő hosszúságú adat"
meta_index = np.array([int(row["index"]) for row in meta_rows])
assert np.array_equal(meta_index, np.arange(len(images))), \
    "a metadata index oszlopa nem követi az images tömb sorrendjét"
split = np.array([row["split"] for row in meta_rows])
assert set(split) <= {"train", "val", "test"}
train_idx = np.where(split == "train")[0]
val_idx = np.where(split == "val")[0]
test_idx = np.where(split == "test")[0]
assert len(train_idx) == 240 and len(val_idx) == 60 and len(test_idx) == 60

X_train = torch.tensor(images[train_idx], dtype=dtype, device=device)
y_train = torch.tensor(labels[train_idx], dtype=torch.long, device=device)
X_val = torch.tensor(images[val_idx], dtype=dtype, device=device)
y_val = torch.tensor(labels[val_idx], dtype=torch.long, device=device)
X_test = torch.tensor(images[test_idx], dtype=dtype, device=device)
y_test = torch.tensor(labels[test_idx], dtype=torch.long, device=device)

def make_model(hidden):
    return nn.Sequential(
        nn.Flatten(),
        nn.Linear(24 * 24, hidden),
        nn.ReLU(),
        nn.Linear(hidden, 3),
    ).to(device)

def evaluate(model, X, y):
    model.eval()
    with torch.no_grad():
        pred = model(X).argmax(dim=1)
    return (pred == y).float().mean().item()

def make_loader():
    generator = torch.Generator()
    generator.manual_seed(seed)
    return DataLoader(TensorDataset(X_train, y_train),
                      batch_size=32, shuffle=True, generator=generator)

criterion = nn.CrossEntropyLoss()
results = []
for hidden in [16, 32]:
    for lam in [0.0, 1e-4, 1e-3]:
        # Azonos recept minden konfigurációhoz: seed, init és batch-sorrend.
        torch.manual_seed(seed)
        np.random.seed(seed)
        train_loader = make_loader()
        model = make_model(hidden)
        optimizer = torch.optim.SGD(model.parameters(), lr=0.01,
                                    weight_decay=lam)
        best_acc, best_state = -1.0, None
        for _ in range(30):
            model.train()
            for xb, yb in train_loader:
                optimizer.zero_grad()
                loss = criterion(model(xb), yb)
                loss.backward()
                optimizer.step()
            val_acc = evaluate(model, X_val, y_val)
            if val_acc > best_acc:
                best_acc = val_acc
                best_state = copy.deepcopy(model.state_dict())
        assert best_state is not None
        model.load_state_dict(best_state)
        results.append({"hidden": hidden, "lam": lam,
                        "val_acc": best_acc, "state": best_state})
        print(f"hidden={hidden:2d} lam={lam:g} val_acc={best_acc:.3f}")

# Holtversenynél a kisebb lam nyer; az első maximum marad meg.
best = max(results, key=lambda r: (r["val_acc"], -r["lam"]))
model = make_model(best["hidden"])
model.load_state_dict(best["state"])
test_acc = evaluate(model, X_test, y_test)
assert 0.0 <= test_acc <= 1.0
print("választott:", best["hidden"], best["lam"],
      f"val_acc={best['val_acc']:.3f}")
print(f"test_acc={test_acc:.3f}")
print("seed:", seed, "torch:", torch.__version__, "numpy:", np.__version__)
