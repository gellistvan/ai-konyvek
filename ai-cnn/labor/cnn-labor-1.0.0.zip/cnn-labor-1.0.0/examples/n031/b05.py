# munkakönyvtár: lab/
# Szimuláció: M=20, n_val=5, p=0.5, 10000 ismétlés.
# Futás: python sim_validation_bias.py
import numpy as np

rng = np.random.default_rng(20261020)
M, n_val, p, reps = 20, 5, 0.5, 10_000
val_max = np.empty(reps, dtype=np.float64)
test_acc = np.empty(reps, dtype=np.float64)

for r in range(reps):
    # validation predikciók: M x n_val, Bernoulli(p)
    pred = rng.random((M, n_val), dtype=np.float64) < p
    val_acc = pred.mean(axis=1)          # shape (M,)
    best = int(np.argmax(val_acc))       # a legjobb modell
    val_max[r] = val_acc[best]
    # tesztpontosság: egy újabb Bernoulli(p) minta a kiválasztott modellre
    test_acc[r] = rng.binomial(1, p)

print("átlagos legjobb validation accuracy:", val_max.mean())
print("átlagos test accuracy:", test_acc.mean())
