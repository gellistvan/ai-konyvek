# munkakönyvtár: lab/
# Futtatva; a kimenet a fenti kézzel levezetett értékeket adja vissza.
from fractions import Fraction
from math import comb

M, n_val, p = 3, 2, Fraction(1, 2)

def binom_prob(n, k):
    return Fraction(comb(n, k)) * p**k * (1 - p)**(n - k)

# P(max <= v) = P(Y <= v)^M, v itt a pontosság (0, 0.5, 1)
def cdf_max(v):
    # v pontosság; a mintaelemszám egész, ezért az ellenőrzés kizárja,
    # hogy float kerekítés miatt rossz felső indexet használjunk.
    k_max = v * n_val
    assert Fraction(k_max) == k_max, "a v*n_val szorzatnak egésznek kell lennie"
    return sum(binom_prob(n_val, k) for k in range(int(k_max) + 1)) ** M

cdf_0 = cdf_max(0)                 # P(max = 0)
cdf_half = cdf_max(Fraction(1, 2)) # P(max <= 0.5)
cdf_1 = cdf_max(1)                 # P(max <= 1) = 1

p_0 = cdf_0
p_half = cdf_half - cdf_0
p_1 = cdf_1 - cdf_half
expected_max = p_0 * 0 + p_half * Fraction(1, 2) + p_1 * 1
print(p_0, p_half, p_1, expected_max, float(expected_max))
# Kimenet: 1/64 13/32 37/64 25/32 0.78125
