# lab/n058_dx_check.py
import numpy as np
import torch
import torch.nn.functional as F

rng = np.random.default_rng(20261020)

def conv2d_output_shape(H, W, kh, kw, stride, padding, dilation):
    Hout = (H + 2 * padding - dilation * (kh - 1) - 1) // stride + 1
    Wout = (W + 2 * padding - dilation * (kw - 1) - 1) // stride + 1
    return Hout, Wout

def conv2d_input_grad_numpy(D, K, H, W, stride, padding, dilation):
    # D: (N, Cout, Hout, Wout), K: (Cout, Cin, kh, kw)
    N, Cout, Hout, Wout = D.shape
    Cout2, Cin, kh, kw = K.shape
    assert Cout2 == Cout
    dX = np.zeros((N, Cin, H, W), dtype=D.dtype)
    for n in range(N):
        for o in range(Cout):
            for i in range(Hout):
                for j in range(Wout):
                    du = D[n, o, i, j]
                    for c in range(Cin):
                        for a in range(kh):
                            for b in range(kw):
                                u = i * stride + a * dilation - padding
                                v = j * stride + b * dilation - padding
                                if 0 <= u < H and 0 <= v < W:
                                    dX[n, c, u, v] += du * K[o, c, a, b]
    return dX

N, Cin, Cout, H, W = 2, 3, 4, 6, 7
kh, kw = 3, 3

for stride in (1, 2):
    for padding in (0, 1):
        for dilation in (1, 2):
            Hout, Wout = conv2d_output_shape(H, W, kh, kw, stride, padding, dilation)
            if Hout <= 0 or Wout <= 0:
                continue
            X_np = rng.standard_normal((N, Cin, H, W)).astype(np.float64)
            K_np = rng.standard_normal((Cout, Cin, kh, kw)).astype(np.float64)
            b_np = rng.standard_normal(Cout).astype(np.float64)
            D_np = rng.standard_normal((N, Cout, Hout, Wout)).astype(np.float64)

            dX_np = conv2d_input_grad_numpy(D_np, K_np, H, W, stride, padding, dilation)

            X_t = torch.tensor(X_np, dtype=torch.float64, requires_grad=True)
            K_t = torch.tensor(K_np, dtype=torch.float64, requires_grad=True)
            b_t = torch.tensor(b_np, dtype=torch.float64, requires_grad=True)
            Y_t = F.conv2d(X_t, K_t, b_t, stride=stride, padding=padding, dilation=dilation)
            D_t = torch.tensor(D_np, dtype=torch.float64)
            loss = (Y_t * D_t).sum()
            loss.backward()
            dX_t = X_t.grad

            diff = np.max(np.abs(dX_np - dX_t.detach().numpy()))
            assert dX_np.shape == (N, Cin, H, W)
            assert diff < 1e-12, diff
            print(f"s={stride} p={padding} d={dilation} "
                  f"Hout,Wout={Hout},{Wout} max_abs_diff={diff:.3e}")
