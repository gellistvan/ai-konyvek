python n058_dx_check.py
