# lab/n058_f3_1d.py
import numpy as np
import torch
import torch.nn.functional as F

rng = np.random.default_rng(20261020)

def conv1d_input_grad_numpy(D, K, H, stride, padding, dilation):
    N, Cout, Hout = D.shape
    Cout2, Cin, kh = K.shape
    assert Cout2 == Cout
    dX = np.zeros((N, Cin, H), dtype=D.dtype)
    for n in range(N):
        for o in range(Cout):
            for i in range(Hout):
                for c in range(Cin):
                    for a in range(kh):
                        u = i * stride + a * dilation - padding
                        if 0 <= u < H:
                            dX[n, c, u] += D[n, o, i] * K[o, c, a]
    return dX

N, Cin, Cout, H = 1, 2, 2, 5
kh, stride, padding, dilation = 3, 2, 1, 1
Hout = (H + 2 * padding - dilation * (kh - 1) - 1) // stride + 1

X_np = rng.standard_normal((N, Cin, H)).astype(np.float64)
K_np = rng.standard_normal((Cout, Cin, kh)).astype(np.float64)
b_np = rng.standard_normal(Cout).astype(np.float64)
D_np = rng.standard_normal((N, Cout, Hout)).astype(np.float64)

dX_np = conv1d_input_grad_numpy(D_np, K_np, H, stride, padding, dilation)

X_t = torch.tensor(X_np, dtype=torch.float64, requires_grad=True)
K_t = torch.tensor(K_np, dtype=torch.float64, requires_grad=True)
b_t = torch.tensor(b_np, dtype=torch.float64, requires_grad=True)
Y_t = F.conv1d(X_t, K_t, b_t, stride=stride, padding=padding, dilation=dilation)
D_t = torch.tensor(D_np, dtype=torch.float64)
loss = (Y_t * D_t).sum()
loss.backward()

diff = np.max(np.abs(dX_np - X_t.grad.detach().numpy()))
assert diff < 1e-12, diff
print(f"Hout={Hout} max_abs_diff={diff:.3e}")
