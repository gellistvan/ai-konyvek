if padding > 0:
    dX = full[:, :, padding:-padding, padding:-padding]
else:
    dX = full
