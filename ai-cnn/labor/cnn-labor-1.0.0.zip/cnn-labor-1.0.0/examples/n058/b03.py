# HIBA: p=0 esetén a 0:-0 szelet üres.
dX = full[:, :, padding:-padding, padding:-padding]
