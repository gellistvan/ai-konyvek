eps = np.sqrt(np.log(2 / alpha) / (2 * N))
cover = np.mean(np.abs(x.mean(axis=1) - p) < eps)
