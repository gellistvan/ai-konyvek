"""Az MLE mintavételi eloszlása ismételt mintavétellel.

N=20, p0=0.7, R=1000 független minta; tapasztalati szórás és hisztogram.
"""
from __future__ import annotations

import numpy as np

rng = np.random.default_rng(20261020)
N = 20
R = 1000
p0 = 0.7

x = rng.binomial(1, p0, size=(R, N))
p_hat = x.mean(axis=1)
se_theory = np.sqrt(p0 * (1 - p0) / N)

print(f"p0={p0}, N={N}, R={R}")
print("tapasztalati szórás:", p_hat.std(ddof=1))
print("elméleti standard hiba:", se_theory)

# Egész számlálóból képzett, a lehetséges p_hat értékekkel egyező osztályhatárok.
bins = np.arange(5, 21) / 20.0
hist, edges = np.histogram(p_hat, bins=bins)
for lo, hi, cnt in zip(edges[:-1], edges[1:], hist):
    right = "]" if hi == 1.0 else ")"
    print(f"[{lo:.2f},{hi:.2f}{right}: {cnt}")
print("0.25 alatt:", (p_hat < 0.25).sum())

assert p_hat.shape == (R,)
assert abs(p_hat.std(ddof=1) - se_theory) < 0.01
assert hist.sum() + (p_hat < 0.25).sum() == R
print("ellenorzes: alak, Monte-Carlo-hiba es hisztogram-lefedettseg rendben")
