"""Wald-intervallum Bernoulli-mintára."""
from __future__ import annotations

import numpy as np
from scipy.stats import norm


def wald_interval(x: np.ndarray, alpha: float) -> tuple[float, float]:
    """A Wald-féle konfidenciaintervallum [L, U] végpontjai.

    x: (N,) alakú 0/1 értékű minta; a függvény float64-re konvertálja.
    alpha: a hiba valószínűsége, pl. 0.05.
    """
    x = np.asarray(x, dtype=np.float64)
    N = x.shape[0]
    p_hat = x.mean()
    se = np.sqrt(p_hat * (1 - p_hat) / N)
    z = norm.ppf(1 - alpha / 2)
    L = max(0.0, p_hat - z * se)
    U = min(1.0, p_hat + z * se)
    return L, U


x = np.array([1, 0, 0, 1], dtype=np.float64)
alpha = 0.05
L, U = wald_interval(x, alpha)
print(f"L={L:.6f}, U={U:.6f}")
