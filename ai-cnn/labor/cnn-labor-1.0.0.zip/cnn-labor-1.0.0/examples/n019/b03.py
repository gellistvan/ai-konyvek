"""Bernoulli-becslő lefedettségi szimulációja.

A kód a Wald-intervallum és a Hoeffding-intervallum lefedettségét
becsüli ismételt mintavétellel. A kimeneteket a konzolra írja.
"""
from __future__ import annotations

import numpy as np
from scipy.stats import norm

rng = np.random.default_rng(20261020)
N = 20
R = 2000
alpha = 0.05
z = norm.ppf(1 - alpha / 2)
# 99 pontos rács; egész számlálóból osztva elkerüljük a float-lépés kerekítését
p_grid = np.arange(1, 100) / 100.0

cover_wald = np.zeros_like(p_grid)
cover_hoeff = np.zeros_like(p_grid)

for idx, p in enumerate(p_grid):
    x = rng.binomial(1, p, size=(R, N))
    p_hat = x.mean(axis=1)                       # egyszer számoljuk ki
    se = np.sqrt(np.clip(p_hat * (1 - p_hat), 0.0, 1.0) / N)
    low = np.maximum(0.0, p_hat - z * se)        # [0,1]-re metszés
    high = np.minimum(1.0, p_hat + z * se)
    cover_wald[idx] = np.mean((low <= p) & (p <= high))
    eps = np.sqrt(np.log(2 / alpha) / (2 * N))
    cover_hoeff[idx] = np.mean(np.abs(p_hat - p) <= eps)

print(f"N={N}, R={R}, alpha={alpha}")
print("Legkisebb Wald-lefedettség:", cover_wald.min())
print("Legnagyobb Wald-lefedettség:", cover_wald.max())
print("Legkisebb Hoeffding-lefedettség:", cover_hoeff.min())
print("Legnagyobb Hoeffding-lefedettség:", cover_hoeff.max())
print("Wald-lefedettség p=0.1-nél:", cover_wald[9])
print("Wald-lefedettség p=0.5-nél:", cover_wald[49])

# Beépített ellenőrzések: alak, [0,1] tartomány, Hoeffding tűréshatár
assert cover_wald.shape == p_grid.shape == (99,)
assert np.all((cover_wald >= 0.0) & (cover_wald <= 1.0))
assert np.all((cover_hoeff >= 0.0) & (cover_hoeff <= 1.0))
assert cover_hoeff.min() >= 1 - alpha - 5 * np.sqrt(alpha * (1 - alpha) / R)
print("ellenorzes: alak, lefedettsegi tartomany es Hoeffding-tures rendben")
