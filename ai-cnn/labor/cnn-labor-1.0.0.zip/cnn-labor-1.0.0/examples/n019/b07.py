cover = np.mean(np.abs(x.mean(axis=1) - p) <= eps)
