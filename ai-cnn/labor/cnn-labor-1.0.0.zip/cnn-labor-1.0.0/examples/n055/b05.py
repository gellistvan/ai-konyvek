c_in, c_out, kh, kw = 3, 4, 3, 3
groups, bias = 1, True
n, h_out, w_out = 2, 8, 8
params_ok = c_out * (c_in // groups) * kh * kw + (c_out if bias else 0)
macs_ok = n * c_out * h_out * w_out * (c_in // groups) * kh * kw
assert (params_ok, macs_ok) == (112, 13824), (params_ok, macs_ok)
