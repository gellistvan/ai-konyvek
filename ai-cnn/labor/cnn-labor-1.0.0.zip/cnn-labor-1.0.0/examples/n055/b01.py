# lab/n055/param_mac_check.py
# Munkakönyvtár: lab/n055
# Környezet: Python 3.12.3, torch 2.15.0+cpu, CPU, float32.
import torch
import torch.nn as nn

def conv_output_size(h, k, p, s):
    return (h + 2*p - k) // s + 1

def conv_mac(n, c_out, h_out, w_out, c_in_per_group, kh, kw):
    return n * c_out * h_out * w_out * c_in_per_group * kh * kw

def report(conv, x):
    with torch.no_grad():
        y = conv(x)
    n, c_out, h_out, w_out = y.shape
    c_in_per_group = conv.in_channels // conv.groups
    params = sum(t.numel() for t in conv.parameters())
    macs = conv_mac(n, c_out, h_out, w_out, c_in_per_group,
                    conv.kernel_size[0], conv.kernel_size[1])
    act_bytes = y.numel() * y.element_size()
    return params, macs, tuple(y.shape), act_bytes

class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 4, 3, padding=1)
        self.conv2 = nn.Conv2d(4, 8, 3, padding=1, stride=2)

    def forward(self, x):
        x = torch.relu(self.conv1(x))
        return self.conv2(x)

model = SmallCNN()
total_params = sum(t.numel() for t in model.parameters())
assert total_params == 408, total_params
print("Teljes paraméterszám:", total_params)

x1 = torch.zeros(2, 3, 8, 8, dtype=torch.float32)
x2 = torch.zeros(2, 4, 8, 8, dtype=torch.float32)
for name, conv, x in [("conv1", model.conv1, x1),
                      ("conv2", model.conv2, x2)]:
    p, m, shape, abytes = report(conv, x)
    print(name, "params=", p, "mac=", m, "shape=", shape,
          "activation_bytes=", abytes)
    assert (shape[2], shape[3]) == (
        conv_output_size(x.shape[2], conv.kernel_size[0],
                         conv.padding[0], conv.stride[0]),
        conv_output_size(x.shape[3], conv.kernel_size[1],
                         conv.padding[1], conv.stride[1]))
