params_bad = c_out * c_in * kh * kw       # (1)
macs_bad = c_out * h_out * w_out * kh * kw  # (2)
