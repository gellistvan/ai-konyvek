# lab/n055/feladat_f3.py
import torch
import torch.nn as nn

def conv_stats(model, x):
    total_params = total_macs = total_act_bytes = 0
    h = x
    with torch.no_grad():
        for layer in model:
            if isinstance(layer, nn.Conv2d):
                total_params += sum(p.numel() for p in layer.parameters())
                h = layer(h)
                n, c_out, h_out, w_out = h.shape
                c_in_per_group = layer.in_channels // layer.groups
                total_macs += n * c_out * h_out * w_out * c_in_per_group \
                              * layer.kernel_size[0] * layer.kernel_size[1]
                total_act_bytes += h.numel() * h.element_size()
            elif isinstance(layer, nn.ReLU):
                h = layer(h)  # az alak nem változik
            else:
                raise TypeError(f"Nem kezelt réteg: {type(layer)}")
    return total_params, total_macs, total_act_bytes

model = nn.Sequential(
    nn.Conv2d(3, 4, 3, padding=1),
    nn.ReLU(),
    nn.Conv2d(4, 8, 3, padding=1, stride=2),
)
x = torch.zeros(2, 3, 8, 8, dtype=torch.float32)
stats = conv_stats(model, x)
print(stats)
assert stats == (408, 23040, 3072), stats
