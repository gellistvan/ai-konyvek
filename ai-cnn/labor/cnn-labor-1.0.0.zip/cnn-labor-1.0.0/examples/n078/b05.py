import torch
import torch.nn as nn

torch.manual_seed(0)
bn = nn.BatchNorm2d(4)
bn.weight.requires_grad_(False)
bn.bias.requires_grad_(False)

bn.train()
before = bn.running_mean.clone()
bn(torch.randn(2, 4, 3, 3))
changed_train = not torch.equal(before, bn.running_mean)
print("train mód, változott:", changed_train)
assert changed_train

bn.eval()
before = bn.running_mean.clone()
bn(torch.randn(2, 4, 3, 3))
changed_eval = not torch.equal(before, bn.running_mean)
print("eval mód, változott:", changed_eval)
assert not changed_eval
