def train_head_only_fixed(model, loader, epochs):
    for p in model.backbone.parameters():
        p.requires_grad = False
    for p in model.head.parameters():
        p.requires_grad = True
    for epoch in range(epochs):
        model.train()
        model.backbone.eval()     # minden epochban, a model.train() után
        ...
