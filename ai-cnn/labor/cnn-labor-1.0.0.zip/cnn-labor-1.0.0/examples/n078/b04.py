def train_head_only_bad(model, loader, epochs):
    model.train()                       # hiba itt
    for p in model.backbone.parameters():
        p.requires_grad = False
    for p in model.head.parameters():
        p.requires_grad = True
    opt = torch.optim.Adam(model.head.parameters(), lr=0.01)
    ...
