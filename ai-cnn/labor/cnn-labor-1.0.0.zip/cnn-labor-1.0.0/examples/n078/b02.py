import csv
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

SEED = 20261020
BASE = Path(__file__).resolve().parent      # lab/
DATA = BASE / "data"
device = torch.device("cpu")
dtype = torch.float32

# GlyphLab betöltés
X = np.load(DATA / "images.npy").astype(np.float32)    # (360,1,24,24)
y = np.load(DATA / "labels.npy").astype(np.int64)      # (360,)
with open(DATA / "metadata.csv", newline="", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))
# A sorrendre nem támaszkodunk: a saját index oszlopa adja a tömbindexet.
if not rows or "index" not in rows[0]:
    raise ValueError("a metadata.csv-ből hiányzik az index oszlop")
if not (len(rows) == len(X) == len(y)):
    raise ValueError("a metadata.csv és a tömbök hossza eltér")
idx = np.array([int(r["index"]) for r in rows], dtype=np.int64)
if not np.array_equal(np.sort(idx), np.arange(len(X))):
    raise ValueError("a metadata.csv index oszlopa nem permutációja a tömbindexeknek")
split = np.array([r["split"] for r in rows])

X = torch.from_numpy(X).to(device)
y = torch.from_numpy(y).to(device)
train_idx = idx[split == "train"]
val_idx   = idx[split == "val"]
assert (len(train_idx), len(val_idx)) == (240, 60)
BATCH = 32

def train_order(epoch):
    # Külön generátor: a sorrend nem függ a globális RNG állapotától, ezért
    # mindkét változat ugyanazt a batch-sorrendet kapja.
    g = torch.Generator().manual_seed(SEED + epoch)
    return torch.randperm(len(train_idx), generator=g)

val_loader = DataLoader(TensorDataset(X[val_idx], y[val_idx]),
                        batch_size=64, shuffle=False)

class GlyphLabCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.backbone = nn.Sequential(
            nn.Conv2d(1, 8, 3, stride=2, padding=1),
            nn.BatchNorm2d(8),
            nn.ReLU(),
            nn.Conv2d(8, 16, 3, stride=2, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(),
        )
        self.head = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(16, 3),
        )
    def forward(self, x):
        return self.head(self.backbone(x))

def set_frozen_layerwise(model, backbone_slice, head_trainable):
    # backbone_slice=None: egyetlen backbone-paraméter sem aktív (head-only).
    for p in model.parameters():
        p.requires_grad = False
    if backbone_slice is not None:
        for p in backbone_slice.parameters():
            p.requires_grad = True
    for p in model.head.parameters():
        p.requires_grad = head_trainable

def evaluate(model, loader):
    model.eval()
    correct = total = 0
    with torch.no_grad():
        for xb, yb in loader:
            logits = model(xb)
            correct += (logits.argmax(1) == yb).sum().item()
            total += yb.size(0)
    acc = correct / total
    assert 0.0 <= acc <= 1.0
    return acc

init_sig = None
ref_order = None

def run_variant(partial):
    # Minden változat azonos inicializálást és batch-sorrendet kap.
    global init_sig, ref_order
    torch.manual_seed(SEED)
    model = GlyphLabCNN().to(device).to(dtype)
    sig = float(model.backbone[0].weight.detach().double().sum())
    if init_sig is None:
        init_sig = sig
    assert sig == init_sig, "a két változat inicializálása eltér"
    order0 = train_order(0)
    if ref_order is None:
        ref_order = order0.clone()
    assert torch.equal(order0, ref_order), "a két változat batch-sorrendje eltér"
    if partial:
        # utolsó backbone blokk: index 3-tól (conv2, BN2, ReLU)
        set_frozen_layerwise(model, model.backbone[3:], True)
        opt = torch.optim.Adam([
            {"params": model.head.parameters(), "lr": 0.01},
            {"params": model.backbone[3:].parameters(), "lr": 0.001},
        ])
    else:
        set_frozen_layerwise(model, None, True)
        opt = torch.optim.Adam(model.head.parameters(), lr=0.01)
    loss_fn = nn.CrossEntropyLoss()
    train_losses = []
    for epoch in range(10):
        model.train()
        if partial:
            model.backbone[:3].eval()   # a befagyasztott conv1, BN1 eval marad
        else:
            model.backbone.eval()       # a head train, a backbone eval marad
        order = train_order(epoch)
        epoch_loss = 0.0
        for start in range(0, len(order), BATCH):
            bidx = order[start:start + BATCH]
            xb, yb = X[train_idx[bidx]], y[train_idx[bidx]]
            opt.zero_grad()
            loss = loss_fn(model(xb), yb)
            loss.backward()
            opt.step()
            epoch_loss += loss.item() * xb.size(0)
        train_losses.append(epoch_loss / len(train_idx))
    val_acc = evaluate(model, val_loader)
    return train_losses[-1], val_acc

head_loss, head_acc = run_variant(partial=False)
part_loss, part_acc = run_variant(partial=True)
print(f"head-only:  train_loss={head_loss:.3f}, val_acc={head_acc:.3f}")
print(f"partial:    train_loss={part_loss:.3f}, val_acc={part_acc:.3f}")
