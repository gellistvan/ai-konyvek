import torch

# head-only
w_h = torch.tensor([0.5], requires_grad=True)
w_b = torch.tensor([1.0], requires_grad=False)
loss = (w_h + 2*w_b - 1)**2
loss.backward()
print(w_h.grad, w_b.grad)          # tensor([3.]) None
opt = torch.optim.SGD([w_h], lr=0.1)
opt.step()
print(w_h, w_b)                    # tensor([0.2000], requires_grad=True) tensor([1.])

# partial unfreeze, külön paramétercsoport
w_h = torch.tensor([0.5], requires_grad=True)
w_b = torch.tensor([1.0], requires_grad=True)
loss = (w_h + 2*w_b - 1)**2
loss.backward()
opt = torch.optim.SGD([
    {"params": [w_h], "lr": 0.1},
    {"params": [w_b], "lr": 0.01},
])
opt.step()
print(w_h, w_b)                    # tensor([0.2000], requires_grad=True) tensor([0.9400], requires_grad=True)
