def forward_wrong(X, W, b):
    return X @ W + b
