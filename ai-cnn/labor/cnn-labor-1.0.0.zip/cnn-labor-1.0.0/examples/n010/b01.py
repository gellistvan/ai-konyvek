# futtatás: python n010_affine_lab.py
import numpy as np

X = np.array([[1.0, 3.0],
              [-2.0, 0.5]], dtype=np.float32)      # (2, 2)
W = np.array([[ 1.0, -2.0],
              [ 0.0,  1.0],
              [ 2.0,  0.0]], dtype=np.float32)     # (3, 2)
b = np.array([0.5, -1.0, 0.2], dtype=np.float32)   # (3,)

Z = X @ W.T + b

Z_expected = np.array([[-4.5, 2.0, 2.2],
                       [-2.5, -0.5, -3.8]], dtype=np.float32)

print("Z =")
print(Z)
assert Z.shape == (2, 3)
assert np.allclose(Z, Z_expected, atol=1e-6, rtol=1e-5)
print("OK: alak és numerikus egyezés a kézi számítással")
