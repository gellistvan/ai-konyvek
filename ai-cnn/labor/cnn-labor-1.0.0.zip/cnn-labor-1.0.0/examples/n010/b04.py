import numpy as np

def affine_forward(X, W, b):
    if X.ndim != 2:
        raise ValueError("X-nek (N, d) alakúnak kell lennie")
    if W.ndim != 2:
        raise ValueError("W-nek (m, d) alakúnak kell lennie")
    if b.ndim != 1:
        raise ValueError("b-nek (m,) alakúnak kell lennie")
    N, d = X.shape
    m, d_w = W.shape
    if d != d_w:
        raise ValueError(f"bemeneti dimenzió eltérés: X {d}, W {d_w}")
    if b.shape[0] != m:
        raise ValueError(f"bias méret {b.shape[0]}, de {m} kell")
    return X @ W.T + b

X = np.array([[1.0, 3.0], [-2.0, 0.5]], dtype=np.float32)
W = np.array([[1.0, -2.0], [0.0, 1.0], [2.0, 0.0]], dtype=np.float32)
b = np.array([0.5, -1.0, 0.2], dtype=np.float32)
Z = affine_forward(X, W, b)
Z_expected = np.array([[-4.5, 2.0, 2.2], [-2.5, -0.5, -3.8]], dtype=np.float32)
assert Z.shape == (2, 3)
assert np.allclose(Z, Z_expected, atol=1e-6, rtol=1e-5)
