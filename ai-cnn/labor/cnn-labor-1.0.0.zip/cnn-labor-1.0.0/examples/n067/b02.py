# fajl: lab_vgg_stack.py, futtatas: python lab_vgg_stack.py
import torch
import torch.nn as nn

torch.manual_seed(20261020)

X = torch.rand(1, 1, 9, 9, dtype=torch.float32) * 2 - 1  # [-1,1]

blockA = nn.Conv2d(1, 4, kernel_size=5, padding=2)
blockB = nn.Sequential(
    nn.Conv2d(1, 4, kernel_size=3, padding=1),
    nn.ReLU(),
    nn.Conv2d(4, 4, kernel_size=3, padding=1),
)

def n_params(m):
    return sum(p.numel() for p in m.parameters())

with torch.no_grad():
    yA = blockA(X)
    yB = blockB(X)

assert n_params(blockA) == 104
assert n_params(blockB) == 188
assert tuple(yA.shape) == (1, 4, 9, 9)
assert tuple(yB.shape) == (1, 4, 9, 9)

def rf_from_spec(spec):
    F = J = 1
    for k, s in spec:
        F = F + (k - 1) * J
        J = J * s
    return F

assert rf_from_spec([(5, 1)]) == 5
assert rf_from_spec([(3, 1), (3, 1)]) == 5
print("RF A:", rf_from_spec([(5, 1)]), "RF B:", rf_from_spec([(3, 1), (3, 1)]))

print("A params:", n_params(blockA))  # elvart: 104
print("B params:", n_params(blockB))  # elvart: 188
print("A shape:", tuple(yA.shape))    # elvart: (1, 4, 9, 9)
print("B shape:", tuple(yB.shape))    # elvart: (1, 4, 9, 9)
print("abs diff max:", (yA - yB).abs().max().item()) # veletlenszeru, nem 0
