import torch
import torch.nn as nn

torch.manual_seed(20261020)
device = torch.device('cpu')
dtype = torch.float32

X = torch.randn(2, 4, 10, 10, dtype=dtype, device=device)

stack = nn.Sequential(
    nn.Conv2d(4, 4, kernel_size=3, padding=0),
    nn.ReLU(),
    nn.Conv2d(4, 4, kernel_size=3, padding=0),
)
single = nn.Conv2d(4, 4, kernel_size=5, padding=0)

def n_params(m):
    return sum(p.numel() for p in m.parameters() if p.requires_grad)

print("stack params:", n_params(stack))   # várt: 296
print("single params:", n_params(single)) # várt: 404

with torch.no_grad():
    y_stack = stack(X)
    y_single = single(X)
print("stack output shape:", y_stack.shape)   # várt: torch.Size([2, 4, 6, 6])
print("single output shape:", y_single.shape) # várt: torch.Size([2, 4, 6, 6])
