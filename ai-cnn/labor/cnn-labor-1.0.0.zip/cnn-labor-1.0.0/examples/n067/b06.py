def forward(self, x):
    return self.conv2(torch.relu(self.conv1(x)))
