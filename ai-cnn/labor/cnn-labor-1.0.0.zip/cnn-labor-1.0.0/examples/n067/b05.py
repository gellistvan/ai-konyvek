def stack_rf_params(k_list, s_list, d_list, C, bias=True):
    if not (len(k_list) == len(s_list) == len(d_list)):
        raise ValueError("a k_list, s_list és d_list hossza egyezzen meg")
    J = 1
    F = 1
    total = 0
    for k, s, d in zip(k_list, s_list, d_list):
        F = F + (k - 1) * d * J
        J = J * s
        total += C * (C * k * k + (1 if bias else 0))
    return F, total

rf, params = stack_rf_params([3, 3], [1, 1], [1, 1], 4, True)
print(rf, params)   # 5 296
