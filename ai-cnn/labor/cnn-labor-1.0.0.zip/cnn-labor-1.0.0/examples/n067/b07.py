import torch
import torch.nn as nn

class Stack(nn.Module):
    def __init__(self, use_relu=True):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 1, 3, padding=1, bias=False)
        self.conv2 = nn.Conv2d(1, 1, 3, padding=1, bias=False)
        self.use_relu = use_relu

    def forward(self, x):
        h = self.conv1(x)
        if self.use_relu:
            h = torch.relu(h)
        return self.conv2(h)

def center_value(model, a):
    x = torch.zeros(1, 1, 3, 3)
    x[0, 0, 1, 1] = a
    return model(x)[0, 0, 1, 1].item()

for m in (Stack(True), Stack(False)):
    with torch.no_grad():
        m.conv1.weight.zero_()
        m.conv1.weight[0, 0, 1, 1] = 1.0
        m.conv2.weight.fill_(1.0)
    print(m.use_relu, center_value(m, 1.0), center_value(m, -1.0))
