def backward_bad(x, y, W):
    g_z = y  # hiba: phi'(z) kimaradt
    return W.T @ g_z, np.outer(g_z, x), g_z
