"""n016_gradcheck.py – teljes kis gráf gradiensellenőrzése.

A gráf: z = Wx + b, y = z**2, L = 0.5 * sum(y**2).
A kód f64-ben, középső differenciával ellenőrzi x, W és b gradiensét,
majd egy normalizált v irányban az iránymenti deriváltat is.
"""
import argparse
import numpy as np

def phi(z):
    return np.square(z)

def phi_prime(z):
    return 2.0 * z

def loss(x, W, b):
    y = phi(W @ x + b)
    return 0.5 * np.sum(np.square(y))

def backward(x, W, b):
    z = W @ x + b
    y = phi(z)
    g_z = y * phi_prime(z)
    g_x = W.T @ g_z
    g_W = np.outer(g_z, x)
    g_b = g_z
    return g_x, g_W, g_b

def close(a, b, atol=1e-7, rtol=1e-7):
    diff = np.abs(a - b)
    scale = np.maximum(np.abs(a), np.abs(b))
    return bool(np.all(diff <= atol + rtol * scale))

def finite_diff_all(x, W, b, eps=1e-6):
    num_x = np.zeros_like(x)
    for i in range(x.shape[0]):
        xp, xm = x.copy(), x.copy()
        xp[i] += eps
        xm[i] -= eps
        num_x[i] = (loss(xp, W, b) - loss(xm, W, b)) / (2 * eps)

    num_W = np.zeros_like(W)
    for i in range(W.shape[0]):
        for j in range(W.shape[1]):
            Wp, Wm = W.copy(), W.copy()
            Wp[i, j] += eps
            Wm[i, j] -= eps
            num_W[i, j] = (loss(x, Wp, b) - loss(x, Wm, b)) / (2 * eps)

    num_b = np.zeros_like(b)
    for i in range(b.shape[0]):
        bp, bm = b.copy(), b.copy()
        bp[i] += eps
        bm[i] -= eps
        num_b[i] = (loss(x, W, bp) - loss(x, W, bm)) / (2 * eps)

    return num_x, num_W, num_b

def check_point(name, x, W, b, eps=1e-6):
    g_x, g_W, g_b = backward(x, W, b)
    n_x, n_W, n_b = finite_diff_all(x, W, b, eps=eps)

    z = W @ x + b
    y = phi(z)
    print(f"{name}: z={np.array2string(z, precision=4)}, "
          f"y={np.array2string(y, precision=4)}, L={loss(x, W, b):.6f}")

    ok_x = close(g_x, n_x)
    ok_W = close(g_W, n_W)
    ok_b = close(g_b, n_b)

    v = np.arange(1.0, x.shape[0] + 1, dtype=np.float64)
    v = v / np.linalg.norm(v)
    dir_num = (loss(x + eps * v, W, b) - loss(x - eps * v, W, b)) / (2 * eps)
    dir_ana = float(v @ g_x)
    ok_dir = close(dir_ana, dir_num)

    print(f"{name}: x={ok_x}, W={ok_W}, b={ok_b}, iranymenti={ok_dir}")
    print(f"  max|x-hiba|={np.max(np.abs(g_x - n_x)):.2e}, "
          f"max|W-hiba|={np.max(np.abs(g_W - n_W)):.2e}, "
          f"max|b-hiba|={np.max(np.abs(g_b - n_b)):.2e}")
    assert ok_x and ok_W and ok_b and ok_dir, f"{name}: gradiensellenorzes nem teljesult"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=20261020)
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)

    # P0: a szövegben kézzel kiszámolt pont
    x0 = np.array([1.0, 2.0, -1.0], dtype=np.float64)
    W0 = np.array([[0.5, -1.0, 2.0],
                   [1.0, 0.5, -1.0]], dtype=np.float64)
    b0 = np.array([0.2, -0.3], dtype=np.float64)
    check_point("P0", x0, W0, b0)

    # P1: második, kis gradiensű kontrollpont
    x1 = np.array([0.5, -2.0, 1.5], dtype=np.float64)
    W1 = np.array([[2.0, 0.0, -1.0],
                   [0.0, 1.0, 1.0]], dtype=np.float64)
    b1 = np.array([0.1, 0.0], dtype=np.float64)
    check_point("P1", x1, W1, b1)

    # Seedelt új pont: a seed rögzíti a véletlen pontot
    xr = rng.standard_normal(3)
    Wr = rng.standard_normal((2, 3))
    br = rng.standard_normal(2)
    check_point("random_seed", xr, Wr, br)

if __name__ == "__main__":
    main()
