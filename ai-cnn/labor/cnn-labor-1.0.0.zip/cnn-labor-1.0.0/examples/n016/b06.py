def check_point(name, x, W, b, eps=1e-6, atol=1e-7, rtol=1e-7):
    g_x, g_W, g_b = backward(x, W, b)
    n_x, n_W, n_b = finite_diff_all(x, W, b, eps=eps)
    ok_x = safe_close(g_x, n_x, atol, rtol)
    ok_W = safe_close(g_W, n_W, atol, rtol)
    ok_b = safe_close(g_b, n_b, atol, rtol)
    v = np.arange(1.0, x.shape[0] + 1, dtype=np.float64)
    v = v / np.linalg.norm(v)
    dir_num = (loss(x + eps * v, W, b) - loss(x - eps * v, W, b)) / (2 * eps)
    dir_ana = float(v @ g_x)
    ok_dir = safe_close(dir_ana, dir_num, atol, rtol)
    assert ok_x and ok_W and ok_b and ok_dir, f"{name}: gradiensellenorzes nem teljesult"
