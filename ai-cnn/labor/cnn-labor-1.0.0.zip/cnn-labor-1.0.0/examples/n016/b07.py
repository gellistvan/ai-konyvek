a = np.array([1e-12])
b = np.array([0.0])
assert safe_close(a, b, atol=1e-7, rtol=1e-7)           # az abszolút ág dönt
assert not safe_close(np.array([1e-6]), np.array([0.0]),
                      atol=1e-7, rtol=1e-7)             # ekkora eltérés nem fér bele
