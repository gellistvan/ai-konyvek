def safe_close(a, b, atol=1e-7, rtol=1e-7):
    diff = np.abs(np.asarray(a, dtype=np.float64)
                  - np.asarray(b, dtype=np.float64))
    scale = np.maximum(np.abs(np.asarray(a, dtype=np.float64)),
                       np.abs(np.asarray(b, dtype=np.float64)))
    return bool(np.all(diff <= atol + rtol * scale))
