python erf_lab.py
