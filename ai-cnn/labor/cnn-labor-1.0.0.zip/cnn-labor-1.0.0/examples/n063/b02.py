import torch
import torch.nn as nn

torch.manual_seed(7)
device = torch.device("cpu")

def rf_from_spec(spec):
    """spec: list of (kernel, dilation, stride) 1D/négyzetes esetre."""
    F = 1
    J = 1
    for k, d, s in spec:
        F = F + (k - 1) * d * J
        J = J * s
    return F, J

def build_layer(k, d, s):
    return nn.Conv2d(1, 1, kernel_size=k, dilation=d,
                     stride=s, padding=1, bias=False)

specs = {
    "A": [(3, 1, 1)] * 4,                     # négy 3x3, stride 1
    "B": [(3, 1, 2)] * 3,                     # három 3x3, stride 2
    "C": [(3, 1, 1), (3, 2, 1), (3, 4, 1)],  # dilation 1,2,4
}

for name, spec in specs.items():
    F, J = rf_from_spec(spec)
    model = nn.Sequential(*[build_layer(*p) for p in spec]).to(device)

    x = torch.ones(1, 1, 32, 32, device=device, requires_grad=True)
    out = model(x)
    cy, cx = out.shape[2] // 2, out.shape[3] // 2
    loss = out[0, 0, cy, cx]
    loss.backward()

    g = x.grad[0, 0].detach().abs()
    # A konvolúció lineáris, a bemenet csupa egyes, ezért a gradiens értékei
    # pontos nullák vagy a kernelszorzatok; az 1e-8 csak a float32 összegzési
    # zaját küszöböli, a nemnulla értékek nagyságrendje 1.
    nz = (g > 1e-8).nonzero()
    ymin, xmin = nz.min(dim=0).values
    ymax, xmax = nz.max(dim=0).values
    mh, mw = int(ymax - ymin + 1), int(xmax - xmin + 1)

    # a gradiens befoglaló dobozának középső 3x3 blokkja
    cy_eff, cx_eff = (ymin + ymax) // 2, (xmin + xmax) // 2
    mid = g[cy_eff - 1:cy_eff + 2, cx_eff - 1:cx_eff + 2].sum().item()
    total = g.sum().item()

    expected = {"A": (9, 1), "B": (15, 8), "C": (15, 1)}
    expected_out = {"A": (32, 32), "B": (4, 4), "C": (24, 24)}
    assert (F, J) == expected[name], (name, F, J)
    assert tuple(out.shape[2:]) == expected_out[name], (name, out.shape)
    assert (mh, mw) == (F, F), (name, mh, mw, F)
    assert 0.0 < mid / total <= 1.0

    print(f"{name}: out.shape={tuple(out.shape[2:])}, elméleti RF=({F},{F}), "
          f"jump=({J},{J}), mért doboz=({mh},{mw}), közép3x3 arány={mid/total:.3f}")
