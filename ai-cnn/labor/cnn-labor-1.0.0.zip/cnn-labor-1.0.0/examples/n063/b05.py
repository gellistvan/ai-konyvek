def rf_fixed(spec):
    F = 1
    J = 1
    for k, d, s in spec:
        F = F + (k - 1) * d * J
        J = J * s
    return F, J
