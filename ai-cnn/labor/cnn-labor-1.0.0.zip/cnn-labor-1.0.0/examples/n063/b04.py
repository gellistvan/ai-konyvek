def rf_from_spec(spec):
    """spec: list of (kernel, dilation, stride)."""
    F = 1
    J = 1
    for k, d, s in spec:
        F = F + (k - 1) * d * J
        J = J * s
    return F, J

# teszt 1: négy 3x3-as, stride 1: RF=9
assert rf_from_spec([(3, 1, 1)] * 4) == (9, 1)

# teszt 2: egy stride-2 réteg, majd egy stride-1
assert rf_from_spec([(3, 1, 2)]) == (3, 2)
assert rf_from_spec([(3, 1, 2), (3, 1, 1)]) == (7, 2)

# teszt 3 (2D): dimenziónként külön rekurzió
spec2d = [((3, 1, 1), (5, 1, 2)), ((3, 1, 1), (5, 1, 2))]
Fh, Jh = rf_from_spec([h for h, w in spec2d])
Fw, Jw = rf_from_spec([w for h, w in spec2d])
assert (Fh, Jh, Fw, Jw) == (5, 1, 13, 4)
print((Fh, Jh), (Fw, Jw))
# mért kimenet: (5, 1) (13, 4)
