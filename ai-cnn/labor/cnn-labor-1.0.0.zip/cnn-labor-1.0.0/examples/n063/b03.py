def rf_wrong(spec):
    F = 1
    J = 1
    for k, d, s in spec:
        J = J * s
        F = F + (k - 1) * d * J   # a frissített J-t használja
    return F, J
