import math

def vector_norm(v):
    if len(v) == 0:
        raise ValueError("üres tömbnek nincs normája")
    return math.sqrt(sum(x * x for x in v))

def mean(v):
    if len(v) == 0:
        raise ValueError("üres tömbnek nincs átlaga")
    return sum(v) / len(v)

# Tesztek
assert abs(vector_norm([3.0, 4.0]) - 5.0) < 1e-12
assert abs(mean([1.0, 3.0, 5.0]) - 3.0) < 1e-12
for f in (vector_norm, mean):
    try:
        f([])
    except ValueError:
        pass
    else:
        raise AssertionError(f"{f.__name__} üres listára nem dobott ValueError-t")
