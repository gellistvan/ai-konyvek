python n004_diagnosis.py --answers 5 5 3 4 1152 --basis n009 \
  --seed-note "A seed csak a generátor kezdőállapota; ugyanaz a seed \
más NumPy-verzióban vagy más algoritmussal eltérő sorozatot adhat."
