#!/usr/bin/env python3
"""n004 diagnosztikai labor: első változat mentése és napló."""
import argparse
import hashlib
import json
import os
import sys
from datetime import datetime, timezone

EXPECTED = {
    "norm": {"value": 5.0, "tol": 1e-6},
    "function": {"value": 5.0, "tol": 1e-6},
    "mean": {"value": 3.0, "tol": 1e-6},
    "derivative": {"value": 4.0, "tol": 1e-5},
    "tensor_elements": {"value": 1152, "exact": True},
}

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--answers", nargs=5, type=float, required=True,
                    help="sorrend: vektornorma, f(3), átlag, "
                         "szimmetrikus differenciahányados, tensor-elemszám")
    ap.add_argument("--basis", required=True,
                    help="választott célzott alapozó egység, pl. n009")
    ap.add_argument("--seed-note", required=True,
                    help="magyarázat: miért nem elég a seed önmagában")
    ap.add_argument("--output-dir", default="lab_n004")
    args = ap.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    log_path = os.path.join(args.output_dir, "log.json")
    first_version_kept = not os.path.exists(log_path)
    if not first_version_kept:
        print(f"Hiba: {log_path} már létezik. "
              "A napló append-only; ne írd felül az első változatot.")
        return 2

    tensor_float = args.answers[4]
    if abs(tensor_float - round(tensor_float)) > 1e-9:
        print("Hiba: a tensor-elemszám egész szám legyen.")
        return 2
    answers = {
        "norm": args.answers[0],
        "function": args.answers[1],
        "mean": args.answers[2],
        "derivative": args.answers[3],
        "tensor_elements": int(round(tensor_float)),
    }
    assert set(answers) == set(EXPECTED)

    results = []
    for key, spec in EXPECTED.items():
        got = answers[key]
        if spec.get("exact"):
            err = abs(got - spec["value"])
            ok = got == spec["value"]
        else:
            err = abs(got - spec["value"])
            ok = err <= spec["tol"]
        results.append({
            "task": key,
            "expected": spec["value"],
            "got": got,
            "error": err,
            "ok": ok,
            "tolerance": spec.get("tol", 0),
        })

    now_dt = datetime.now(timezone.utc)
    now = now_dt.isoformat()
    stamp = now_dt.strftime("%Y%m%dT%H%M%S")
    with open(__file__, "rb") as fh:
        code_sha8 = hashlib.sha256(fh.read()).hexdigest()[:8]
    config = {
        "answers": answers,
        "chosen_basis_unit": args.basis,
        "seed_note": args.seed_note,
        "code_sha8": code_sha8,
    }
    material = now + json.dumps(config, sort_keys=True)
    run_id = "run-" + stamp + "-" + hashlib.sha256(material.encode()).hexdigest()[:8]

    record = {
        "unit": "n004",
        "run_id": run_id,
        "code_sha8": code_sha8,
        "timestamp": now,
        "seed": None,
        "data_version": "nincs külső adat (a labor nem olvas fájlt)",
        "device": "cpu",
        "dtype": "float64 numerikus ellenőrzés; tensor-elemszám int",
        "glyphlab_seed_note":
            "GlyphLab-generáló seed 20261020; ez a labor nem generál véletlent",
        "diagnosis_not_grading": True,
        "answers": answers,
        "results": results,
        "all_ok": all(r["ok"] for r in results),
        "chosen_basis_unit": args.basis,
        "seed_note": args.seed_note,
        "first_version_kept": first_version_kept,
    }
    with open(log_path, "w", encoding="utf-8") as fh:
        json.dump(record, fh, ensure_ascii=False, indent=2)

    print("run_id:", run_id)
    print("log:", log_path)
    print("results:")
    for r in results:
        print(f"  {r['task']:>15s}: ok={r['ok']}, error={r['error']:.3g}")
    print("all_ok:", record["all_ok"])
    print("chosen_basis_unit:", args.basis)
    return 0 if record["all_ok"] else 1

if __name__ == "__main__":
    sys.exit(main())
