def mean_fixed(x):
    if len(x) == 0:
        raise ValueError("üres tömbnek nincs átlaga")
    return sum(x) / len(x)

assert mean_fixed([2.0]) == 2.0
assert abs(mean_fixed([1.0, 3.0]) - 2.0) < 1e-12
try:
    mean_fixed([])
except ValueError:
    pass
else:
    raise AssertionError("üres lista nem dobott ValueError-t")
