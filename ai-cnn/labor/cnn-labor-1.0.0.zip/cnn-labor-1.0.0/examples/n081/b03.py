# lab/n081_init_scale.py
import argparse
import math
import torch

def make_layers(width, layers, scheme, dt):
    result = []
    for _ in range(layers):
        lin = torch.nn.Linear(width, width, bias=True, dtype=dt)
        if scheme == "he":
            std = math.sqrt(2.0 / lin.in_features)
            torch.nn.init.normal_(lin.weight, mean=0.0, std=std)
        elif scheme == "xavier":
            a = math.sqrt(6.0 / (lin.in_features + lin.out_features))
            torch.nn.init.uniform_(lin.weight, -a, a)
        else:
            raise ValueError(f"ismeretlen séma: {scheme}")
        torch.nn.init.zeros_(lin.bias)
        result.append(lin)
    return result

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--seed", type=int, default=20261020)
    p.add_argument("--dtype", choices=["float32", "float64"], default="float64")
    p.add_argument("--batch", type=int, default=8192)
    p.add_argument("--width", type=int, default=64)
    p.add_argument("--layers", type=int, default=6)
    p.add_argument("--scheme", choices=["he", "xavier"], default="he")
    p.add_argument("--shifted", action="store_true",
                   help="zérus átlag feltétel megsértése")
    args = p.parse_args()

    dt = torch.float64 if args.dtype == "float64" else torch.float32
    torch.manual_seed(args.seed)
    x = torch.randn(args.batch, args.width, dtype=dt)
    if args.shifted:
        x = x + 1.5
    x.requires_grad_(True)   # az eltolás után lesz levél és kap gradienst

    layers = make_layers(args.width, args.layers, args.scheme, dt)
    h = x
    print("label layer_idx fan_in fan_out h_std h_rms")
    for i, lin in enumerate(layers):
        h = torch.relu(lin(h))
        if i < 3 or i == len(layers) - 1:
            h_rms = float(h.detach().pow(2).mean().sqrt())
            print(args.scheme, i, lin.in_features, lin.out_features,
                  f"{float(h.detach().std()):.4f}", f"{h_rms:.4f}")
    h.sum().backward()
    print("input_grad_std", f"{float(x.grad.std()):.4f}")
    print("input_grad_rms", f"{float(x.grad.pow(2).mean().sqrt()):.4f}")

if __name__ == "__main__":
    main()
