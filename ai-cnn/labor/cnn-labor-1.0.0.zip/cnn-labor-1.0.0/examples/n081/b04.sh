python lab/n081_init_scale.py --seed 20261020 --dtype float64 --scheme he
python lab/n081_init_scale.py --seed 20261020 --dtype float64 --scheme xavier
python lab/n081_init_scale.py --seed 20261020 --dtype float64 --scheme he --shifted
