def measure_forward_scale(layers, x):
    scales = []
    h = x
    for lin in layers:
        fan_in = lin.weight.shape[1]
        fan_out = lin.weight.shape[0]
        h = torch.relu(lin(h))
        out_rms = float(h.detach().pow(2).mean().sqrt())
        scales.append((fan_in, fan_out, out_rms))
    return scales

import math, torch
torch.manual_seed(20261020)
dt = torch.float64
x = torch.randn(4096, 64, dtype=dt)
l1 = torch.nn.Linear(64, 64, dtype=dt)
l2 = torch.nn.Linear(64, 64, dtype=dt)
for lin in (l1, l2):
    torch.nn.init.normal_(lin.weight, 0.0, math.sqrt(2.0 / 64))
    torch.nn.init.zeros_(lin.bias)
print(measure_forward_scale([l1, l2], x))
