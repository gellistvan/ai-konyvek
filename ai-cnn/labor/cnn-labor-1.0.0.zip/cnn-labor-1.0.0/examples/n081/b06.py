a = math.sqrt(6.0 / (fan_in + fan_out))
torch.nn.init.uniform_(m.weight, 0, a)
