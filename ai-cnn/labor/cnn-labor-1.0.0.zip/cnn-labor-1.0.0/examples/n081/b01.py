# lab/n081_mini_scale.py
import math
import torch

torch.manual_seed(20261020)
dt = torch.float64            # a variancia pontos méréséhez
batch, d, m = 8192, 8, 4
x = torch.randn(batch, d, dtype=dt) * math.sqrt(3.0)  # sigma_x^2 = 3
lin = torch.nn.Linear(d, m, dtype=dt)
std_w = math.sqrt(2.0 / d)    # He normal: sigma_w^2 = 2/fan_in
torch.nn.init.normal_(lin.weight, mean=0.0, std=std_w)
torch.nn.init.zeros_(lin.bias)

with torch.no_grad():
    z = lin(x)
    h = torch.relu(z)
print("z var  :", float(z.var()))              # elmélet (súlyok felett várható): 6
print("E[h^2] :", float((h ** 2).mean()))      # elmélet: 6/2 = 3
print("h var  :", float(h.var()))              # elmélet: 6*(1/2 - 1/(2*pi)) ~ 2.045
