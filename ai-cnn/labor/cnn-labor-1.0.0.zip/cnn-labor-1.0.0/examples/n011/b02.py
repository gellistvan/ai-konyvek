# lab/n011_lstsq/n011_lstsq.py
# Input: nincs külső adat; CPU, float64, seed nem szükséges.
import numpy as np

EPS = 1e-5
A = np.array(
    [[1.0, 1.0],
     [1.0, 1.0 + EPS],
     [1.0, 1.0 + 2.0 * EPS]],
    dtype=np.float64,
)

x_ref = np.array([1.0, 2.0], dtype=np.float64)
delta = np.array([1.0, -2.0, 1.0], dtype=np.float64)
assert np.allclose(A.T @ delta, np.zeros(2), atol=1e-14)
b = A @ x_ref + delta

# 1) Expliciten invertált normálegyenlet.
x_explicit = np.linalg.inv(A.T @ A) @ A.T @ b
err_explicit = np.linalg.norm(x_explicit - x_ref)

# 2) Stabil, SVD-alapú megoldó; rcond=None: automatikus SVD-küszöb.
sv = np.linalg.svd(A, compute_uv=False)
rcond_eff = np.finfo(A.dtype).eps * max(A.shape)
print(f"SVD-küszöb  = {rcond_eff * sv[0]} (rcond_eff = {rcond_eff})")
x_lstsq, residuals, rank_lstsq, _ = np.linalg.lstsq(A, b, rcond=None)
err_lstsq = np.linalg.norm(x_lstsq - x_ref)

print("x_ref      =", x_ref)
print("explicit   =", x_explicit, "hiba =", err_explicit)
print("lstsq      =", x_lstsq, "hiba =", err_lstsq)
print("rank       =", rank_lstsq, "reziduum-norma^2 =", residuals[0])
print("cond(A.T A) =", np.linalg.cond(A.T @ A))
print("cond(A)     =", np.linalg.cond(A))

# Elméleti kontrollok, amelyek a stabil megoldóra vonatkoznak.
assert rank_lstsq == 2
assert np.allclose(x_lstsq, x_ref, rtol=0.0, atol=2e-5)
assert np.allclose(residuals[0], 6.0, rtol=1e-10, atol=1e-10)
print("Ellenőrzés: rank, x_lstsq és reziduum rendben.")
