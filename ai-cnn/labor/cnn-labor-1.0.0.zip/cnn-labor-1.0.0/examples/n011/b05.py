def bad_solve(A, b):
    return np.linalg.inv(A.T @ A) @ A.T @ b
