python lab/n011_lstsq/n011_lstsq.py
