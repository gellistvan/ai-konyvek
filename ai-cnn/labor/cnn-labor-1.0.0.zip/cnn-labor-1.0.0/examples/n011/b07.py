def good_solve(A, b):
    x, _, rank, _ = np.linalg.lstsq(A, b, rcond=None)
    if rank < A.shape[1]:
        raise np.linalg.LinAlgError("ranghiányos adatmátrix")
    return x
