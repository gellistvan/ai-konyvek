import numpy as np
import pytest
from good_solve import good_solve

def test_kozel_kollinearis_referencia():
    EPS = 1e-5
    A = np.array([[1.0, 1.0], [1.0, 1.0 + EPS], [1.0, 1.0 + 2 * EPS]])
    x_ref = np.array([1.0, 2.0])
    b = A @ x_ref + np.array([1.0, -2.0, 1.0])
    x = good_solve(A, b)
    assert np.allclose(x, x_ref, rtol=0.0, atol=2e-5)

def test_ranghianyos_kivetel():
    A = np.array([[1.0, 2.0], [2.0, 4.0]])
    b = np.array([1.0, 2.0])
    with pytest.raises(np.linalg.LinAlgError):
        good_solve(A, b)
