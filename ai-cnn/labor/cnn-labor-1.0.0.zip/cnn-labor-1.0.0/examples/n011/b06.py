# lab/n011_lstsq/least_squares.py
import numpy as np

def least_squares(A: np.ndarray, b: np.ndarray) -> tuple[np.ndarray, np.ndarray, int]:
    if A.ndim != 2 or b.ndim != 1:
        raise ValueError("A legyen 2D, b legyen 1D")
    if A.shape[0] != b.shape[0]:
        raise ValueError("A sorainak száma egyezzen b hosszával")
    x, _, rank, _ = np.linalg.lstsq(A, b, rcond=None)
    residual = b - A @ x
    return x, residual, rank

if __name__ == "__main__":
    EPS = 1e-5
    A = np.array([[1.0, 1.0], [1.0, 1.0 + EPS], [1.0, 1.0 + 2.0 * EPS]])
    x_ref = np.array([1.0, 2.0])
    b = A @ x_ref + np.array([1.0, -2.0, 1.0])
    x, r, rank = least_squares(A, b)
    assert rank == 2
    assert np.allclose(x, x_ref, rtol=0.0, atol=2e-5)
    assert np.allclose(r, [1.0, -2.0, 1.0], atol=1e-8)
    print("F3 kontroll: mindhárom feltétel teljesült.")
