import torch
import torch.nn as nn

def batchnorm_forward_manual(X, gamma, beta, eps):
    mu = X.mean(dim=(0, 2, 3), keepdim=True)
    var = X.var(dim=(0, 2, 3), unbiased=False, keepdim=True)
    xhat = (X - mu) / torch.sqrt(var + eps)
    Y = gamma.view(1, -1, 1, 1) * xhat + beta.view(1, -1, 1, 1)
    return Y, (mu, var)

X = torch.tensor(
    [[[[1.0, 2.0], [3.0, 4.0]]],
     [[[2.0, 4.0], [6.0, 8.0]]]], dtype=torch.float32
)

bn = nn.BatchNorm2d(1, eps=1e-5, momentum=0.1)
bn.weight.data.copy_(torch.tensor([2.0]))
bn.bias.data.copy_(torch.tensor([-1.0]))
bn.train()

Y_ref = bn(X)
Y_man, (mu, var) = batchnorm_forward_manual(
    X, bn.weight, bn.bias, 1e-5
)
print("mu =", mu.view(-1).tolist())       # [3.75]
print("var =", var.view(-1).tolist())     # [4.6875]
diff = (Y_ref - Y_man).abs().max().item()
print("max abs diff =", diff)
assert torch.allclose(Y_ref, Y_man, atol=1e-5, rtol=0)
