best.eval()
with torch.inference_mode():
    preds = [best(x.unsqueeze(0)).argmax().item() for x in test_images]
