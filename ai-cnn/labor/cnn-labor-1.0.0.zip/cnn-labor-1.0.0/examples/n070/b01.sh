python bn_manual.py
