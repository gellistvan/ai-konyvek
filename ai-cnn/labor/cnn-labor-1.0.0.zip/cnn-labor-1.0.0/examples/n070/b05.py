best = SmallCNN()
best.load_state_dict(torch.load("best.pt", weights_only=True))
best.train()  # HIBA: train módba kapcsol; nem őrzi meg a kiértékelési állapotot
preds = [best(x.unsqueeze(0)).argmax().item() for x in test_images]
