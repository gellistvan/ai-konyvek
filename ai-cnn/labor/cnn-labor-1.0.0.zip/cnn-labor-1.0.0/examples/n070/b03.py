bn.eval()
Y_eval = bn(X)

manual_eval = (X - rm_manual.view(1, -1, 1, 1)) / torch.sqrt(rv_manual.view(1, -1, 1, 1) + 1e-5)
manual_eval = bn.weight.view(1, -1, 1, 1) * manual_eval + bn.bias.view(1, -1, 1, 1)
eval_diff = (Y_eval - manual_eval).abs().max().item()
print("max_abs_diff eval:", eval_diff)
assert torch.allclose(Y_eval, manual_eval, atol=1e-5, rtol=0)

# Induló kérdés: ugyanaz az egy kép train módban a saját statisztikájával
# normalizálódik, és a forward mellékhatásként felülírja a running puffert.
bn.train()
rm_before = bn.running_mean.clone()
rv_before = bn.running_var.clone()
Y_single = bn(X[:1])
single_mu = X[:1].mean(dim=(0, 2, 3), keepdim=True)
single_var = X[:1].var(dim=(0, 2, 3), unbiased=False, keepdim=True)
manual_single = (X[:1] - single_mu) / torch.sqrt(single_var + 1e-5)
manual_single = bn.weight.view(1, -1, 1, 1) * manual_single + bn.bias.view(1, -1, 1, 1)
single_diff = (Y_single - manual_single).abs().max().item()
single_vs_eval = (Y_single - Y_eval[:1]).abs().max().item()
buffer_changed = (not torch.allclose(bn.running_mean, rm_before)) or (not torch.allclose(bn.running_var, rv_before))
print("egykepes train max_abs_diff:", single_diff)
print("egykepes train vs eval max_abs_diff:", single_vs_eval)
print("running buffer valtozott:", buffer_changed)
assert torch.allclose(Y_single, manual_single, atol=1e-5, rtol=0)
assert single_vs_eval > 1e-3 and buffer_changed
