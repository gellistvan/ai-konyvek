import torch
import torch.nn as nn

torch.manual_seed(20261020)  # a BN inicializálása seedfüggetlen; a seed a script ismételhetőségét rögzíti
dtype = torch.float32
device = "cpu"

X = torch.tensor(
    [[[[1.0, 2.0], [3.0, 4.0]]],
     [[[2.0, 4.0], [6.0, 8.0]]]],
    dtype=dtype, device=device
)  # (2,1,2,2)

bn = nn.BatchNorm2d(
    num_features=1, eps=1e-5, momentum=0.1,
    affine=True, track_running_stats=True
).to(device)

# Kézi statisztika a (N,H,W) dimenziókon, ugyanazzal a torzított varianciával:
mu = X.mean(dim=(0, 2, 3), keepdim=True)         # (1,1,1,1)
var = X.var(dim=(0, 2, 3), unbiased=False, keepdim=True)

bn.train()
Y = bn(X)

manual = (X - mu) / torch.sqrt(var + 1e-5)       # gamma=1, beta=0
train_diff = (Y - manual).abs().max().item()
print("max_abs_diff train:", train_diff)
assert train_diff < 1e-5

# Kézi pufferfrissítés: a futó variancia a torzítatlan becslést kapja (M=8).
M = X.numel() // X.shape[1]
var_unbiased = var * M / (M - 1)
rm_manual = 0.9 * 0.0 + 0.1 * mu.flatten()
rv_manual = 0.9 * 1.0 + 0.1 * var_unbiased.flatten()
print("running_mean:", bn.running_mean.item(), "kézi:", rm_manual.item())
print("running_var:", bn.running_var.item(), "kézi:", rv_manual.item())
assert torch.allclose(bn.running_mean, rm_manual) and torch.allclose(bn.running_var, rv_manual)
# Kézi levezetés: running_mean = 0.375, running_var = 37.5/70 + 0.9 = 1.435714...
