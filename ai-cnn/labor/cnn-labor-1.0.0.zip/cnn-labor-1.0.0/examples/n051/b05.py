def bad_edge_response(x):
    k = np.array([[1,1],[-1,-1]], dtype=np.float32)
    y = np.zeros((3,3), dtype=np.float32)
    for i in range(3):
        for j in range(3):
            y[i,j] = np.sum(x[i:i+2, i:i+2] * k,
                            dtype=np.float32)
    return y
