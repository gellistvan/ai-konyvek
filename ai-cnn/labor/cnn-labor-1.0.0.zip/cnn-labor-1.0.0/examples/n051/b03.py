"""Két rögzített szűrő deskriptív válasza GlyphLab mintákon.

A script nem végez predikciót; a válaszabszolútösszeg csak
ugyanazon bemenet két leképezésének összevetésére szolgál.
Nincs véletlen lépés: a kiválasztás a metadata train splitjéből
determinisztikus; a dtype float32, az eszköz CPU.
"""
import argparse
import csv
import numpy as np

DTYPE = np.float32

def valid_cross_corr2d(x, k):
    H, W = x.shape
    kh, kw = k.shape
    y = np.zeros((H - kh + 1, W - kw + 1), dtype=DTYPE)
    for i in range(y.shape[0]):
        for j in range(y.shape[1]):
            y[i, j] = np.sum(x[i:i+kh, j:j+kw] * k,
                             dtype=DTYPE)
    return y

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--images", default="data/images.npy")
    p.add_argument("--labels", default="data/labels.npy")
    p.add_argument("--metadata", default="data/metadata.csv")
    args = p.parse_args()

    images = np.load(args.images).astype(DTYPE)  # (360,1,24,24)
    labels = np.load(args.labels)                # (360,) int64
    with open(args.metadata, newline="", encoding="utf-8") as f:
        meta = list(csv.DictReader(f))
    assert list(meta[0]) == ["index", "scene_id", "view_id", "label", "split",
                             "xmin", "ymin", "xmax", "ymax"], list(meta[0])
    assert len(meta) == len(images) == len(labels) == 360, (len(meta), images.shape)
    assert [int(r["index"]) for r in meta] == list(range(len(meta)))

    k_smooth = (1.0/9.0) * np.ones((3,3), dtype=DTYPE)
    k_edge = np.array([[1,1,1],[0,0,0],[-1,-1,-1]],
                      dtype=DTYPE)

    # osztályonként a train split első három képét választjuk;
    # a feladat szempontjából elegendő, és nem képez predikciót
    train_idx = [int(r["index"]) for r in meta if r["split"] == "train"]
    selected = []
    for c in range(3):
        idx = [i for i in train_idx if labels[i] == c][:3]
        selected.extend(idx)
    assert len(selected) == 9

    print("idx smooth_abs edge_abs")
    for idx in selected:
        x = images[idx, 0]
        ys = valid_cross_corr2d(x, k_smooth)
        ye = valid_cross_corr2d(x, k_edge)
        s_abs = float(np.sum(np.abs(ys)))
        e_abs = float(np.sum(np.abs(ye)))
        assert np.isfinite(s_abs) and np.isfinite(e_abs)
        assert s_abs >= 0.0 and e_abs >= 0.0
        print(f"{idx:03d} {s_abs:.4f} {e_abs:.4f}")

if __name__ == "__main__":
    main()
