python n051_filter_response.py \
  --images data/images.npy \
  --labels data/labels.npy \
  --metadata data/metadata.csv
