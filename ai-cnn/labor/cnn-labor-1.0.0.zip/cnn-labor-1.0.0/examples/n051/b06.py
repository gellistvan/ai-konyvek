def valid_cross_corr2d(x, k):
    x = np.asarray(x, dtype=np.float32)
    k = np.asarray(k, dtype=np.float32)
    H, W = x.shape
    kh, kw = k.shape
    if H < kh or W < kw:
        raise ValueError(
            f"input {H}x{W} smaller than kernel {kh}x{kw}; "
            "valid output would be empty")
    y = np.zeros((H - kh + 1, W - kw + 1), dtype=np.float32)
    for i in range(y.shape[0]):
        for j in range(y.shape[1]):
            y[i, j] = np.sum(x[i:i+kh, j:j+kw] * k,
                             dtype=np.float32)
    return y
