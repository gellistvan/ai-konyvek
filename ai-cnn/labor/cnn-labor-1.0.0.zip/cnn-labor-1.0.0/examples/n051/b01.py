import numpy as np

def valid_cross_corr2d(x, k):
    # x: (H, W), k: (kh, kw), float32; valid cross-correlation
    H, W = x.shape
    kh, kw = k.shape
    y = np.zeros((H - kh + 1, W - kw + 1), dtype=np.float32)
    for i in range(y.shape[0]):
        for j in range(y.shape[1]):
            y[i, j] = np.sum(x[i:i+kh, j:j+kw] * k,
                             dtype=np.float32)
    return y

x_step = np.array([[0,0,0,0],
                   [0,0,0,0],
                   [1,1,1,1],
                   [1,1,1,1]], dtype=np.float32)

k_edge = np.array([[1,1],[-1,-1]], dtype=np.float32)
k_smooth = (1.0/4.0) * np.ones((2,2), dtype=np.float32)

y_edge = valid_cross_corr2d(x_step, k_edge)
y_smooth = valid_cross_corr2d(x_step, k_smooth)

assert y_edge.shape == (3,3)
assert y_smooth.shape == (3,3)
assert np.allclose(y_edge, [[0,0,0],[-2,-2,-2],[0,0,0]],
                   atol=1e-6)
assert np.allclose(y_smooth, [[0,0,0],[0.5,0.5,0.5],[1,1,1]],
                   atol=1e-6)
print("shape check OK")
