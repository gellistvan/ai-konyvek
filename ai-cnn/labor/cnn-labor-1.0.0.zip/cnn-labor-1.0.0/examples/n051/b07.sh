python - <<'PY'
import numpy as np

def valid_cross_corr2d(x, k):
    x = np.asarray(x, dtype=np.float32)
    k = np.asarray(k, dtype=np.float32)
    H, W = x.shape
    kh, kw = k.shape
    if H < kh or W < kw:
        raise ValueError(
            f"input {H}x{W} smaller than kernel {kh}x{kw}; "
            "valid output would be empty")
    y = np.zeros((H - kh + 1, W - kw + 1), dtype=np.float32)
    for i in range(y.shape[0]):
        for j in range(y.shape[1]):
            y[i, j] = np.sum(x[i:i+kh, j:j+kw] * k,
                             dtype=np.float32)
    return y

x = np.array([[0,0,0,0],[0,0,0,0],[1,1,1,1],[1,1,1,1]], dtype=np.float32)
k = np.array([[1,1],[-1,-1]], dtype=np.float32)
y = valid_cross_corr2d(x, k)
expected = np.array([[0,0,0],[-2,-2,-2],[0,0,0]], dtype=np.float32)
assert np.allclose(y, expected, atol=1e-6)
try:
    valid_cross_corr2d(np.zeros((2, 2), dtype=np.float32), k)
except ValueError as e:
    print("ValueError:", e)
else:
    raise AssertionError("a kicsi bemenet nem adott ValueError-t")
print(y)
PY
