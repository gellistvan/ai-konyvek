# lab/n052_lab.py
import numpy as np
from n052_boundary_check import corr_1d

DTYPE = np.float64

t = np.arange(32, dtype=DTYPE)
x_per = np.sin(2.0 * np.pi * t / 16.0)
x_edge = np.ones(32, dtype=DTYPE)
x_edge[16:] = 0.0

w_mean = np.ones(3, dtype=DTYPE) / 3.0
w_diff = np.array([-1.0, 0.0, 1.0], dtype=DTYPE)

for name, x in [("periodikus", x_per), ("el", x_edge)]:
    for b in ["zeros", "circular"]:
        y_mean = corr_1d(x, w_mean, b)
        y_diff = corr_1d(x, w_diff, b)
        assert y_mean.shape == (32,) and y_diff.shape == (32,)
        assert np.all(np.isfinite(y_mean)) and np.all(np.isfinite(y_diff))
        print(f"{name:10s} {b:9s} mean szél: {y_mean[0]:+.4f} {y_mean[-1]:+.4f} "
              f"diff szél: {y_diff[0]:+.4f} {y_diff[-1]:+.4f}")

assert np.isclose(corr_1d(x_per, w_mean, "circular")[0], 0.0, atol=1e-12)
assert np.isclose(corr_1d(x_edge, w_diff, "zeros")[-1], 0.0, atol=1e-12)
assert np.isclose(corr_1d(x_edge, w_diff, "circular")[-1], 1.0, atol=1e-12)
