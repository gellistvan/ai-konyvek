cd lab && python n052_lab.py
