x = np.array([1.0, 2.0, 0.0, 1.0])
w = np.ones(3, dtype=np.float64)
fft_size = len(x) + len(w) - 1   # 6
u = np.pad(x, (0, fft_size-len(x)))
v = np.pad(w[::-1], (0, fft_size-len(w)))
full = np.fft.ifft(np.fft.fft(u) * np.fft.fft(v)).real
same = full[1:1+len(x)]
np.testing.assert_allclose(same, corr_1d(x, w, "zeros"), atol=1e-12)
print(same)  # [3. 3. 3. 1.]
