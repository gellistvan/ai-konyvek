# lab/n052_boundary_check.py
import numpy as np

DTYPE = np.float64

def pad_1d(x, p, mode):
    """Szimmetrikus padding 1D jelekre."""
    x = np.asarray(x, dtype=DTYPE)
    if mode == "zeros":
        return np.pad(x, (p, p), mode="constant", constant_values=0.0)
    if mode == "circular":
        return np.pad(x, (p, p), mode="wrap")
    raise ValueError(f"ismeretlen mode: {mode}")

def corr_1d(x, w, boundary):
    """Cross-correlation, K páratlan, same kimenet zero/circular esetén."""
    H = x.shape[0]
    K = w.shape[0]
    assert K % 2 == 1, "csak páratlan kernel támogatott"
    p = K // 2
    if boundary == "valid":
        out = np.empty(H - K + 1, dtype=DTYPE)
        for t in range(out.shape[0]):
            out[t] = np.sum(x[t:t+K] * w)
        return out
    xp = pad_1d(x, p, boundary)
    out = np.empty(H, dtype=DTYPE)
    for t in range(H):
        out[t] = np.sum(xp[t:t+K] * w)
    return out

if __name__ == "__main__":
    x_demo = np.array([1.0, 2.0, 3.0])
    w_mean = np.array([1.0, 1.0, 1.0])

    print("zero   :", corr_1d(x_demo, w_mean, "zeros"))
    print("circular:", corr_1d(x_demo, w_mean, "circular"))
    np.testing.assert_allclose(corr_1d(x_demo, w_mean, "zeros"),
                               [3.0, 6.0, 5.0], atol=1e-12)
    np.testing.assert_allclose(corr_1d(x_demo, w_mean, "circular"),
                               [6.0, 6.0, 6.0], atol=1e-12)
