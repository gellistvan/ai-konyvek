def corr_2d(X, W, boundary):
    X = np.asarray(X, dtype=np.float64)
    W = np.asarray(W, dtype=np.float64)
    H, Wd = X.shape
    Kh, Kw = W.shape
    assert Kh % 2 == 1 and Kw % 2 == 1
    ph, pw = Kh // 2, Kw // 2
    if boundary == "zeros":
        Xp = np.pad(X, ((ph, ph), (pw, pw)), mode="constant", constant_values=0.0)
    elif boundary == "circular":
        Xp = np.pad(X, ((ph, ph), (pw, pw)), mode="wrap")
    else:
        raise ValueError(boundary)
    Y = np.empty_like(X)
    for i in range(H):
        for j in range(Wd):
            Y[i, j] = np.sum(Xp[i:i+Kh, j:j+Kw] * W)
    return Y

X = np.arange(1, 10, dtype=np.float64).reshape(3, 3)
W = np.array([[0,1,0],[1,0,1],[0,1,0]], dtype=np.float64)
print(corr_2d(X, W, "zeros"))
# [[ 6.  9.  8.]
#  [13. 20. 17.]
#  [12. 21. 14.]]
print(corr_2d(X, W, "circular"))
# [[16. 17. 18.]
#  [19. 20. 21.]
#  [22. 23. 24.]]
