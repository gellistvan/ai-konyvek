import numpy as np
x = np.array([1.0, 2.0, 0.0, 1.0])
w = np.array([1.0, 1.0, 1.0])
xpad = np.pad(x, (0, 1))              # 5 hossz
wpad = np.pad(w, (0, 2))              # 5 hossz
y_fft = np.fft.ifft(np.fft.fft(xpad) * np.fft.fft(wpad)).real
print(y_fft)  # hibás? hasonlítsa a zero paddinges corr_1d-hez
