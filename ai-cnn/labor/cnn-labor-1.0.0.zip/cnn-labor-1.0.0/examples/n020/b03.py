idx_all = np.arange(len(train_images))
for b in range(B):
    sample = rng.permutation(idx_all)[:len(idx_all)]  # visszatevés nélkül!
    boot[b] = estimator(train_images[sample])
