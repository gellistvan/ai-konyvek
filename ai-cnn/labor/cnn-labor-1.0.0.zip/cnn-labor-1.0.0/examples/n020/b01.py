# n020_lab.py — futtatás: python n020_lab.py
# Munkakönyvtár: a projekt gyökere, ahol a lab/data/ elérhető.
import numpy as np
import pandas as pd
from pathlib import Path

data_dir = Path("lab/data")
rng = np.random.default_rng(20261020)  # seed a replikátumokhoz
images = np.load(data_dir / "images.npy")          # (360,1,24,24), float32
# A metadata.csv oszlopai: index (globális képazonosító az images.npy-ban),
# scene_id (klaszter), view_id (nézet), label (osztály), split (train/val/test),
# majd a befoglaló doboz koordinátái. A labor az index, scene_id, label és
# split oszlopokat használja.
meta = pd.read_csv(data_dir / "metadata.csv")

train = meta[meta["split"] == "train"].reset_index(drop=True)
# train: 240 kép, 120 jelenet, osztályonként 40 jelenet
train_idx = train["index"].to_numpy()              # (240,)
train_images = images[train_idx]                   # (240,1,24,24)

def estimator(imgs: np.ndarray) -> float:
    """Átlagos intenzitás; float64-re konvertálva a stabil összegzéshez."""
    return float(np.asarray(imgs, dtype=np.float64).mean())

B = 2000
# 1) Képenkénti bootstrap: 240 képből 240 húzás visszatevéssel.
boot_img = np.empty(B, dtype=np.float64)
for b in range(B):
    idx = rng.integers(0, len(train_images), size=len(train_images))
    boot_img[b] = estimator(train_images[idx])

# 2) Jelenetenkénti, osztályonként rétegzett bootstrap.
# A GlyphLab generálása osztályonként rögzített jelenetszámot használ;
# a bootstrap ezt a rétegzést megőrzi: osztályonként 40 jelenetet húz.
scenes_by_label = {lab: np.unique(train.loc[train["label"] == lab, "scene_id"])
                   for lab in np.unique(train["label"])}
scene_to_idx = train.groupby("scene_id")["index"].apply(np.array).to_dict()

boot_scene = np.empty(B, dtype=np.float64)
for b in range(B):
    chosen = []
    for lab, scene_ids in scenes_by_label.items():
        drawn = rng.choice(scene_ids, size=len(scene_ids), replace=True)
        for sid in drawn:
            chosen.extend(scene_to_idx[sid])
    sel = np.array(chosen, dtype=np.int64)
    assert len(sel) == len(train_images), "a rétegzett bootstrap mérete sérült"
    # sel globális indexeket tartalmaz, ezért az images tömbből kell venni
    boot_scene[b] = estimator(images[sel])

ci_img = np.quantile(boot_img, [0.025, 0.975])
ci_scene = np.quantile(boot_scene, [0.025, 0.975])
print(f"train képek száma: {len(train_images)}, jelenetek száma: {train['scene_id'].nunique()}")
print(f"képenkénti bootstrap: átlag={boot_img.mean():.6f}, sd={boot_img.std(ddof=1):.6f}, "
      f"95% percentilis CI=({ci_img[0]:.6f}, {ci_img[1]:.6f})")
print(f"jelenetenkénti bootstrap: átlag={boot_scene.mean():.6f}, sd={boot_scene.std(ddof=1):.6f}, "
      f"95% percentilis CI=({ci_scene[0]:.6f}, {ci_scene[1]:.6f})")
ratio = boot_scene.std(ddof=1) / boot_img.std(ddof=1)
sample_mean = estimator(images[train_idx])
assert abs(boot_img.mean() - sample_mean) < 1e-3
assert abs(boot_scene.mean() - sample_mean) < 1e-3
assert ratio > 1.0, "a jelenetalapu szoras nem nagyobb a kepenkinel"
print(f"szórások aránya (jelenet/kép): {ratio:.3f}")
print("ellenorzes: a bootstrap-atlagok a mintaatlag kozeleben, az arany > 1")
