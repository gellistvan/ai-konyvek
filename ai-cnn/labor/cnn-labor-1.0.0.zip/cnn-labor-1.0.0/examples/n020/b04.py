import numpy as np

def cluster_bootstrap(data, clusters, B, rng):
    data = np.asarray(data, dtype=np.float64)
    clusters = np.asarray(clusters)
    unique_clusters = np.unique(clusters)
    idx_by_cluster = {c: np.flatnonzero(clusters == c)
                      for c in unique_clusters}
    result = np.empty(B, dtype=np.float64)
    for b in range(B):
        drawn = rng.choice(unique_clusters, size=len(unique_clusters),
                           replace=True)
        idx = np.concatenate([idx_by_cluster[c] for c in drawn])
        result[b] = data[idx].mean()
    return result
