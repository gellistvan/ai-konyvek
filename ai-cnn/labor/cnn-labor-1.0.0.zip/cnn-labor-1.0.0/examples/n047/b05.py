import torch, math
import torch.nn as nn

def grad_norm(model):
    sq = 0.0
    for p in model.parameters():
        if p.grad is not None:
            sq += float((p.grad ** 2).sum().item())
    return math.sqrt(sq)

lin = nn.Linear(2, 1, bias=False)
lin.weight.grad = torch.tensor([[3.0, 4.0]])  # mesterséges feltöltés
print(f"{grad_norm(lin):.4f}")  # 5.0000
