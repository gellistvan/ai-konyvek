# lab/sanity_check.py — munkakönyvtár: lab/
import csv
import math
import numpy as np
import torch
import torch.nn as nn

torch.manual_seed(20261020)
np.random.seed(20261020)
device = torch.device("cpu")
dtype = torch.float32

# --- Adatút a metadata index és split mezője alapján ---
images = np.load("data/images.npy").astype(np.float32)
labels = np.load("data/labels.npy").astype(np.int64)
with open("data/metadata.csv", newline="", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))
# A CSV sorszáma nem azonos a képtömb sorszámával: az index mező köt.
assert list(rows[0]) == ["index", "scene_id", "view_id", "label", "split",
                         "xmin", "ymin", "xmax", "ymax"], list(rows[0])
assert len(rows) == 360, len(rows)
assert [int(r["index"]) for r in rows] == list(range(len(rows)))
assert len(images) == len(labels) == len(rows), (images.shape, labels.shape)

# Scene-split invariáns: egy jelenet minden nézete ugyanabban a splitben van.
scene_splits = {}
for r in rows:
    scene_splits.setdefault(r["scene_id"], set()).add(r["split"])
assert all(len(s) == 1 for s in scene_splits.values()), "szivárgó jelenet"

train_idx = np.array([int(r["index"]) for r in rows if r["split"] == "train"])

# 16 train kép, osztályonként legalább 5
chosen = []
for c in (0, 1, 2):
    idx_c = train_idx[labels[train_idx] == c]
    assert len(idx_c) >= 5, (c, len(idx_c))
    chosen.extend(np.random.choice(idx_c, size=5, replace=False).tolist())
chosen = np.array(chosen, dtype=np.int64)  # 15 minta; a 16. más train kép
extra = np.random.choice(np.setdiff1d(train_idx, chosen), size=1, replace=False)
chosen = np.concatenate([chosen, extra])
assert len(set(chosen.tolist())) == 16

x = torch.tensor(images[chosen], dtype=dtype, device=device)  # (16,1,24,24)
y = torch.tensor(labels[chosen], dtype=torch.int64, device=device)  # (16,)

class TinyCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Conv2d(1, 8, 3, padding=1)
        self.pool = nn.MaxPool2d(2)
        self.fc = nn.Linear(8 * 12 * 12, 3)

    def forward(self, x):
        z = self.pool(torch.relu(self.conv(x)))
        return self.fc(z.flatten(1))

def grad_norm(model):
    sq = 0.0
    for p in model.parameters():
        if p.grad is not None:
            sq += float((p.grad.detach() ** 2).sum().item())
    return math.sqrt(sq)

def run(model, x, y, epochs=200, lr=1e-3):
    params = [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.Adam(params, lr=lr) if params else None
    loss_fn = nn.CrossEntropyLoss()
    # history[k] a k. frissítés utáni loss; history[0] a frissítés előtti érték.
    history = []
    with torch.no_grad():
        history.append(float(loss_fn(model(x), y).item()))
    if opt is not None:
        for _ in range(epochs):
            opt.zero_grad()
            loss = loss_fn(model(x), y)
            loss.backward()
            opt.step()
            with torch.no_grad():
                history.append(float(loss_fn(model(x), y).item()))
        # A jelentett gradiens a végleges theta_T pontban értendő.
        opt.zero_grad()
        loss_fn(model(x), y).backward()
    with torch.no_grad():
        acc = (model(x).argmax(1) == y).float().mean().item()
        final = float(loss_fn(model(x), y).item())
    return final, acc, grad_norm(model), history

# 1) clean tiny overfit
m = TinyCNN().to(device)
l1, a1, g1, h1 = run(m, x, y)
print(f"[clean tiny] loss={l1:.4f} acc={a1:.3f} grad_norm={g1:.4f}")
print("[clean tiny curve]", [(e, round(h1[e], 4)) for e in (0, 10, 50, 200)])
assert l1 < 0.2 and a1 >= 0.9

# 2) random labels
perm = torch.randperm(y.numel())
y_rand = y[perm].clone()
m2 = TinyCNN().to(device)
l2, a2, g2, _ = run(m2, x, y_rand)
print(f"[random label] loss={l2:.4f} acc={a2:.3f} grad_norm={g2:.4f}")
assert l2 < 0.2 and a2 >= 0.9

# 3) frozen weights
m3 = TinyCNN().to(device)
for p in m3.parameters():
    p.requires_grad_(False)
l3, a3, g3, _ = run(m3, x, y)  # nincs trainable paraméter; a tanítási ciklus nem fut
print(f"[frozen] loss={l3:.4f} acc={a3:.3f} grad_norm={g3:.4f}")
assert l3 > 1.0 and g3 == 0.0

# 4) cyclic label mapping
y_bad = torch.tensor([2, 0, 1], dtype=torch.int64)[y].to(device)
m4 = TinyCNN().to(device)
l4, a4, g4, _ = run(m4, x, y_bad)
print(f"[label mapping] loss={l4:.4f} acc={a4:.3f} grad_norm={g4:.4f}")
assert l4 < 0.2 and a4 >= 0.9
