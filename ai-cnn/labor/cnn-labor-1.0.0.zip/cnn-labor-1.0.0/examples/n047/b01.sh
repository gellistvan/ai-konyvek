cd lab
python sanity_check.py
