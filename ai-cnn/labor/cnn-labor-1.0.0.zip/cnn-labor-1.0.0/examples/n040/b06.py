val_hist.append(forward_loss(X_val, y_val, W1, b1, W2, b2))  # helyes
