def train_step(W1, b1, W2, b2, Xb, yb, lr):
    """Egy minibatch lépés; visszaadja az új paramétereket és a régi loss-t."""
    loss, dW1, db1, dW2, db2 = backward(Xb, yb, W1, b1, W2, b2)
    W1_new = W1 - lr * dW1
    b1_new = b1 - lr * db1
    W2_new = W2 - lr * dW2
    b2_new = b2 - lr * db2
    return W1_new, b1_new, W2_new, b2_new, loss
