perm = np.random.default_rng(4202).permutation(N_train)
Xb, yb = X_train[perm[:16]], y_train[perm[:16]]
loss_before = forward_loss(Xb, yb, W1, b1, W2, b2)
W1_new, b1_new, W2_new, b2_new, loss_returned = train_step(
    W1, b1, W2, b2, Xb, yb, 0.01)
loss_after = forward_loss(Xb, yb, W1_new, b1_new, W2_new, b2_new)
assert loss_returned == loss_before
assert loss_after < loss_before
