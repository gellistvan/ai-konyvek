# lab/n040_train_mlp.py — munkakönyvtár: lab/
"""n040 labor: kézi MLP tanítás minibatch SGD-vel, holdouttal."""
import numpy as np

# --- adat: eredeti szintetikus regresszió, seed rögzítve ---
rng_data = np.random.default_rng(4201)
N_train, N_val, d, h = 200, 50, 2, 16
X_train = rng_data.uniform(-2.0, 2.0, size=(N_train, d))
y_train = np.sin(2.0 * X_train[:, 0:1]) + 0.5 * X_train[:, 1:2]**2
y_train = y_train + rng_data.normal(0.0, 0.05, size=y_train.shape)
X_val = rng_data.uniform(-2.0, 2.0, size=(N_val, d))
y_val = np.sin(2.0 * X_val[:, 0:1]) + 0.5 * X_val[:, 1:2]**2
y_val = y_val + rng_data.normal(0.0, 0.05, size=y_val.shape)

# --- inicializálás ---
rng_init = np.random.default_rng(4203)
W1 = rng_init.normal(0.0, 0.3, size=(h, d))  # (h,d), a konvenció szerint
b1 = np.zeros(h)
W2 = rng_init.normal(0.0, 0.3, size=(1, h))  # (1,h)
b2 = np.zeros(1)
assert X_train.shape == (N_train, d) and y_train.shape == (N_train, 1)
assert W1.shape == (h, d) and W2.shape == (1, h)

def forward(X, W1, b1, W2, b2):
    Z1 = X @ W1.T + b1            # (M,h)
    A1 = np.tanh(Z1)
    Yhat = A1 @ W2.T + b2         # (M,1)
    return Yhat, A1

def forward_loss(X, Y, W1, b1, W2, b2):
    Yhat, _ = forward(X, W1, b1, W2, b2)
    return np.mean((Yhat - Y)**2)

def backward(X, Y, W1, b1, W2, b2):
    M = X.shape[0]
    Yhat, A1 = forward(X, W1, b1, W2, b2)
    dL_dZ2 = 2.0 / M * (Yhat - Y)       # (M,1), az átlag deriváltja
    dW2 = dL_dZ2.T @ A1                 # (1,h)
    db2 = dL_dZ2.sum(axis=0)            # (1,)
    dA1 = dL_dZ2 @ W2                   # (M,h)
    dZ1 = dA1 * (1.0 - A1**2)           # tanh lokális derivált
    dW1 = dZ1.T @ X                     # (h,d)
    db1 = dZ1.sum(axis=0)               # (h,)
    loss = np.mean((Yhat - Y)**2)
    assert Yhat.shape == Y.shape
    return loss, dW1, db1, dW2, db2

# --- tanítás: epochonként keverés, minibatch-ekre osztás ---
rng_train = np.random.default_rng(4202)
epochs, batch_size, lr = 300, 16, 0.01
train_hist, val_hist = [], []
for epoch in range(epochs):
    perm = rng_train.permutation(N_train)
    X_shuf, y_shuf = X_train[perm], y_train[perm]
    epoch_loss = 0.0
    for start in range(0, N_train, batch_size):
        idx = slice(start, start + batch_size)
        Xb, yb = X_shuf[idx], y_shuf[idx]
        loss, dW1, db1, dW2, db2 = backward(Xb, yb, W1, b1, W2, b2)
        # optimizerlépés: paraméterfrissítés, nincs akkumulátor, ezért nincs zero_grad
        W1 -= lr * dW1
        b1 -= lr * db1
        W2 -= lr * dW2
        b2 -= lr * db2
        # az utolsó batch 8 elemű lehet, ezért a batch-loss-t a méretével súlyozzuk
        epoch_loss += loss * yb.shape[0]
    train_hist.append(epoch_loss / N_train)
    val_hist.append(forward_loss(X_val, y_val, W1, b1, W2, b2))
    if epoch % 50 == 0 or epoch == epochs - 1:
        print(f"epoch {epoch:3d}  train={train_hist[-1]:.4f}  val={val_hist[-1]:.4f}")

print(f"final W1 norm: {np.linalg.norm(W1):.3f}, W2 norm: {np.linalg.norm(W2):.3f}")
assert np.isfinite(val_hist).all()
assert train_hist[-1] < train_hist[0]
assert val_hist[-1] > train_hist[-1]
