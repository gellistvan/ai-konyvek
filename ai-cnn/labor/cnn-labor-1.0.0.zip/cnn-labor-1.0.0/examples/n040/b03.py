# Szándékosan hibás részlet: a labor tanítási hurkának holdout-ága
for epoch in range(epochs):
    # ... a keverés és a minibatch-frissítések változatlanok ...
    val_hist.append(forward_loss(X_train, y_train, W1, b1, W2, b2))  # HIBÁS
