cd lab
uv sync
uv run python n006/lab_logsumexp.py
