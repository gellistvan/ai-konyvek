x = np.array([1_000_000.0, 1_000_000.1, 1_000_000.2], dtype=np.float32)
d = x - np.mean(x)
var_center = np.mean(d * d)
x64 = x.astype(np.float64)
ref = np.mean((x64 - np.mean(x64)) ** 2)
print("javított:", var_center)        # 0.0078125
print("referencia:", ref)             # 0.0060763889
assert var_center > 0, "A központosított variancia nem negatív."
assert abs(var_center - ref) < 2e-2, (
    "A float32 variancia eltérése a bemeneti kvantálás miatt nagyobb a megengedettnél."
)
