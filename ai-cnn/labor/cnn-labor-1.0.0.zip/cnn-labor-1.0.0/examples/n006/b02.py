# lab/n006/lab_logsumexp.py — naiv és stabil logsumexp nagy logitokon
import numpy as np

# Bemenet: 1-D float32 logitvektor
z = np.array([1000.0, 1001.0, 1002.0], dtype=np.float32)

def naive_logsumexp(v):
    # v alakja (K,), float32; itt overflow várható
    return np.log(np.sum(np.exp(v)))

def stable_logsumexp(v):
    # v alakja (K,), float32
    m = np.max(v)                 # max-logit, skalár float32
    shifted = v - m               # (K,) float32, minden elem <= 0
    return m + np.log(np.sum(np.exp(shifted)))

# float32 eredmények
naive = naive_logsumexp(z)
stable = stable_logsumexp(z)

# float64 referencia, a NumPy beépített stabilitását használva
ref64 = np.logaddexp.reduce(z.astype(np.float64))

print("naive:", naive)
print("  finite:", bool(np.isfinite(naive)))
print("stable:", stable)
print("  finite:", bool(np.isfinite(stable)))
print("ref64: ", ref64)

# Ellenőrzés: a stabil float32 érték véges legyen, és
# a float64 referenciához képest a skálához illő tűréssel egyezzen.
assert np.isfinite(stable), "A stabil eredmény nem véges."
assert np.allclose(stable, ref64, rtol=1e-6, atol=2e-4), (
    "A stabil float32 eredmény nem esik a megadott tűrésen belülre."
)

# Negatív nagy logitokon a naiv út alulcsordul: minden exp() nulla lesz,
# ezért log(0) = -inf; a NumPy RuntimeWarningot ad
z2 = np.array([-1000.0, -1001.0, -1002.0], dtype=np.float32)
naive_neg = naive_logsumexp(z2)   # RuntimeWarning: divide by zero encountered in log
print("naive negatív:", naive_neg)
print("stable negatív:", stable_logsumexp(z2))
print("finite negatív:", bool(np.isfinite(stable_logsumexp(z2))))
