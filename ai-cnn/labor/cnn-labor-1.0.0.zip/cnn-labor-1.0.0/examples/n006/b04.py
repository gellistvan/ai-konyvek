x = np.array([1_000_000.0, 1_000_000.1, 1_000_000.2], dtype=np.float32)
mean_x = np.mean(x)
var_naive = np.mean(x * x) - mean_x * mean_x
print(var_naive)
