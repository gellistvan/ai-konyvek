import numpy as np

def stable_softmax(Z):
    # Z alakja (N, K), float32
    m = np.max(Z, axis=1, keepdims=True)       # (N, 1)
    E = np.exp(Z - m)                          # (N, K)
    return E / np.sum(E, axis=1, keepdims=True) # (N, K)

Z = np.array([[1000.0, 1000.0],
              [0.0, 1.0]], dtype=np.float32)
P = stable_softmax(Z)
print(P)
print("Sorösszegek:", np.sum(P, axis=1))

# Ellenőrzés: a sorösszegek 1-hez közeliek, és az ismert értékek is stimmelnek
np.testing.assert_allclose(np.sum(P, axis=1), 1.0, atol=1e-6)
expected = np.array([[0.5, 0.5],
                     [1.0 / (1.0 + np.e), np.e / (1.0 + np.e)]],
                    dtype=np.float32)
np.testing.assert_allclose(P, expected, rtol=1e-6, atol=1e-6)
