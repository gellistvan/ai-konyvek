import numpy as np

def topk_error_bad(logits, labels, k):
    p = np.exp(logits - logits.max(axis=1, keepdims=True))
    p /= p.sum(axis=1, keepdims=True)
    top = np.argsort(-p, axis=1)[:, :k]
    hit = np.any(top == labels[:, None], axis=1)
    return hit.mean()
