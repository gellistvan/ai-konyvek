import numpy as np

def topk_error(logits, labels, k):
    # logits: (N, K) float32; labels: (N,) int64
    p = np.exp(logits - logits.max(axis=1, keepdims=True))
    p = p / p.sum(axis=1, keepdims=True)
    top = np.argsort(-p, axis=1)[:, :k]
    hit = np.any(top == labels[:, None], axis=1)
    return 1.0 - hit.mean()

Z = np.array([[1.2, 0.3, 2.5],
              [0.1, 1.8, 0.9]], dtype=np.float32)
y = np.array([2, 0], dtype=np.int64)
print(topk_error(Z, y, k=2))  # várt: 0.5
