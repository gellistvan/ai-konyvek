def conv_out(h, w, kh, kw, s, p):
    ho = (h + 2*p - kh) // s + 1
    wo = (w + 2*p - kw) // s + 1
    return ho, wo

def pool_out(h, w, k, s):
    ho = (h - k) // s + 1
    wo = (w - k) // s + 1
    return ho, wo

# Bemenet: 227x227x3, NCHW alakban csatorna elöl.
H, W = 227, 227
cin = 3

# conv1: 96 db 11x11 kernel, stride 4, padding 0
h, w = conv_out(H, W, 11, 11, 4, 0)
p1 = 96 * cin * 11 * 11 + 96
assert (h, w) == (55, 55) and p1 == 34_944
print(f"conv1: {96}x{h}x{w}, params={p1}")

# pool1: 3x3, stride 2
h, w = pool_out(h, w, 3, 2)
assert (h, w) == (27, 27)
print(f"pool1: {96}x{h}x{w}")

# conv2: 256 db 5x5 kernel, stride 1, padding 2
h, w = conv_out(h, w, 5, 5, 1, 2)
p2 = 256 * 96 * 5 * 5 + 256  # cin=96 a conv1 kimenete (g=1)
assert (h, w) == (27, 27) and p2 == 614_656
print(f"conv2: {256}x{h}x{w}, params={p2}")

# pool2: 3x3, stride 2
h, w = pool_out(h, w, 3, 2)
assert (h, w) == (13, 13)
print(f"pool2: {256}x{h}x{w}")

# conv3, conv4, conv5: 3x3, stride 1, padding 1
expected = {"conv3": (384, 13, 13, 885_120),
            "conv4": (384, 13, 13, 1_327_488),
            "conv5": (256, 13, 13, 884_992)}
for name, cout, cin_prev in [("conv3", 384, 256), ("conv4", 384, 384), ("conv5", 256, 384)]:
    h, w = conv_out(h, w, 3, 3, 1, 1)
    p = cout * cin_prev * 3 * 3 + cout
    assert (cout, h, w, p) == expected[name]
    print(f"{name}: {cout}x{h}x{w}, params={p}")

# pool3: 3x3, stride 2
h, w = pool_out(h, w, 3, 2)
assert (h, w) == (6, 6)
print(f"pool3: {256}x{h}x{w}")

# FC rétegek
fc_expected = {"fc1": 37_752_832, "fc2": 16_781_312, "fc3": 4_097_000}
for name, cout, cin_prev in [("fc1", 4096, 256*h*w), ("fc2", 4096, 4096), ("fc3", 1000, 4096)]:
    p = cout * cin_prev + cout
    assert p == fc_expected[name]
    print(f"{name}: {cout}, params={p}")

assert 34_944 + 614_656 + 885_120 + 1_327_488 + 884_992 + 37_752_832 + 16_781_312 + 4_097_000 == 62_378_344
print("minden assert lefutott")
