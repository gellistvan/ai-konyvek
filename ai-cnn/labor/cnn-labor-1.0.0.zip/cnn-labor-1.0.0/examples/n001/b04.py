X = ...  # a teljes megfigyelés
y = ...
grid = [...]
best = min(grid, key=lambda a: np.mean((X > a) != y))
report = np.mean((X > best) != y)
