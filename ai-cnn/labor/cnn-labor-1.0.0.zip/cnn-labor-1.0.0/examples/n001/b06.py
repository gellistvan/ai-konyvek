train_idx, test_idx = fixed_split(...)
best = min(grid, key=lambda a: np.mean((X[train_idx] > a) != y[train_idx]))
report = np.mean((X[test_idx] > best) != y[test_idx])
