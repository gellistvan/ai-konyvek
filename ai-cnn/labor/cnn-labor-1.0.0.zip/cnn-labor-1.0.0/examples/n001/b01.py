# munkakönyvtár: lab/
import numpy as np

X = np.array([[0.0, 0.0],
              [1.0, 0.0],
              [0.0, 1.0],
              [1.0, 1.0]], dtype=np.float32)  # (4, 2)
y = np.array([0, 1, 1, 0], dtype=np.int64)   # (4,)

def train_error(w1, w2, b):
    z = X @ np.array([w1, w2], dtype=np.float32) + b
    pred = (z > 0).astype(np.int64)
    return float(np.mean(pred != y))

grid_w = [-1, 0, 1]
grid_b = [-2, -1, 0, 1, 2]
best = (None, None, None, np.inf)
for w1 in grid_w:
    for w2 in grid_w:
        for b in grid_b:
            err = train_error(w1, w2, b)
            if err < best[3]:
                best = (w1, w2, b, err)
print(best)  # (-1, -1, 2, 0.25)
