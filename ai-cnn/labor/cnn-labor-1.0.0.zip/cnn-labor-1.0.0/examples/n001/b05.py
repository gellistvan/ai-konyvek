# lab/f3_grid_linear.py
import numpy as np

def grid_linear(X, y):
    assert X.ndim == 2 and X.shape[1] == 2
    assert X.dtype == np.float32
    assert y.ndim == 1 and y.dtype == np.int64
    assert X.shape[0] == y.shape[0] > 0, "azonos, pozitív mintaszám kell"
    best = None
    grid_w = [-1, 0, 1]
    grid_b = [-2, -1, 0, 1, 2]
    for w1 in grid_w:
        for w2 in grid_w:
            w = np.array([w1, w2], dtype=np.float32)
            for b in grid_b:
                z = X @ w + b
                pred = (z > 0).astype(np.int64)
                err = np.mean(pred != y)
                if best is None or err < best[3]:
                    best = (w1, w2, b, err, pred.copy())
    return best

X = np.array([[0.0, 0.0], [1.0, 0.0],
              [0.0, 1.0], [1.0, 1.0]], dtype=np.float32)
y = np.array([0, 1, 1, 0], dtype=np.int64)
w1, w2, b, err, pred = grid_linear(X, y)
assert (w1, w2, b) == (-1, -1, 2)
np.testing.assert_allclose(err, 0.25, rtol=1e-7, atol=1e-10)
assert pred.shape == y.shape == (4,)
np.testing.assert_array_equal(pred, np.array([1, 1, 1, 0], dtype=np.int64))
