# n053_lab/shape_test.py
import torch


def out1d(length, kernel, pad, stride, dilation):
    """Egy térbeli dimenzió kimeneti mérete szimmetrikus paddinggel."""
    assert length >= 1 and kernel >= 1 and stride >= 1 and dilation >= 1
    assert pad >= 0
    # A Python // negatív számlálónál is floor szerint oszt, ahogy a tételben a ⌊·⌋.
    numerator = length + 2 * pad - dilation * (kernel - 1) - 1
    if numerator < 0:
        raise ValueError(
            f"érvénytelen kimenet: d*(k-1)+1={dilation * (kernel - 1) + 1} "
            f"> L+2*p={length + 2 * pad}"
        )
    return numerator // stride + 1


def expected_shape(H, W, kh, kw, ph, pw, sh, sw, dh, dw):
    return (out1d(H, kh, ph, sh, dh), out1d(W, kw, pw, sw, dw))


def main():
    torch.manual_seed(20261020)
    dtype = torch.float32
    device = torch.device("cpu")

    # (H, W, kh, kw, ph, pw, sh, sw, dh, dw, név)
    cases = [
        (5, 5, 3, 3, 0, 0, 1, 1, 1, 1, "valid, négyzetes"),
        (7, 5, 3, 3, 1, 1, 1, 1, 1, 1, "nemnégyzetes, padding"),
        (8, 10, 3, 5, 0, 0, 1, 1, 1, 1, "nemnégyzetes input és kernel"),
        (7, 6, 3, 3, 0, 0, 2, 2, 1, 1, "stride 2, padding nélkül"),
        (9, 8, 3, 3, 0, 0, 1, 1, 2, 2, "dilation 2"),
        (5, 4, 4, 4, 1, 1, 2, 2, 1, 1, "padding+stride"),
        (13, 7, 5, 5, 0, 0, 2, 2, 1, 1, "nagyobb nemnégyzetes"),
        (6, 6, 6, 6, 0, 0, 1, 1, 1, 1, "éppen 1x1 kimenet"),
    ]

    for (H, W, kh, kw, ph, pw, sh, sw, dh, dw, name) in cases:
        exp = expected_shape(H, W, kh, kw, ph, pw, sh, sw, dh, dw)
        x = torch.zeros(1, 2, H, W, dtype=dtype, device=device)
        conv = torch.nn.Conv2d(2, 3, (kh, kw),
                               stride=(sh, sw),
                               padding=(ph, pw),
                               dilation=(dh, dw),
                               bias=False,
                               dtype=dtype, device=device)
        got = tuple(conv(x).shape[2:])
        assert got == exp, (name, got, exp)
        print(f"{name:30s} formula={exp} torch={got}")

    # Érvénytelen beállítás: a számláló negatív, ezért a formula nem használható.
    # A Conv2d forward ilyenkor RuntimeError-t ad, a saját függvényünk ValueError-t vet.
    invalid = [(3, 4, 0, 1, 1), (4, 5, 0, 1, 1)]
    for L, k, p, s, d in invalid:
        try:
            out1d(L, k, p, s, d)
        except ValueError as exc:
            print(f"érvénytelen L={L},k={k},p={p},s={s},d={d}: {exc}")
        else:
            raise AssertionError((L, k, p, s, d))
    print("Minden alaktartalom-ellenőrzés rendben.")


if __name__ == "__main__":
    main()
