def out_bad(L, k, p, s, d):
    return (L + 2*p - (k - 1) - 1)//s + 1
