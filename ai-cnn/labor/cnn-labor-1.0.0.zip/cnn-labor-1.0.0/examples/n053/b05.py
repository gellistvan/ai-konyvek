import torch

def out1d(L, k, p, s, d):
    numerator = L + 2*p - d*(k - 1) - 1
    if numerator < 0:
        raise ValueError("érvénytelen kimenet: a kernel nagyobb a paddelt bemenetnél")
    return numerator//s + 1

def expected_shape(H, W, kh, kw, ph, pw, sh, sw, dh, dw):
    return (out1d(H, kh, ph, sh, dh), out1d(W, kw, pw, sw, dw))

cases = [
    ((5, 5), 3, 0, 1, 1),
    ((7, 5), 3, 1, 1, 1),
    ((7, 6), 3, 0, 2, 1),
    ((9, 8), 3, 0, 1, 2),
    ((5, 4), 4, 1, 2, 1),
    ((13, 7), 5, 0, 2, 1),
]
for (H, W), k, p, s, d in cases:
    exp = expected_shape(H, W, k, k, p, p, s, s, d, d)
    x = torch.zeros(1, 1, H, W)
    y = torch.nn.functional.conv2d(x, torch.zeros(1, 1, k, k),
                                  stride=s, padding=p, dilation=d)
    assert tuple(y.shape[2:]) == exp, (exp, y.shape)
    print((H, W), "->", exp)

try:
    out1d(3, 4, 0, 1, 1)
except ValueError:
    pass
else:
    raise AssertionError("az érvénytelen eset nem jelzett")
print("érvénytelen eset ellenőrizve")
