def out_fixed(L, k, p, s, d):
    return (L + 2*p - d*(k - 1) - 1)//s + 1

assert out_fixed(9, 3, 0, 1, 2) == 5
assert out_bad(9, 3, 0, 1, 2) == 7
