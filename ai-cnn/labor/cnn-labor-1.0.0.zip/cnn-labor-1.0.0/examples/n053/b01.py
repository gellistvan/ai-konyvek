import torch

H, W, k, ph, pw, s, d = 6, 5, 3, 1, 0, 2, 1
formula = ((H + 2*ph - d*(k-1) - 1)//s + 1,
           (W + 2*pw - d*(k-1) - 1)//s + 1)
conv = torch.nn.Conv2d(2, 4, k, stride=s, padding=(ph, pw), dilation=d,
                       bias=False, dtype=torch.float32, device="cpu")
y = conv(torch.zeros(1, 2, H, W, dtype=torch.float32, device="cpu"))
assert formula == tuple(y.shape[2:]), (formula, y.shape)
print("formula:", formula, "torch:", tuple(y.shape[2:]))
