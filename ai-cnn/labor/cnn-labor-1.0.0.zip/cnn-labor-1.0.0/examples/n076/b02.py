# lab/n076/n076_mini_block.py
import torch
import torch.nn as nn

torch.manual_seed(20261020)
device = torch.device("cpu")

class MiniConvNeXtBlock(nn.Module):
    """Kisméretű ConvNeXt-szerű blokk, bias nélküli konvolúciókkal.

    Alak: (N,C,H,W) -> (N,C,H,W), stride=1, szimmetrikus padding.
    """
    def __init__(self, dim, expand, kernel):
        super().__init__()
        assert kernel % 2 == 1, "a szimmetrikus paddinghez páratlan kernel kell"
        pad = kernel // 2
        self.dw = nn.Conv2d(dim, dim, kernel_size=kernel,
                            padding=pad, groups=dim, bias=False)
        self.norm = nn.LayerNorm(dim)  # NHWC-ben a csatornadimenzióra
        self.pw1 = nn.Conv2d(dim, dim * expand, kernel_size=1, bias=False)
        self.act = nn.GELU()
        self.pw2 = nn.Conv2d(dim * expand, dim, kernel_size=1, bias=False)
        self.gamma = nn.Parameter(torch.ones(dim, 1, 1))

    def forward(self, x):
        h = self.dw(x)                    # (N,C,H,W)
        h = h.permute(0, 2, 3, 1)        # NHWC
        h = self.norm(h)                 # (N,H,W,C)
        h = h.permute(0, 3, 1, 2)        # NCHW
        h = self.pw1(h)
        h = self.act(h)
        h = self.pw2(h)
        h = h * self.gamma
        return x + h

dim, expand, kernel = 2, 4, 5
model = MiniConvNeXtBlock(dim, expand, kernel).to(device).to(torch.float32)
x = torch.randn(1, dim, 8, 8, device=device, dtype=torch.float32)
y = model(x)

weight = model.dw.weight
n_params = sum(p.numel() for p in model.parameters())
# Kézi képlet: dw C*k^2, pw1 és pw2 2*E*C^2, gamma és LayerNorm együtt 3C.
expected_params = dim * kernel**2 + 2 * expand * dim**2 + 3 * dim
assert tuple(weight.shape) == (dim, 1, kernel, kernel), weight.shape
assert tuple(y.shape) == tuple(x.shape), y.shape
assert n_params == expected_params, (n_params, expected_params)
print("dw weight shape:", tuple(weight.shape))
print("output shape:", tuple(y.shape))
print("params:", n_params, "expected:", expected_params)
print("norm type:", type(model.norm).__name__,
      "| gamma shape:", tuple(model.gamma.shape))
