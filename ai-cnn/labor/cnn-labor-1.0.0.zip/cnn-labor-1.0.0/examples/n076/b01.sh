cd lab/n076
python n076_mini_block.py
