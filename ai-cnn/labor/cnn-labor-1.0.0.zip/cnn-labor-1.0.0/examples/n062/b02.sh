cd lab && python -c "
import numpy as np
C = ((np.indices((8,8)).sum(0))%2).astype('float32')[None,None]
S = (((np.arange(8)[:,None]-1)%4)<2).astype('float32') * np.ones((1,8),'float32')
S = S[None,None]
def pool(X, mode):
    V = X[0,0].reshape(4,2,4,2)
    return (V.max(axis=(1,3)) if mode == 'max' else V.mean(axis=(1,3)))
def box(X):
    return (X[:,:, :-1, :-1] + X[:,:,1:, :-1] + X[:,:, :-1,1:] + X[:,:,1:,1:]) / 4
for name, X in [('C', C), ('S', S)]:
    B = box(X)
    print(name, 'max', pool(X, 'max').tolist())
    print(name, 'avg', pool(X, 'avg').tolist())
    print(name, 'box even', B[:,:,::2,::2][0,0].tolist())
    print(name, 'box odd', B[:,:,1::2,1::2][0,0].tolist())
    if name == 'C':
        assert np.allclose(pool(X, 'max'), 1.0)
        assert np.allclose(pool(X, 'avg'), 0.5)
        assert np.allclose(B[:,:,::2,::2], 0.5)
        assert np.allclose(B[:,:,1::2,1::2], 0.5)
    else:
        assert np.allclose(pool(X, 'max'), 1.0)
        assert np.allclose(pool(X, 'avg'), 0.5)
        assert np.allclose(B[:,:,::2,::2], 0.5)
        assert np.allclose(B[:,:,1::2,::2][0,0,:,0], [1.0, 0.0, 1.0])
"
