# munkakönyvtár: lab/
# fájl: pooling_reference.py
import numpy as np

def max_pool2d(X: np.ndarray, k: tuple[int, int], s: tuple[int, int]) -> np.ndarray:
    """NCHW max pooling, zero padding nélkül, teljes ablakokkal.

    X: float32, alak (N, C, H, W).
    k, s: (kh, kw), (sh, sw) pozitív egészek.
    """
    N, C, H, W = X.shape
    kh, kw = k
    sh, sw = s
    Ho = (H - kh) // sh + 1
    Wo = (W - kw) // sw + 1
    Y = np.empty((N, C, Ho, Wo), dtype=np.float32)
    for i in range(Ho):
        for j in range(Wo):
            patch = X[:, :, i*sh:i*sh+kh, j*sw:j*sw+kw]
            Y[:, :, i, j] = patch.max(axis=(2, 3))
    return Y

# kézi példa
X = np.array([[[
    [1,0,2,1],
    [0,3,2,0],
    [0,0,4,0],
    [1,0,0,1]
]]], dtype=np.float32)
Y = max_pool2d(X, (2,2), (2,2))
assert Y.shape == (1, 1, 2, 2)
assert Y.tolist() == [[[[3.0, 2.0], [1.0, 4.0]]]]
print(Y.shape, Y.tolist())
# mért kimenet: (1, 1, 2, 2) [[[[3.0, 2.0], [1.0, 4.0]]]]
