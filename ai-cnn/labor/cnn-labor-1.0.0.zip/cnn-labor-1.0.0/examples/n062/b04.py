import numpy as np

def avg_pool2d(X, k, s):
    N, C, H, W = X.shape; kh, kw = k; sh, sw = s
    Ho = (H - kh)//sh + 1; Wo = (W - kw)//sw + 1
    Y = np.empty((N, C, Ho, Wo), dtype=X.dtype)
    for i in range(Ho):
        for j in range(Wo):
            patch = X[:, :, i*sh:i*sh+kh, j*sw:j*sw+kw]
            Y[:, :, i, j] = patch.mean(axis=(2, 3))
    return Y

X4 = np.array([[[[1,0,2,1],[0,3,2,0],[0,0,4,0],[1,0,0,1]]]], dtype=np.float32)
Y4 = avg_pool2d(X4, (2, 2), (2, 2))
assert Y4.shape == (1, 1, 2, 2)
assert np.allclose(Y4, [[[[1.0, 1.25], [0.25, 1.25]]]])

X5 = np.arange(25, dtype=np.float32).reshape(1, 1, 5, 5)
Y5 = avg_pool2d(X5, (2, 2), (1, 1))
assert Y5.shape == (1, 1, 4, 4)

Ygap = avg_pool2d(X5, (X5.shape[2], X5.shape[3]), (1, 1))  # global average pooling
assert Ygap.shape == (1, 1, 1, 1) and np.isclose(Ygap.squeeze(), X5.mean())
print(Y4.shape, Y5.shape, Ygap.shape)
# mért kimenet: (1, 1, 2, 2) (1, 1, 4, 4) (1, 1, 1, 1)
