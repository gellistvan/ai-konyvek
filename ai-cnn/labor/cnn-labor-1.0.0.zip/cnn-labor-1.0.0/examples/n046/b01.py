# lab/n046_checkpoint/checkpoint_lab.py — munkakönyvtár: lab/n046_checkpoint/

from pathlib import Path

import torch
from torch import nn, optim

HERE = Path(__file__).resolve().parent
HERE.mkdir(parents=True, exist_ok=True)

SEED = 20261020
DTYPE = torch.float32
DEVICE = torch.device("cpu")
LR = 0.5
MOMENTUM = 0.9
STEPS_A = 2
TOTAL = 4

torch.manual_seed(SEED)
torch.use_deterministic_algorithms(True)

X = torch.linspace(-1.0, 1.0, 48, dtype=DTYPE).reshape(16, 3)
Y = (1.5 * X[:, 0] + 0.5 * X[:, 1] - 0.7 * X[:, 2] + 0.2).unsqueeze(1)

def make_model():
    torch.manual_seed(SEED)
    return nn.Sequential(nn.Linear(3, 4), nn.ReLU(), nn.Dropout(0.5),
                         nn.Linear(4, 1)).to(DEVICE)

def one_step(model, optimizer):
    model.train()
    optimizer.zero_grad()
    loss = torch.nn.functional.mse_loss(model(X), Y)
    loss.backward()
    optimizer.step()
    return loss.item()

# 1. Kontroll: négy lépés egyben.
model_cont = make_model()
opt_cont = optim.SGD(model_cont.parameters(), lr=LR, momentum=MOMENTUM)
losses_cont = [one_step(model_cont, opt_cont) for _ in range(TOTAL)]

# 2. Checkpoint-ág: két lépés, teljes állapot mentése.
model_a = make_model()
opt_a = optim.SGD(model_a.parameters(), lr=LR, momentum=MOMENTUM)
losses_a = [one_step(model_a, opt_a) for _ in range(STEPS_A)]
cp = {
    "model": model_a.state_dict(),
    "optimizer": opt_a.state_dict(),
    "epoch": 0,
    "step": STEPS_A,
    "rng": torch.get_rng_state(),
}
torch.save(cp, HERE / "checkpoint.pt")

# 3. Új folyamat szimulálása ugyanabban a folyamatban: friss modell,
#    optimizer és betöltés.
model_b = make_model()
opt_b = optim.SGD(model_b.parameters(), lr=LR, momentum=MOMENTUM)
cp2 = torch.load(HERE / "checkpoint.pt", weights_only=True)
model_b.load_state_dict(cp2["model"])
opt_b.load_state_dict(cp2["optimizer"])
torch.set_rng_state(cp2["rng"])
losses_b = [one_step(model_b, opt_b) for _ in range(TOTAL - STEPS_A)]
losses_chk = losses_a + losses_b

# 4. Bitazonossági ellenőrzés a paramétereken.
max_abs = max((p1.detach() - p2.detach()).abs().max().item()
              for p1, p2 in zip(model_cont.parameters(), model_b.parameters()))
print("control_losses:", [f"{v:.6f}" for v in losses_cont])
print("resumed_losses:", [f"{v:.6f}" for v in losses_chk])
print(f"max_abs_diff={max_abs:.3e}")
assert max_abs < 1e-6
assert max(abs(a - b) for a, b in zip(losses_cont, losses_chk)) < 1e-6

# 4b. Negatív kontroll: RNG-visszaállítás nélkül a folytatás eltér.
model_c = make_model()
opt_c = optim.SGD(model_c.parameters(), lr=LR, momentum=MOMENTUM)
model_c.load_state_dict(cp2["model"])
opt_c.load_state_dict(cp2["optimizer"])
# szándékosan NINCS torch.set_rng_state(cp2["rng"])
losses_c = [one_step(model_c, opt_c) for _ in range(TOTAL - STEPS_A)]
max_abs_no_rng = max((p1.detach() - p2.detach()).abs().max().item()
                     for p1, p2 in zip(model_cont.parameters(), model_c.parameters()))
print(f"max_abs_diff_no_rng={max_abs_no_rng:.3e}")
assert max_abs_no_rng > 1e-6

# 5. A referenciamásolat hibájának bemutatása.
snapshot_ref = model_b.state_dict()          # referencia, nem független másolat
one_step(model_b, opt_b)                      # helyben módosító mutáció
print("reference_is_mutated:",
      snapshot_ref["0.weight"].equal(model_b[0].weight))
assert snapshot_ref["0.weight"].equal(model_b[0].weight)

snapshot_best = {k: v.detach().clone() for k, v in model_b.state_dict().items()}
one_step(model_b, opt_b)
print("clone_is_independent:",
      not snapshot_best["0.weight"].equal(model_b[0].weight))
assert not snapshot_best["0.weight"].equal(model_b[0].weight)
