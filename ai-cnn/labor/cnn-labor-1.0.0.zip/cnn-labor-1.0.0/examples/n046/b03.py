import torch

def save_training_state(model, optimizer, scheduler, epoch, step, path,
                        best_val_loss=None, best_step=None, extra_rng=None):
    """A teljes tanítási állapot mentése.

    extra_rng: a további RNG-források állapotai, a weights_only=True által
    engedett típusokkal (tenzor, bájt, primitív).
    """
    state = {
        "model": model.state_dict(),
        "optimizer": optimizer.state_dict(),
        "scheduler": scheduler.state_dict() if scheduler is not None else None,
        "epoch": epoch,
        "step": step,
        "best_val_loss": best_val_loss,
        "best_step": best_step,
        "rng": torch.get_rng_state(),
        "extra_rng": extra_rng,
    }
    torch.save(state, path)

def load_training_state(path, build_fn):
    state = torch.load(path, weights_only=True)
    model, optimizer, scheduler = build_fn()
    model.load_state_dict(state["model"])
    optimizer.load_state_dict(state["optimizer"])
    if scheduler is not None and state["scheduler"] is not None:
        scheduler.load_state_dict(state["scheduler"])
    torch.set_rng_state(state["rng"])
    position = {"epoch": state["epoch"], "step": state["step"],
                "best_val_loss": state["best_val_loss"],
                "best_step": state["best_step"],
                "extra_rng": state["extra_rng"]}
    return model, optimizer, scheduler, position
