h = torch.tanh(h_lin).detach()
