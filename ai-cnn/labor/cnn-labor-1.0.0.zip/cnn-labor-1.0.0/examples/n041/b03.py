# lab/n041/detach_demo.py
import torch

torch.manual_seed(20261020)
dtype = torch.float64
device = torch.device("cpu")

# 1. eset: detach a közepén
x = torch.tensor(2.0, dtype=dtype, device=device, requires_grad=True)
y = x**2 + 3*x          # y = 10
z = y.detach()          # gráfél elvágva
L = z**2                # L = 100
assert not L.requires_grad
try:
    L.backward()
except RuntimeError:
    print("detach: nincs visszaterjeszthető gráf")
else:
    raise AssertionError("A backwardnak detached loss esetén hibáznia kell")
print("detach után x.grad:", x.grad)   # None

# 2. eset: ugyanaz a számítás detach nélkül
x2 = torch.tensor(2.0, dtype=dtype, device=device, requires_grad=True)
y2 = x2**2 + 3*x2       # y2 = 10
L2 = y2**2
L2.backward()
print("detach nélkül x2.grad:", x2.grad)  # tensor(140., dtype=torch.float64)
