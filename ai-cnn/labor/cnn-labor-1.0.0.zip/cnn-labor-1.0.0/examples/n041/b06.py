# lab/n041/check_autograd.py
import numpy as np
import torch

torch.manual_seed(20261020)
np.random.seed(20261020)
dtype = torch.float64
device = torch.device("cpu")

def numpy_mlp_grad(X, W1, b1, W2, b2, Y):
    """NumPy-MLP gradiens, tanh aktiváció, MSE loss, átlagolással."""
    Z1 = X @ W1.T + b1
    A1 = np.tanh(Z1)
    Z2 = A1 @ W2.T + b2
    diff = Z2 - Y
    N = X.shape[0]
    gZ2 = 2.0 * diff / diff.size   # MSE (mean az összes elemre): 2*diff/(N*k)
    gW2 = gZ2.T @ A1
    gb2 = gZ2.sum(axis=0)
    gA1 = gZ2 @ W2
    gZ1 = gA1 * (1.0 - A1**2)
    gW1 = gZ1.T @ X
    gb1 = gZ1.sum(axis=0)
    return gW1, gb1, gW2, gb2

N, d, h, k = 4, 3, 4, 2
X_np = np.random.randn(N, d)
Y_np = np.random.randn(N, k)
W1_np = np.random.randn(h, d)
b1_np = np.random.randn(h)
W2_np = np.random.randn(k, h)
b2_np = np.random.randn(k)

ref = numpy_mlp_grad(X_np, W1_np, b1_np, W2_np, b2_np, Y_np)

X = torch.tensor(X_np, dtype=dtype, device=device, requires_grad=True)
Y = torch.tensor(Y_np, dtype=dtype, device=device)
W1 = torch.tensor(W1_np, dtype=dtype, device=device, requires_grad=True)
b1 = torch.tensor(b1_np, dtype=dtype, device=device, requires_grad=True)
W2 = torch.tensor(W2_np, dtype=dtype, device=device, requires_grad=True)
b2 = torch.tensor(b2_np, dtype=dtype, device=device, requires_grad=True)

# Hibás változat: a detach megszakítja az utat az első réteg felé.
h_lin = X @ W1.t() + b1
h = torch.tanh(h_lin).detach()      # <-- a hiba
logits = h @ W2.t() + b2
loss = ((logits - Y) ** 2).mean()
loss.backward()

print("Hibás: W1.grad =", W1.grad, ", b1.grad =", b1.grad)
print("Hibás: X.grad =", X.grad)
assert W1.grad is None and b1.grad is None and X.grad is None

# Javított változat: a detach elhagyása.
W1.grad = None; b1.grad = None; W2.grad = None; b2.grad = None
h = torch.tanh(X @ W1.t() + b1)
logits = h @ W2.t() + b2
loss = ((logits - Y) ** 2).mean()
loss.backward()

errs = [
    np.max(np.abs(W1.grad.detach().numpy() - ref[0])),
    np.max(np.abs(b1.grad.detach().numpy() - ref[1])),
    np.max(np.abs(W2.grad.detach().numpy() - ref[2])),
    np.max(np.abs(b2.grad.detach().numpy() - ref[3])),
]
print("max_abs_errors:", errs)
assert max(errs) < 1e-12
