# lab/n041/lifetime_counterexample.py
import torch

x = torch.tensor(2.0, dtype=torch.float64, requires_grad=True)
y = x * 2
y.backward()
print("x.grad:", x.grad)   # tensor(2., dtype=torch.float64)
try:
    y.backward()
except RuntimeError as e:
    print("második backward:", e)
    # Az üzenet első mondata: Trying to backward through the graph a
    # second time (or directly access saved tensors after they have
    # already been freed). …
