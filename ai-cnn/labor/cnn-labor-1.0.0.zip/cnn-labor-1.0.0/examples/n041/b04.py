# lab/n041/accumulation_demo.py
import torch

x = torch.tensor(3.0, dtype=torch.float64, requires_grad=True)
for _ in range(2):
    (x**2).backward()
print("két backward után x.grad:", x.grad)   # tensor(12., dtype=torch.float64), nem 6.0
