# lab/n041/split_path.py
import torch

torch.manual_seed(20261020)

def split_path(x, detach_middle):
    a = x ** 2
    if detach_middle:
        a = a.detach()
    L = 2.0 * a
    # A detach-ágon nincs autograd-gráf; ott a backward kivételt okozna.
    if L.requires_grad:
        L.backward()
    return L.item(), x.grad

x1 = torch.tensor(2.0, dtype=torch.float64, requires_grad=True)
print("detach nélkül:", split_path(x1, False))
# (8.0, tensor(8., dtype=torch.float64))

x2 = torch.tensor(2.0, dtype=torch.float64, requires_grad=True)
print("detach-tal:", split_path(x2, True))        # (8.0, None)

assert x2.grad is None
