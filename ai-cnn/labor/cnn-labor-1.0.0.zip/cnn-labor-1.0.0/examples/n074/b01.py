# lab/n074/inverted_residual_demo.py
import torch
import torch.nn as nn

class InvertedResidual(nn.Module):
    """Oktatási célú inverted residual, lineáris bottleneck-tel.

    F(X) = BN_p(Project(Act(BN_d(DW(Act(BN_e(Expand(X))))))))
    Y    = F(X) + X, ha stride == 1 es cin == cout.
    A [P09] ReLU6-ja helyett itt nn.ReLU fut (oktatási egyszerűsítés).
    """

    def __init__(self, cin, cout, expand=3, stride=1, activation=nn.ReLU):
        super().__init__()
        self.use_skip = (stride == 1) and (cin == cout)
        hidden = expand * cin
        self.conv = nn.Sequential(
            nn.Conv2d(cin, hidden, 1, bias=False),   # expanzió
            nn.BatchNorm2d(hidden),
            activation(),
            nn.Conv2d(hidden, hidden, 3, stride=stride,
                      padding=1, groups=hidden, bias=False),  # depthwise
            nn.BatchNorm2d(hidden),
            activation(),
            nn.Conv2d(hidden, cout, 1, bias=False),  # projekció, utána NINCS aktiváció
            nn.BatchNorm2d(cout),
        )

    def forward(self, x):
        y = self.conv(x)
        if self.use_skip:
            return y + x
        return y


def conv_params(module):
    """Csak a Conv2d súlyparaméterek száma, a BatchNorm affin paraméterei nélkül."""
    total = 0
    for m in module.modules():
        if isinstance(m, nn.Conv2d):
            total += sum(p.numel() for p in m.parameters())
    return total


def main():
    torch.manual_seed(20261020)
    x1 = torch.randn(1, 4, 8, 8, dtype=torch.float32)
    x2 = torch.randn(1, 4, 8, 8, dtype=torch.float32)

    m1 = InvertedResidual(4, 4, expand=3, stride=1)
    m2 = InvertedResidual(4, 4, expand=3, stride=2)

    y1, y2 = m1(x1), m2(x2)
    # A lemmából számított alakok; a futás assert-tel ellenőrzi.
    assert y1.shape == torch.Size([1, 4, 8, 8])
    assert y2.shape == torch.Size([1, 4, 4, 4])
    assert m1.use_skip is True
    assert m2.use_skip is False
    # Konvolúciós súlyok: 3*4*(4+9+4)=204; teljes modell ennél több a BN miatt.
    assert conv_params(m1) == 204
    print("y1 shape:", tuple(y1.shape))
    print("y2 shape:", tuple(y2.shape))
    print("conv params m1:", conv_params(m1))
    print("total params m1:", sum(p.numel() for p in m1.parameters()))

if __name__ == "__main__":
    main()
