# A) hibás skip: a stride-ot figyelmen kívül hagyja
self.use_skip = True
# B) hibás bottleneck: a projekció után is aktiváció fut
nn.ReLU(),
nn.Conv2d(hidden, cout, 1, bias=False),
nn.ReLU(),
