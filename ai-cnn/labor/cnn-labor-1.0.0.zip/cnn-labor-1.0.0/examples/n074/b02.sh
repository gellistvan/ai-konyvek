cd lab/n074
python inverted_residual_demo.py
