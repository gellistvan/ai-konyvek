# lab/n074/f3_extended.py
# Futtatás a lab/n074 könyvtárból: python f3_extended.py
import torch
from inverted_residual_demo import InvertedResidual, conv_params


def main():
    torch.manual_seed(20261020)
    x = torch.randn(2, 8, 16, 16, dtype=torch.float32)
    model = InvertedResidual(8, 8, expand=2, stride=2)
    y = model(x)
    assert y.shape == torch.Size([2, 8, 8, 8])
    assert model.use_skip is False
    assert conv_params(model) == 400
    print("F3 OK:", tuple(y.shape), conv_params(model))


if __name__ == "__main__":
    main()
