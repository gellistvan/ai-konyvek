# lab/n005/lab_batch_mean.py
"""Kézi és NumPy batch-átlag, valamint a (n,)+(n,1) hiba javítása."""
import numpy as np

X = np.array([[1.0, 0.0, 2.0],
              [0.0, 2.0, 1.0],
              [2.0, 1.0, 0.0],
              [1.0, 1.0, 2.0]], dtype=np.float32)

# Kézi átlag oszloponként: shape (3,)
manual_mean = np.array([X[:, j].mean() for j in range(X.shape[1])],
                       dtype=np.float32)
np_mean = X.mean(axis=0)
print("X shape:", X.shape)
print("manual_mean:", manual_mean)
print("np_mean:", np_mean)

# Ellenőrzés: az alakok és a két átlag egyezése
assert X.shape == (4, 3), X.shape
assert np_mean.shape == (3,), np_mean.shape
np.testing.assert_allclose(manual_mean, np_mean, rtol=1e-6, atol=1e-6)
expected_mean = np.array([1.0, 1.0, 1.25], dtype=np.float32)
np.testing.assert_allclose(np_mean, expected_mean, rtol=1e-6, atol=1e-6)

# Hiba: (3,) és (3,1) összeadása (3,3) mátrixot ad
x = np.array([1.0, 2.0, 3.0], dtype=np.float32)      # (3,)
y = np.array([[10.0], [20.0], [30.0]], dtype=np.float32)  # (3,1)
bad = x + y          # (3,3) -- csendes, de rossz művelet
good = x + y[:, 0]   # (3,)  -- explicit 1D vektor
print("bad shape:", bad.shape)
print("good shape:", good.shape, good)

# Ellenőrzés: a rossz alak (3,3), a jó (3,), és az értékek stimmelnek
assert bad.shape == (3, 3), bad.shape
assert good.shape == (3,), good.shape
np.testing.assert_allclose(bad, np.array([[11, 12, 13],
                                          [21, 22, 23],
                                          [31, 32, 33]], dtype=np.float32))
np.testing.assert_allclose(good, np.array([11.0, 22.0, 33.0],
                                          dtype=np.float32))
print("OK")
