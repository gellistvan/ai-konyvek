x = np.arange(6, dtype=np.float32).reshape(2, 3)
row = x[0]      # view
row[0] = -1.0   # x[0,0] is megváltozik
