cd lab
uv sync
uv run python n005/lab_batch_mean.py
