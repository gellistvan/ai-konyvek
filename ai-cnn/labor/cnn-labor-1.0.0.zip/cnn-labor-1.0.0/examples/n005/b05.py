import numpy as np

def batch_and_channel_mean(x: np.ndarray):
    assert x.ndim == 4, f"Várt shape (N,C,H,W), kapott: {x.shape}"
    batch_mean = x.mean(axis=0)            # (C,H,W)
    channel_mean = x.mean(axis=(0, 2, 3))  # (C,)
    return batch_mean.astype(np.float32), channel_mean.astype(np.float32)

X = np.arange(12, dtype=np.float32).reshape(2, 1, 2, 3)
batch, channel = batch_and_channel_mean(X)
expected_batch = np.array([[[3, 4, 5], [6, 7, 8]]], dtype=np.float32)
expected_channel = np.array([5.5], dtype=np.float32)
np.testing.assert_allclose(batch, expected_batch, rtol=1e-6, atol=1e-6)
np.testing.assert_allclose(channel, expected_channel, rtol=1e-6, atol=1e-6)
print("OK", batch.shape, channel.shape)  # OK (1, 2, 3) (1,)
