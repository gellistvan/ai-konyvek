def add_bias(X, b):
    return X + b   # X.shape == (4,3), b.shape == (3,1)
