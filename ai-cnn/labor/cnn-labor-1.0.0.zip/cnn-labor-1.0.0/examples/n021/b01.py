# n021_gd_demo.py
# Az alábbi kimenet a kód futtatásával kapott mért érték.
import numpy as np

x = np.array(3.0, dtype=np.float64)       # bemeneti skalár
y = np.array(9.0, dtype=np.float64)       # cél
lam = 0.2                                 # regularizációs erősség
eta = 0.05                                # step size

def objective(w):
    z = w * x
    return 0.5 * (z - y) ** 2 + 0.5 * lam * w ** 2   # fél-MSE + lambda/2 w^2

def gradient(w):
    z = w * x
    return (z - y) * x + lam * w                     # (3w-9)*3 + 0.2w

def step(w):
    return w - eta * gradient(w)

w = np.array(0.0, dtype=np.float64)
for t in range(6):
    g = gradient(w)
    print(f"t={t}  w={w:.8f}  F={objective(w):.8f}  grad={g:.8f}")
    w = step(w)

# Ellenőrzés: az első három frissítés egyezzen a kézi lépésekkel
w_repro = np.array(0.0, dtype=np.float64)
for expected in (1.35, 2.079, 2.47266):
    w_repro = step(w_repro)
    np.testing.assert_allclose(w_repro, expected, rtol=0.0, atol=5e-6)
print("ellenorzes: az elso harom lepes a kezi szamitassal egyezik (atol=5e-6)")
