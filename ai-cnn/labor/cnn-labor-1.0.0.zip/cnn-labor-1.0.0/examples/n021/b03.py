def buggy_grad(W, X, Y):
    Z = X @ W.T        # (M, m); W: (m, d)
    R = Z - Y          # (M, m)
    return R.T @ X     # (m, d), de hiányzik az 1/M átlagolás
