def fixed_grad(W, X, Y):
    M = X.shape[0]
    Z = X @ W.T
    R = Z - Y
    return (R.T @ X) / M      # (m, d), batch-átlag
