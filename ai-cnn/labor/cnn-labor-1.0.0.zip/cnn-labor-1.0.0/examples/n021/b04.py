# f3_gd.py
import numpy as np

def gd_first_three(x=3.0, y=9.0, lam=0.2, eta=0.05):
    # A cél 0.5*(w*x-y)**2 + 0.5*lam*w**2; a lépéshez csak a gradiens kell.

    def grad(w):
        return (w * x - y) * x + lam * w

    w = 0.0
    out = []
    for _ in range(3):
        w = w - eta * grad(w)
        out.append(w)
    return np.array(out, dtype=np.float64)

if __name__ == "__main__":
    res = gd_first_three()
    print(res)
    np.testing.assert_allclose(res, [1.35, 2.079, 2.47266],
                               rtol=0.0, atol=5e-6)
    print("ok")
