"""lab/n030_bound.py — Véges H egyenletes korlátjának numerikus számítása.

A számítás determinisztikus, ezért nincs seed, tensor dtype vagy device.
Futtatás: python lab/n030_bound.py
"""
import math
from numbers import Integral

def uniform_bound(M: int, n: int, delta: float) -> tuple[float, float]:
    """Adott M, n, delta mellett visszaadja (epsilon, bound).

    bound = 2*M*exp(-2*n*epsilon**2); a main a zárt képletű epszilont
    egy független biszekciós megoldással ellenőrzi.
    """
    if not (isinstance(M, Integral) and isinstance(n, Integral)):
        raise TypeError("M és n egész típusú legyen")
    if M <= 0 or n <= 0:
        raise ValueError("M és n pozitív egész")
    if not 0.0 < delta < 1.0:
        raise ValueError("delta a nyílt (0,1) intervallumba esik")
    eps = math.sqrt(math.log((2.0 * M) / delta) / (2.0 * n))
    bound = 2.0 * M * math.exp(-2.0 * n * eps * eps)
    return eps, bound

def bound_at(M: int, n: int, eps: float) -> float:
    """A (2) korlát értéke adott epszilon mellett."""
    return 2.0 * M * math.exp(-2.0 * n * eps * eps)

def solve_epsilon(M: int, n: int, delta: float) -> float:
    """Független biszekció: megoldja a bound_at(eps) = delta egyenletet."""
    lo, hi = 0.0, 1.0
    while bound_at(M, n, hi) > delta:
        hi *= 2.0
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if bound_at(M, n, mid) > delta:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)

def main() -> None:
    delta = 0.05
    tolerance = 1e-12  # relatív tolerancia a zárt képlet és a biszekció összevetéséhez
    print(f"delta = {delta}")
    for M in (10, 1000, 1_000_000):
        print(f"M = {M}")
        for n in (100, 500, 1000, 5000, 10_000):
            eps, bound = uniform_bound(M, n, delta)
            eps_ref = solve_epsilon(M, n, delta)
            ok = abs(eps - eps_ref) <= tolerance * max(1.0, eps_ref)
            assert eps > 0.0
            assert abs(bound - delta) <= tolerance * max(1.0, delta)
            assert ok
            print(f"  n={n:6d}  epsilon={eps:.6f}  bound={bound:.6e}  "
                  f"ellenőrzés={ok}")

if __name__ == "__main__":
    main()
