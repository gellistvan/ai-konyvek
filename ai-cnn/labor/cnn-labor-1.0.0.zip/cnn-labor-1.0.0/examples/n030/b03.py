import math
from numbers import Integral

def epsilon_bound(M, n, delta):
    if not (isinstance(M, Integral) and isinstance(n, Integral)):
        raise TypeError("M és n egész típusú legyen")
    if M <= 0 or n <= 0:
        raise ValueError("M és n pozitív egész")
    if not 0.0 < delta < 1.0:
        raise ValueError("delta a nyílt (0,1) intervallumba esik")
    eps = math.sqrt(math.log((2.0 * M) / delta) / (2.0 * n))
    bound = 2.0 * M * math.exp(-2.0 * n * eps * eps)
    return eps, bound

eps, bound = epsilon_bound(1000, 500, 0.05)
print(eps, bound)
# 0.1029399569316797 0.05000000000000004
assert abs(bound - 0.05) <= 1e-12 * max(1.0, 0.05)
try:
    epsilon_bound(1000.0, 500, 0.05)
except TypeError as exc:
    print(type(exc).__name__, exc)
# TypeError M és n egész típusú legyen
