def rossz_epsilon(M: int, n: int, delta: float) -> float:
    import math
    return math.sqrt(math.log(M / delta) / (2 * n))
