import numpy as np

rng = np.random.default_rng(20261020)
M, n, R = 100, 200, 5000
p = np.arange(1, M + 1) / (M + 1)
eps = np.sqrt(np.log(2 * M / 0.05) / (2 * n))
exceed = 0
for _ in range(R):
    losses = rng.random((M, n)) < p[:, None]
    p_hat = losses.mean(axis=1)
    T = np.max(np.abs(p_hat - p))
    exceed += T >= eps
p_exceed = exceed / R
se = np.sqrt(p_exceed * (1 - p_exceed) / R)
print(f"{eps:.6f} {p_exceed:.4f} {se:.6f}")
