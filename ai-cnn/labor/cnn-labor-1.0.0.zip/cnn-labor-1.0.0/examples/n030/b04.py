def helyes_epsilon(M: int, n: int, delta: float) -> float:
    import math
    return math.sqrt(math.log((2.0 * M) / delta) / (2.0 * n))
