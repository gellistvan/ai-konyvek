import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim

SEED = 20261020
DEVICE = torch.device("cpu")

images = np.load("data/images.npy")      # (360,1,24,24) float32
labels = np.load("data/labels.npy")      # (360,) int64
meta = pd.read_csv("data/metadata.csv")

# A meta sorrendjére nem támaszkodunk: a saját index oszlopa adja a tömbindexet.
if "index" not in meta.columns:
    raise ValueError("a metadata.csv-ből hiányzik az index oszlop")
if not (len(meta) == len(images) == len(labels)):
    raise ValueError("a metadata.csv és a tömbök hossza eltér")
if not np.array_equal(np.sort(meta["index"].to_numpy()), np.arange(len(images))):
    raise ValueError("a metadata.csv index oszlopa nem permutációja a tömbindexeknek")
train_idx = meta.loc[meta["split"] == "train", "index"].to_numpy()
val_idx   = meta.loc[meta["split"] == "val", "index"].to_numpy()
assert (len(train_idx), len(val_idx)) == (240, 60)

K = 3

def symmetric_label_noise(y, K, eps, rng):
    noisy = y.copy()
    flips = rng.random(len(y)) < eps
    for i in np.where(flips)[0]:
        others = np.setdiff1d(np.arange(K), y[i])
        noisy[i] = rng.choice(others)
    return noisy

class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(1, 8, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(8, 16, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Flatten(), nn.Linear(16*6*6, 32), nn.ReLU(),
            nn.Linear(32, K)
        )
    def forward(self, x):
        return self.net(x)

def run(eps):
    # Minden futás azonos inicializálást és shuffle-sorrendet kap.
    torch.manual_seed(SEED)
    # Azonos seeddel a flip-maszkok egymásba ágyazottak: eps=0,1 flipjei
    # részhalmazai az eps=0,2 flipjeinek, és a futás önmagában is reprodukálható.
    noise_rng = np.random.default_rng(SEED)
    y_train = symmetric_label_noise(labels[train_idx], K, eps, noise_rng)
    if eps == 0.0:
        assert np.array_equal(y_train, labels[train_idx])
    else:
        assert not np.array_equal(y_train, labels[train_idx])
    Xtr = torch.tensor(images[train_idx], dtype=torch.float32)
    ytr = torch.tensor(y_train, dtype=torch.long)
    Xva = torch.tensor(images[val_idx], dtype=torch.float32)
    yva = torch.tensor(labels[val_idx], dtype=torch.long)
    assert np.array_equal(yva.numpy(), labels[val_idx])   # a validáció tiszta marad
    model = SmallCNN().to(DEVICE)
    opt = optim.Adam(model.parameters(), lr=1e-3)
    crit = nn.CrossEntropyLoss()
    ds = torch.utils.data.TensorDataset(Xtr, ytr)
    dl = torch.utils.data.DataLoader(ds, batch_size=32, shuffle=True)
    for _ in range(20):
        model.train()
        for xb, yb in dl:
            opt.zero_grad(); crit(model(xb), yb).backward(); opt.step()
    model.eval()
    with torch.no_grad():
        logits = model(Xva)
        val_loss = crit(logits, yva).item()
        val_acc = (logits.argmax(1) == yva).float().mean().item()
    return val_loss, val_acc

print("eps   val_loss_clean  val_acc_clean")
for eps in [0.0, 0.1, 0.2, 0.4]:
    loss, acc = run(eps)
    print(f"{eps:3.1f}  {loss:9.4f}       {acc:6.4f}")
