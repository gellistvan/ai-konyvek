import numpy as np

def symmetric_label_noise(labels, K, eps, rng):
    """labels: (N,) int; minden címkét eps eséllyel egyenletesen
    kicserél a többi K-1 osztály valamelyikére."""
    noisy = labels.copy()
    flips = rng.random(len(labels)) < eps
    for i in np.where(flips)[0]:
        others = [j for j in range(K) if j != labels[i]]
        noisy[i] = rng.choice(others)
    return noisy

rng = np.random.default_rng(7)
y = np.array([0, 1, 2, 0, 1, 2, 0, 1, 2, 0])
y_t = symmetric_label_noise(y, 3, 0.2, rng)
print("clean:", y)
print("noisy:", y_t)
print("flip rate:", np.mean(y != y_t))
