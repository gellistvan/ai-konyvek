def misleading_standardize(x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Visszaadja a standardizált mátrixot és a mintabeli szórást."""
    mu = x.mean(axis=0)
    sd = x.std(axis=0)          # hibagyanús sor
    denom = np.where(sd > 1e-12, sd, 1.0)
    y = (x - mu) / denom
    return y, sd
