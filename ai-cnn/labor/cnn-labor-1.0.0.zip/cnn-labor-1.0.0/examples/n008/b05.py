"""Az n008 labor szerződését rögzítő unit tesztek."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from glyphstats.normalize import normalize_columns


@pytest.fixture()
def input_array() -> np.ndarray:
    path = Path(__file__).resolve().parent.parent / "data" / "input.npy"
    return np.load(path, allow_pickle=False)


def test_output_shape_matches_input(input_array: np.ndarray) -> None:
    y = normalize_columns(input_array)
    assert y.shape == input_array.shape
    assert y.dtype == np.float64


def test_normalized_columns_are_standardized(input_array: np.ndarray) -> None:
    y = normalize_columns(input_array)
    expected_std = np.array([1.0, 1.0, 0.0])
    np.testing.assert_allclose(y.mean(axis=0), np.zeros(3), atol=1e-12)
    np.testing.assert_allclose(y.std(axis=0), expected_std, atol=1e-12)


def test_zero_variance_columns_are_zero(input_array: np.ndarray) -> None:
    y = normalize_columns(input_array)
    np.testing.assert_array_equal(y[:, 2], np.zeros(input_array.shape[0]))


def test_eps_threshold_is_scale_dependent() -> None:
    x = np.array([[0.0], [1e-13], [2e-13]])
    np.testing.assert_array_equal(normalize_columns(x), np.zeros((3, 1)))   # eps=1e-12
    np.testing.assert_allclose(normalize_columns(x, eps=0.0).ravel(),
                               [-np.sqrt(1.5), 0.0, np.sqrt(1.5)], rtol=1e-9, atol=1e-12)
    with pytest.raises(ValueError):
        normalize_columns(x, eps=-1.0)


def test_rejects_non_matrix(input_array: np.ndarray) -> None:
    with pytest.raises(ValueError):
        normalize_columns(input_array[:, 0])
