uv sync
uv run python tools/make_fixture.py
uv run pytest -q
uv run python -m glyphstats.cli \
  --input data/input.npy \
  --output runs/output.npy \
  --manifest manifests/manifest.json
