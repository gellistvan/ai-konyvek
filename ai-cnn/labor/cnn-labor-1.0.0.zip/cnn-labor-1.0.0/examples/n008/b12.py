def misleading_standardize(x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Visszaadja a standardizált mátrixot és a mintabeli szórást."""
    mu = x.mean(axis=0)
    sd_pop = x.std(axis=0)             # standardizáló nevező: populációs
    sd_sample = x.std(axis=0, ddof=1)  # dokumentált jelentett minta-szórás
    denom = np.where(sd_pop > 1e-12, sd_pop, 1.0)
    y = (x - mu) / denom
    return y, sd_sample
