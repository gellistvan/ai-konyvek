"""Az n008 tesztfixture generátora: seedelt, ismételhető."""
from __future__ import annotations

from pathlib import Path

import numpy as np


def main() -> None:
    out_dir = Path(__file__).resolve().parent.parent / "data"
    out_dir.mkdir(exist_ok=True)
    rng = np.random.default_rng(20261020)
    x = rng.normal(loc=2.0, scale=4.0, size=(10, 3))
    x[:, 2] = 5.0  # konstans oszlop a degenerált esethez
    np.save(out_dir / "input.npy", x.astype(np.float64))


if __name__ == "__main__":
    main()
