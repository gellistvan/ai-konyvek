def test_misleading_standardize_separates_sample_sd() -> None:
    x = np.array([[0.0], [4.0]])
    y, sd = misleading_standardize(x)
    np.testing.assert_allclose(sd, [2.0 * np.sqrt(2.0)], atol=1e-12)
    np.testing.assert_allclose(y.ravel(), [-1.0, 1.0], atol=1e-12)
