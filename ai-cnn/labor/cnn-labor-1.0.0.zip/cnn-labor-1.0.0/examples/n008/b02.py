"""Oszloponkénti standardizálás az n008 laborhoz."""
from __future__ import annotations

import numpy as np


def normalize_columns(x: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    """Standardizálja az (N, d) mátrix oszlopait, eps-küszöbbel.

    A szórás konvenció: populációs, 1/N normalizálással.
    Ha egy oszlop szórása <= eps, a kimenet 0 (eps=0: csak a konstans oszlop).
    """
    if x.ndim != 2:
        raise ValueError("x.shape-nak (N, d) kétdimenziósnak kell lennie")
    if not (np.isfinite(eps) and eps >= 0):
        raise ValueError("eps-nek véges, nemnegatív számnak kell lennie")
    centered = x - x.mean(axis=0, keepdims=True)
    var = np.mean(centered * centered, axis=0, keepdims=True)
    sd = np.sqrt(var)
    denom = np.where(sd > eps, sd, 1.0)
    out = centered / denom
    out = np.where(sd > eps, out, 0.0)
    return np.ascontiguousarray(out)
