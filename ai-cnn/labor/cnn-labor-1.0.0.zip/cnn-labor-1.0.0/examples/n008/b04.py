"""Parancssori belépőpont és futási jegyzék."""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from .normalize import normalize_columns


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="GlyphStats normalizáló CLI")
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, default=None)
    parser.add_argument("--eps", type=float, default=1e-12)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    input_path = args.input.expanduser().resolve()
    output_path = args.output.expanduser().resolve()
    # A np.save kiterjesztés nélküli névhez .npy-t fűzne; a manifestnek
    # a ténylegesen létrejött fájlra kell mutatnia.
    if output_path.suffix != ".npy":
        output_path = output_path.with_suffix(".npy")
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Csak saját fixture-t töltünk; allow_pickle=False biztonsági okból.
    loaded = np.load(input_path, allow_pickle=False)
    input_dtype = str(loaded.dtype)
    x = loaded.astype(np.float64, copy=False)
    y = normalize_columns(x, eps=args.eps)
    np.save(output_path, y)

    if args.manifest is not None:
        record = {
            "run_id": uuid.uuid4().hex,
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "input_file": input_path.name,
            "input_sha256": sha256_file(input_path),
            "output_file": output_path.name,
            "output_sha256": sha256_file(output_path),
            "params": {"eps": args.eps, "input_dtype": input_dtype},
            "python": sys.version.split()[0],
            "numpy": np.__version__,
            "machine": platform.platform(),
            "normalization": "population_std",
        }
        manifest_path = args.manifest.expanduser().resolve()
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(json.dumps(record, indent=2), encoding="utf-8")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
