# Kiinduló notebook-cella: betöltés, számítás és kiírás egy cellában
import numpy as np

X = np.load("data/input.npy")
mu = X.mean(axis=0, keepdims=True)
sd = X.std(axis=0, keepdims=True)
Y = (X - mu) / np.where(sd > 1e-12, sd, 1.0)
Y = np.where(sd > 1e-12, Y, 0.0)
print(Y.shape, Y.mean(axis=0), Y.std(axis=0))
