# lab/n064_checkpoint.py -- futtatás: python lab/n064_checkpoint.py
import numpy as np
import torch

def cc_forward(X, K, b, stride=1, pad=0, dilation=1):
    """Referencia: cross-correlation, NCHW, groups=1, zero pad, float64."""
    N, C, H, W = X.shape
    O, Ck, kh, kw = K.shape
    assert C == Ck
    eff_h = dilation * (kh - 1) + 1
    eff_w = dilation * (kw - 1) + 1
    H_out = (H + 2 * pad - eff_h) // stride + 1
    W_out = (W + 2 * pad - eff_w) // stride + 1
    Xp = np.pad(X, ((0, 0), (0, 0), (pad, pad), (pad, pad)), mode="constant")
    Y = np.empty((N, O, H_out, W_out), dtype=np.float64)
    for n in range(N):
        for o in range(O):
            for i in range(H_out):
                for j in range(W_out):
                    total = b[o]
                    for c in range(C):
                        for u in range(kh):
                            for v in range(kw):
                                total += Xp[n, c, i * stride + u * dilation,
                                            j * stride + v * dilation] * K[o, c, u, v]
                    Y[n, o, i, j] = total
    return Y, Xp

def cc_backward_L2(Y, Xp, K, stride=1, dilation=1):
    """Backward a L = 0.5 * sum(Y**2) célra; upstream gradiens g = Y.

    A visszatérési dXp a *paddinges* bemenetre vonatkozó gradiens; a p keret
    levágása a hívó feladata. p=0 esetén dXp közvetlenül dX.
    """
    N, O, H_out, W_out = Y.shape
    Nc, C, Hp, Wp = Xp.shape          # Xp mérete megadja a paddinget is
    kh, kw = K.shape[2], K.shape[3]
    dK = np.zeros_like(K, dtype=np.float64)
    dXp = np.zeros_like(Xp, dtype=np.float64)
    db = np.zeros(O, dtype=np.float64)
    for n in range(N):
        for o in range(O):
            for i in range(H_out):
                for j in range(W_out):
                    g = Y[n, o, i, j]
                    db[o] += g
                    for c in range(C):
                        for u in range(kh):
                            for v in range(kw):
                                a = i * stride + u * dilation
                                b_idx = j * stride + v * dilation
                                dK[o, c, u, v] += g * Xp[n, c, a, b_idx]
                                dXp[n, c, a, b_idx] += g * K[o, c, u, v]
    return dK, db, dXp

# Kézi példa
X = np.arange(1, 17, dtype=np.float64).reshape(1, 1, 4, 4)
K = np.array([[[[1.0, 2.0], [3.0, 4.0]]]])
b = np.zeros((1,), dtype=np.float64)
Y_manual = np.array([[[[44.0, 54.0, 64.0],
                       [84.0, 94.0, 104.0],
                       [124.0, 134.0, 144.0]]]], dtype=np.float64)

Y_ref, Xp = cc_forward(X, K, b, stride=1, pad=0)
np.testing.assert_allclose(Y_ref, Y_manual, atol=1e-12)
dK, db, dXp = cc_backward_L2(Y_ref, Xp, K)
dK_manual = np.array([[[[6096.0, 6942.0], [9480.0, 10326.0]]]])
np.testing.assert_allclose(dK, dK_manual, atol=1e-10)
np.testing.assert_allclose(dXp[:, :, 1, 1], 600.0, atol=1e-10)
np.testing.assert_allclose(dXp[:, :, 0, 0], 44.0, atol=1e-10)

# PyTorch autograd-kontroll
Xt = torch.tensor(X, dtype=torch.float64, device="cpu", requires_grad=True)
Kt = torch.tensor(K, dtype=torch.float64, device="cpu", requires_grad=True)
bt = torch.tensor(b, dtype=torch.float64, device="cpu", requires_grad=True)
Yt = torch.nn.functional.conv2d(Xt, Kt, bt, stride=1, padding=0)
Lt = 0.5 * torch.sum(Yt ** 2)
Lt.backward()
np.testing.assert_allclose(Yt.detach().numpy(), Y_manual, atol=1e-12)
np.testing.assert_allclose(Kt.grad.numpy(), dK_manual, atol=1e-12)
np.testing.assert_allclose(dXp, Xt.grad.numpy(), atol=1e-12)  # paddinges input, itt nincs keret
np.testing.assert_allclose(bt.grad.numpy(), np.array([Y_ref.sum()]), atol=1e-12)
print("forward/backward: OK (f64, tűrés 1e-12)")

# Határkezelési kísérlet: 2x2-es identitás kernel, stride=1, pad=0
def shift_zero_2d(arr, dh, dw):
    out = np.zeros_like(arr)
    h, w = arr.shape[2], arr.shape[3]
    src_h0, src_h1 = max(0, -dh), min(h, h - dh)
    dst_h0, dst_h1 = max(0, dh), min(h, h + dh)
    src_w0, src_w1 = max(0, -dw), min(w, w - dw)
    dst_w0, dst_w1 = max(0, dw), min(w, w + dw)
    out[:, :, dst_h0:dst_h1, dst_w0:dst_w1] = arr[:, :, src_h0:src_h1, src_w0:src_w1]
    return out

Xb = np.arange(1, 10, dtype=np.float64).reshape(1, 1, 3, 3)
Kb = np.array([[[[1.0, 0.0], [0.0, 1.0]]]])
Yb, _ = cc_forward(Xb, Kb, np.zeros(1), stride=1, pad=0)
print("shift_err (Frobenius-norma, 3x3/2x2):")
for dh in range(-1, 2):
    row = []
    for dw in range(-1, 2):
        Xs = shift_zero_2d(Xb, dh, dw)
        Ys, _ = cc_forward(Xs, Kb, np.zeros(1), stride=1, pad=0)
        Ysh = shift_zero_2d(Yb, dh, dw)
        row.append(f"{np.linalg.norm(Ys - Ysh):.2f}")
    print(("dh=%+d: " % dh) + " ".join(row))

# 5) stride-2 határkísérlet: 6x6 bemenet, 3x3 kernel, p=0
X6 = np.arange(1, 37, dtype=np.float64).reshape(1, 1, 6, 6)
K6 = np.array([[[[1.0, 0.0, 2.0],
                 [0.0, 1.0, 0.0],
                 [2.0, 0.0, 1.0]]]])
Y6, _ = cc_forward(X6, K6, np.zeros(1), stride=2, pad=0)
X6_even = shift_zero_2d(X6, 2, 0)
Y6_even, _ = cc_forward(X6_even, K6, np.zeros(1), stride=2, pad=0)
Y6_even_ref = shift_zero_2d(Y6, 1, 0)
diff_even = np.abs(Y6_even - Y6_even_ref)
print("stride 2, páros eltolás (2,0): belső max |diff| =", diff_even[0, 0, 1:, :].max())
assert diff_even[0, 0, 1:, :].max() < 1e-12
assert diff_even.max() > 0.0

X6_odd = shift_zero_2d(X6, 1, 0)
Y6_odd, _ = cc_forward(X6_odd, K6, np.zeros(1), stride=2, pad=0)
odd_diffs = []
for mh in (-1, 0, 1):
    odd_diffs.append(float(np.abs(Y6_odd - shift_zero_2d(Y6, mh, 0)).max()))
print("stride 2, páratlan eltolás (1,0): |diff| m=-1,0,1:", odd_diffs)
assert all(d > 0.0 for d in odd_diffs)
