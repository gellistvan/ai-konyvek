dXp[:, :, i*s+u*d, j*s+v*d] += dY[:, :, i, j] * K[:, :, u, v]
