# szándékosan hibás vázlat: a dXp scatter–add ág
K_rev = K[:, :, ::-1, ::-1]   # matematikai index: K_rev[o,c,u,v] = K[o,c,kh-1-u,kw-1-v]
for i in range(H_out):
    for j in range(W_out):
        for u in range(kh):
            for v in range(kw):
                dXp[:, :, i*s+u*d, j*s+v*d] += (
                    dY[:, :, i, j] * K_rev[:, :, u, v])
