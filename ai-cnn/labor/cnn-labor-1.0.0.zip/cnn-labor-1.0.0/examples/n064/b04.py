import numpy as np
import torch
import torch.nn.functional as F

rs = np.random.RandomState(42)
X = rs.randn(1, 1, 5, 5).astype(np.float64)
K = rs.randn(1, 1, 3, 3).astype(np.float64)
b = rs.randn(1).astype(np.float64)

Y, Xp = cc_forward(X, K, b, stride=1, pad=1, dilation=2)
dK, db, dXp = cc_backward_L2(Y, Xp, K, stride=1, dilation=2)
dX = dXp[:, :, 1:-1, 1:-1]          # a p=1 keret levágása

Xt = torch.tensor(X, dtype=torch.float64, requires_grad=True)
Kt = torch.tensor(K, dtype=torch.float64, requires_grad=True)
bt = torch.tensor(b, dtype=torch.float64, requires_grad=True)
Yt = F.conv2d(Xt, Kt, bt, stride=1, padding=1, dilation=2)
Lt = 0.5 * torch.sum(Yt ** 2)
Lt.backward()

errs = {
    "Y": np.abs(Y - Yt.detach().numpy()).max(),
    "dX": np.abs(dX - Xt.grad.numpy()).max(),
    "dK": np.abs(dK - Kt.grad.numpy()).max(),
    "db": np.abs(db - bt.grad.numpy()).max(),
}
assert all(v < 5e-12 for v in errs.values())
print(errs)
