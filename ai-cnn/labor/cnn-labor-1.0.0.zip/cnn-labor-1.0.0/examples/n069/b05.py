"""lab/residual_stride.py"""
import torch
import torch.nn as nn

torch.manual_seed(20261020)
device = torch.device("cpu")
dtype = torch.float32


class StrideResBlock(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 4, 5, stride=2, padding=2)
        self.conv2 = nn.Conv2d(4, 4, 5, padding=2)
        self.shortcut = nn.Conv2d(1, 4, 1, stride=2)
        self.relu = nn.ReLU()

    def forward(self, x):
        h = self.relu(self.conv1(x))
        h = self.conv2(h)
        return h + self.shortcut(x)


def main():
    x = torch.randn(2, 1, 24, 24, device=device, dtype=dtype)
    block = StrideResBlock().to(device, dtype)
    block.eval()
    with torch.no_grad():
        y = block(x)
        h_ref = block.conv2(block.relu(block.conv1(x)))
        short = block.shortcut(x)
        gap = (y - h_ref).abs().max().item()
        err = (y - (h_ref + short)).abs().max().item()
        short_mag = short.abs().max().item()
    print("kimeneti alak:", tuple(y.shape))
    print("max|y-h|:", gap)
    print("max|shortcut|:", short_mag)
    print("max|y-(h+shortcut)|:", err)
    assert gap > 0 and abs(gap - short_mag) < 1e-6
    assert err < 1e-6


if __name__ == "__main__":
    main()
