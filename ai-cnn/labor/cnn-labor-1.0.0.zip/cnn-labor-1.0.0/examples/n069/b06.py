class FixedBlock(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(2, 4, 3, padding=1)
        self.conv2 = nn.Conv2d(4, 4, 3, padding=1)
        self.shortcut = nn.Conv2d(2, 4, 1)
        self.relu = nn.ReLU()

    def forward(self, x):
        h = self.conv2(self.relu(self.conv1(x)))
        return h + self.shortcut(x)
