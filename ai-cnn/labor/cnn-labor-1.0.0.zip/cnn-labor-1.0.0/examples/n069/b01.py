"""lab/residual_block.py"""
import torch
import torch.nn as nn

torch.manual_seed(20261020)
device = torch.device("cpu")
dtype = torch.float32


class BasicResBlock(nn.Module):
    """Azonos csatornaszámú, stride=1 reziduális blokk."""
    def __init__(self, C, kernel=3):
        super().__init__()
        self.conv1 = nn.Conv2d(C, C, kernel, padding=1)
        self.conv2 = nn.Conv2d(C, C, kernel, padding=1)
        self.relu = nn.ReLU()

    def forward(self, x):
        h = self.relu(self.conv1(x))
        h = self.conv2(h)
        return x + h


class ProjectionResBlock(nn.Module):
    """Csatornát váltó blokk 1x1 projekciós shortcuttal."""
    def __init__(self, C_in, C_out, stride=1):
        super().__init__()
        self.conv1 = nn.Conv2d(C_in, C_out, 3, stride=stride, padding=1)
        self.conv2 = nn.Conv2d(C_out, C_out, 3, padding=1)
        self.shortcut = nn.Conv2d(C_in, C_out, 1, stride=stride)
        self.relu = nn.ReLU()

    def forward(self, x):
        h = self.relu(self.conv1(x))
        h = self.conv2(h)
        return h + self.shortcut(x)


def main():
    N, C, H, W = 2, 3, 24, 24
    x = torch.randn(N, C, H, W, device=device, dtype=dtype)

    # Azonos alakú blokk: a kimenet x + F(x), és a skip ténylegesen számít.
    block_same = BasicResBlock(C).to(device, dtype)
    block_same.eval()
    with torch.no_grad():
        y = block_same(x)
        h_ref = block_same.conv2(block_same.relu(block_same.conv1(x)))
        skip_contrib = y - h_ref
        gap = skip_contrib.abs().max().item()          # a skip hozzájárulása
        err_same = (skip_contrib - x).abs().max().item()
        same = torch.allclose(skip_contrib, x, atol=1e-6, rtol=0)
    print("skip hozzajarulasa max|y-h|:", gap)
    print("max|(y-h)-x|:", err_same)
    # A skip nélküli (sima) előremenet kimenete h_ref lenne; a gap > 0 azt
    # mutatja, hogy a blokk valóban hozzáadja az identity ágat. Az err_same
    # és az allclose ugyanazt az y-h = x azonosságot ellenőrzi: az előbbi
    # numerikus értéket ad, az utóbbi assertionként kötelezővé teszi.
    assert gap > 1e-3 and same

    # Csatornát váltó blokk: a shortcut 1x1 konvolúcióval projektál.
    block_proj = ProjectionResBlock(C, 6).to(device, dtype)
    block_proj.eval()
    with torch.no_grad():
        y2 = block_proj(x)
    assert tuple(y2.shape) == (2, 6, 24, 24)
    print("projekcios kimenet alakja:", tuple(y2.shape))
    print("elvart alak: (2, 6, 24, 24)")


if __name__ == "__main__":
    main()
