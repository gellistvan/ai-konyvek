def norm_probe(model, xb, yb):
    loss_fn = torch.nn.CrossEntropyLoss()
    model.train()
    model.zero_grad(set_to_none=True)
    loss_fn(model(xb), yb).backward()

    def norm(modules):
        s = 0.0
        for m in modules:
            for p in m.parameters():
                if p.grad is not None:
                    s += p.grad.detach().pow(2).sum().item()
        return s ** 0.5
    return {
        "stem": norm([model.stem]),
        "first_block": norm([model.blocks[0]]),
        "last_block": norm([model.blocks[-1]]),
        "head": norm([model.head]),
    }

x = torch.randn(2, 1, 24, 24, dtype=torch.float32, device=torch.device("cpu"))
y = torch.tensor([0, 1], dtype=torch.int64)
model = Net(residual=True)
print(norm_probe(model, x, y))
