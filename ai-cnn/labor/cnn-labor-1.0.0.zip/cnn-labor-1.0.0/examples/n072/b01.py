# lab/n072_resablation.py
# Futtatás bárhonnan: python n072_resablation.py --epochs 40 --seeds 0 1 2
# Az adat alapértelmezésben a script melletti data/ könyvtár.
import argparse, json, pathlib
import numpy as np
import torch
import torch.nn as nn

BASE = pathlib.Path(__file__).resolve().parent

def make_block(ch, residual):
    class Block(nn.Module):
        def __init__(self):
            super().__init__()
            self.conv1 = nn.Conv2d(ch, ch, 3, padding=1, bias=False)
            self.bn1 = nn.BatchNorm2d(ch)
            self.conv2 = nn.Conv2d(ch, ch, 3, padding=1, bias=False)
            self.bn2 = nn.BatchNorm2d(ch)
            self.residual = residual
        def forward(self, x):
            h = self.bn1(self.conv1(x)).relu()
            h = self.bn2(self.conv2(h))
            if self.residual:
                h = h + x
            return h.relu()
    return Block()

class Net(nn.Module):
    def __init__(self, blocks=5, ch=16, residual=True, num_classes=3):
        super().__init__()
        self.stem = nn.Conv2d(1, ch, 3, padding=1)
        self.blocks = nn.Sequential(*[make_block(ch, residual) for _ in range(blocks)])
        self.head = nn.Sequential(
            nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(ch, num_classes))
    def forward(self, x):
        return self.head(self.blocks(self.stem(x).relu()))

def grad_norm(modules):
    sq = 0.0
    for m in modules:
        for p in m.parameters():
            if p.grad is not None:
                sq += p.grad.detach().float().pow(2).sum().item()
    return float(np.sqrt(sq))

def evaluate(model, X, y, loss_fn, device):
    model.eval()
    with torch.no_grad():
        logits = model(X.to(device))
        return (loss_fn(logits, y.to(device)).item(),
                (logits.argmax(1) == y.to(device)).float().mean().item())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=pathlib.Path, default=BASE / "data")
    ap.add_argument("--epochs", type=int, default=40)
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    ap.add_argument("--device", default="cpu")
    args = ap.parse_args()

    imgs = np.load(args.data / "images.npy").astype(np.float32)
    labels = np.load(args.data / "labels.npy").astype(np.int64)
    meta = np.genfromtxt(args.data / "metadata.csv", delimiter=",", dtype=None,
                         names=True, encoding="utf-8")
    # A sorrendre nem támaszkodunk: a saját index oszlopa adja a tömbindexet.
    if not (len(meta) == len(imgs) == len(labels)):
        raise ValueError("a metadata.csv és a tömbök hossza eltér")
    idx_all = meta["index"].astype(np.int64)
    if not np.array_equal(np.sort(idx_all), np.arange(len(imgs))):
        raise ValueError("a metadata.csv index oszlopa nem permutációja a tömbindexeknek")
    split = np.asarray(meta["split"]).astype(str)
    train_idx = torch.tensor(idx_all[split == "train"], dtype=torch.long)
    val_idx = torch.tensor(idx_all[split == "val"], dtype=torch.long)
    test_idx = torch.tensor(idx_all[split == "test"], dtype=torch.long)
    X = torch.from_numpy(imgs)
    y = torch.from_numpy(labels)
    Xco = torch.from_numpy(
        np.load(args.data / "corrupted_test.npy").astype(np.float32))
    if len(Xco) != len(test_idx):
        raise ValueError("a corrupt teszt hossza nem egyezik a test splittel")
    # A corrupt teszt a metadata.csv test sorainak sorrendjében van
    # (manifest.json: corrupt_order), ezért a test_idx pozícióihoz párosul.
    device = torch.device(args.device)
    loss_fn = nn.CrossEntropyLoss()
    assert sum(p.numel() for p in Net(residual=False).parameters()) == 23571
    assert sum(p.numel() for p in Net(residual=True).parameters()) == 23571
    report = {}

    for seed in args.seeds:
        for residual in (False, True):
            # A matched recipe és a H1 azonos kezdeti súlyokat kíván: minden
            # modell ugyanabból a seedből indul, ezért az init és a shuffle
            # sorrendje a két ágban azonos.
            torch.manual_seed(seed)
            model = Net(residual=residual).to(device)
            opt = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
            best_val = float("inf")
            best_epoch = -1
            best_state = None
            history = {"first_step": None, "epochs": []}
            act_grad = {}
            def first_block_hook(module, inp, out):
                out.register_hook(
                    lambda g: act_grad.__setitem__(
                        "norm", g.detach().float().norm().item()))
            hook = model.blocks[0].register_forward_hook(first_block_hook)
            for ep in range(args.epochs):
                model.train()
                order = torch.randperm(len(train_idx))
                train_loss_sum = 0.0
                n_batches = 0
                for st in range(0, len(train_idx), 64):
                    idx = order[st:st+64]
                    xb = X[train_idx[idx]].to(device)
                    yb = y[train_idx[idx]].to(device)
                    opt.zero_grad()
                    loss = loss_fn(model(xb), yb)
                    loss.backward()
                    if ep == 0 and st == 0:
                        history["first_step"] = {
                            "step": 0,
                            "stem_norm": grad_norm([model.stem]),
                            "first_block_norm": grad_norm([model.blocks[0]]),
                            "first_block_act_grad_norm": act_grad.get("norm", 0.0),
                            "last_block_norm": grad_norm([model.blocks[-1]]),
                            "head_norm": grad_norm([model.head]),
                        }
                        hook.remove()
                    opt.step()
                    train_loss_sum += loss.item()
                    n_batches += 1
                val_loss, val_acc = evaluate(model, X[val_idx], y[val_idx],
                                             loss_fn, device)
                history["epochs"].append({
                    "epoch": ep, "train_loss": train_loss_sum / n_batches,
                    "val_loss": val_loss, "val_acc": val_acc})
                if val_loss < best_val:
                    best_val = val_loss
                    best_epoch = ep
                    best_state = {k: v.detach().clone()
                                  for k, v in model.state_dict().items()}
            ckpt = args.data.parent / (
                f"n072_seed{seed}_{'residual' if residual else 'plain'}.pt")
            torch.save(best_state, ckpt)
            model.load_state_dict(best_state)
            test_loss, test_acc = evaluate(model, X[test_idx], y[test_idx],
                                           loss_fn, device)
            corrupt_loss, corrupt_acc = evaluate(model, Xco, y[test_idx],
                                                 loss_fn, device)
            report[f"seed{seed}_{'residual' if residual else 'plain'}"] = {
                "param_count": sum(p.numel() for p in model.parameters()),
                "checkpoint": ckpt.name,
                "best_val_loss": best_val,
                "best_epoch": best_epoch,
                "test_loss": test_loss,
                "test_acc": test_acc,
                "corrupt_loss": corrupt_loss,
                "corrupt_acc": corrupt_acc,
                "first_step": history["first_step"],
                "epochs": history["epochs"],
            }
    out = args.data.parent / "n072_report.json"
    out.write_text(json.dumps(report, indent=2))
    print(out)

if __name__ == "__main__":
    main()
