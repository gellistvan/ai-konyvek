python audit_manifest.py --data data
