order = np.random.permutation(np.unique(meta["index"]))
