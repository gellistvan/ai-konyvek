import pandas as pd

def check_group_split(meta: pd.DataFrame) -> list:
    # meta oszlopai: index, scene_id, split
    nsplit = meta.groupby("scene_id")["split"].nunique()
    return list(nsplit[nsplit != 1].index)

# a kézi példa hat soros, helyes változata
good = pd.DataFrame({
    "index": [0,1,2,3,4,5],
    "scene_id": ["G0-0000","G0-0000","G1-0000","G1-0000","G2-0000","G2-0000"],
    "split": ["train","train","train","train","val","val"],
})
print(check_group_split(good))  # []

# hibás: a G2-0000 egyik view-ja train lett
bad = good.copy()
bad.loc[5, "split"] = "train"
print(check_group_split(bad))   # ['G2-0000']
