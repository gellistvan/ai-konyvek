import argparse, hashlib, json, sys
from pathlib import Path
import numpy as np
import pandas as pd

# Input: GlyphLab data könyvtár; CPU fájlművelet, nincs véletlen.
def sha256_of(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def check(data_dir: str) -> list[str]:
    data = Path(data_dir)
    errors: list[str] = []
    manifest = json.loads((data / "manifest.json").read_text())

    # A GlyphLab manifest sémája (lab/ADATOK.md): generator_version, seed,
    # arrays, counts, sha256, corrupt_order.
    for key in ["generator_version", "seed", "arrays", "counts", "sha256",
                "corrupt_order"]:
        if key not in manifest:
            errors.append(f"hiányzik manifest kulcs: {key}")
    for rel, sha in manifest.get("sha256", {}).items():
        p = data / rel
        if not p.exists():
            errors.append(f"hiányzik adatfájl: {rel}")
        elif sha != sha256_of(p):
            errors.append(f"sha256 hibás: {rel}")
    # a rögzített tömb-alak és dtype egyezzen a tényleges .npy fájlokkal
    for name, spec in manifest.get("arrays", {}).items():
        arr = np.load(data / name, mmap_mode="r")
        if list(arr.shape) != list(spec["shape"]) or str(arr.dtype) != spec["dtype"]:
            errors.append(f"tömb-alak vagy dtype eltérés: {name}")

    meta = pd.read_csv(data / "metadata.csv")
    n = len(meta)
    # index: 0..N-1 permutáció (címkehivatkozás egyedisége)
    if set(meta["index"]) != set(range(n)) or meta["index"].duplicated().any():
        errors.append("index nem egyedi 0..N-1 permutáció")
    if not meta["label"].isin({0, 1, 2}).all():
        errors.append("label {0,1,2}-n kívüli érték")
    if not set(meta["split"]) <= {"train", "val", "test"}:
        errors.append(f"ismeretlen split érték: {sorted(set(meta['split']))}")
    # csoportos split: scene -> split egyértelmű
    bad = meta.groupby("scene_id")["split"].nunique()
    bad = bad[bad != 1]
    if not bad.empty:
        errors.append(f"csoportos split sértve: {list(bad.index)}")
    # megfigyelt darabszámok a manifesttel szemben
    counts = {str(k): int(v) for k, v in meta["split"].value_counts().items()}
    expected = {str(k): int(v) for k, v in manifest.get("counts", {}).items()}
    if counts != expected:
        errors.append(f"split-szám eltérés: {counts} != {expected}")
    # doboz: fél-nyílt xyxy, 0<=min<max<=24, pozitív terület
    box_ok = (
        meta["xmin"].between(0, 24)
        & meta["ymin"].between(0, 24)
        & meta["xmax"].between(0, 24)
        & meta["ymax"].between(0, 24)
        & (meta["xmin"] < meta["xmax"])
        & (meta["ymin"] < meta["ymax"])
    )
    if not box_ok.all():
        errors.append("hibás doboz, nem fél-nyílt xyxy")
    return errors

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    args = ap.parse_args()
    errs = check(args.data)
    for e in errs:
        print("HIBA:", e)
    if errs:
        sys.exit(1)
    print("OK: minden GlyphLab audit-ellenőrzés átment")
