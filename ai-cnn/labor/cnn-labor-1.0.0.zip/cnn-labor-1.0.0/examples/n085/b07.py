import numpy as np

scenes = np.unique(meta["scene_id"])
rng = np.random.default_rng(20261020)
perm = rng.permutation(scenes)
val_scenes = set(perm[:30])
test_scenes = set(perm[30:60])
train_scenes = set(perm[60:])
assert len(val_scenes) == len(test_scenes) == 30
assert len(train_scenes) == len(scenes) - 60

# A képindexet a saját index oszlop adja, nem a pandas sorszám.
is_val = meta["scene_id"].isin(val_scenes)
is_test = meta["scene_id"].isin(test_scenes)
train_idx = meta.loc[~is_val & ~is_test, "index"].to_numpy()
val_idx = meta.loc[is_val, "index"].to_numpy()
test_idx = meta.loc[is_test, "index"].to_numpy()

# visszaellenőrzés: a három képindex-halmaz diszjunkt és lefedő
assert set(train_idx).isdisjoint(val_idx)
assert set(train_idx).isdisjoint(test_idx)
assert set(val_idx).isdisjoint(test_idx)
assert len(train_idx) + len(val_idx) + len(test_idx) == len(meta)

# a döntés jelenetszintű: minden jelenet pontosan egy új splitbe esik
new_split = meta["scene_id"].map(
    {**{s: "val" for s in val_scenes}, **{s: "test" for s in test_scenes},
     **{s: "train" for s in train_scenes}})
assert new_split.notna().all()
assert check_group_split(meta.assign(split=new_split)) == []
