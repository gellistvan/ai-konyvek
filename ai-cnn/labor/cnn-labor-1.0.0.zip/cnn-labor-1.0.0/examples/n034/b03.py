H = relu(X @ W1.T + b1)
Z = relu(H @ W2.T + b2)
