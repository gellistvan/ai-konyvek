import numpy as np

def mlp_forward(X, W1, b1, W2, b2):
    # X: (N,d), W1: (m,d), b1: (m,), W2: (K,m), b2: (K,)
    Z = X @ W1.T + b1          # (N,m)
    H = np.maximum(0.0, Z)     # (N,m)
    return H @ W2.T + b2       # (N,K)

W1 = np.array([[1.0, 1.0], [1.0, 1.0]], dtype=np.float64)
b1 = np.array([-0.5, -1.5], dtype=np.float64)
W2 = np.array([[2.0, -6.0]], dtype=np.float64)
b2 = np.array([0.0], dtype=np.float64)
X = np.array([[0.0, 0.0], [1.0, 0.0], [0.0, 1.0], [1.0, 1.0]],
             dtype=np.float64)

Z = mlp_forward(X, W1, b1, W2, b2)
expected = np.array([[0.0], [1.0], [1.0], [0.0]], dtype=np.float64)
assert Z.shape == (4, 1)
assert np.allclose(Z, expected, atol=1e-12)
print("OK", Z.shape, Z.ravel())
