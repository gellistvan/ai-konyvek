import numpy as np

# dtype float64, CPU, nincs véletlen forrás
W1 = np.array([[1.0, 1.0],
               [1.0, 1.0]], dtype=np.float64)      # (2, 2)
b1 = np.array([-0.5, -1.5], dtype=np.float64)      # (2,)
W2 = np.array([[2.0, -6.0]], dtype=np.float64)     # (1, 2)
b2 = np.array([0.0], dtype=np.float64)             # (1,)

X = np.array([[0.0, 0.0],
              [1.0, 0.0],
              [0.0, 1.0],
              [1.0, 1.0]], dtype=np.float64)       # (4, 2)

def relu(u):
    return np.maximum(0.0, u)

S1 = X @ W1.T + b1              # (4, 2) + (2,) sorirányú broadcast
H = relu(S1)                    # (4, 2)
Z = H @ W2.T + b2               # (4, 1)

print("H shape:", H.shape)
print("Z shape:", Z.shape)
print("H:\n", H)
print("Z:\n", Z)

pred = (Z > 0.5).astype(np.int64)
print("pred:\n", pred.ravel())

expected = np.array([[0.0], [1.0], [1.0], [0.0]], dtype=np.float64)
print("allclose expected:", np.allclose(Z, expected, atol=1e-12))
assert H.shape == (4, 2) and Z.shape == (4, 1)
assert np.allclose(Z, expected, atol=1e-12)
assert np.array_equal(pred.ravel(), np.array([0, 1, 1, 0]))
