def q(x):
    return x * x

def numdiff(f, x, h):
    forward = (f(x + h) - f(x)) / h
    central = (f(x + h) - f(x - h)) / (2.0 * h)
    return forward, central

fwd, cen = numdiff(q, 3.0, 1e-2)
print(fwd, cen)  # várhatóan 6,01 és 6,0 körül
assert abs(fwd - 6.01) < 1e-12
assert abs(cen - 6.0) < 1e-12
