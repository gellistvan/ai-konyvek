"""n013 labor: forward és centrális differencia hibagörbéje q(x)=x^2-re.

Futtatás: python n013_numerical_derivative.py
Környezet: CPU, Python 3, float64; nincs véletlen és nincs GPU.
"""
def q(x):
    """A vizsgált négyzetfüggvény."""
    return x * x

def forward_diff(f, x, h):
    """Előre mutató differenciahányados, h > 0."""
    return (f(x + h) - f(x)) / h

def central_diff(f, x, h):
    """Középső differencia, h > 0."""
    return (f(x + h) - f(x - h)) / (2.0 * h)

def main():
    x0 = 3.0
    exact = 2.0 * x0
    steps = [1.0, 1e-1, 1e-2, 1e-3, 1e-4, 1e-5,
             1e-6, 1e-8, 1e-10, 1e-12, 1e-16]
    print(f"{'h':>9} {'forward':>14} {'central':>14} "
          f"{'err_forward':>14} {'err_central':>14}")
    for h in steps:
        fwd = forward_diff(q, x0, h)
        cen = central_diff(q, x0, h)
        print(f"{h:9.1e} {fwd:14.10e} {cen:14.10e} "
              f"{abs(fwd-exact):14.6e} {abs(cen-exact):14.6e}")

    # Nevezetes értékek ellenőrzése a definícióból (nem a kiírt táblázatból):
    assert abs(forward_diff(q, x0, 1.0) - 7.0) < 1e-12
    assert abs(central_diff(q, x0, 1.0) - 6.0) < 1e-12
    assert abs(forward_diff(q, x0, 1e-2) - 6.01) < 1e-9
    assert abs(central_diff(q, x0, 1e-2) - 6.0) < 1e-9
    assert forward_diff(q, x0, 1e-16) == 0.0
    assert central_diff(q, x0, 1e-16) == 0.0

if __name__ == "__main__":
    main()
