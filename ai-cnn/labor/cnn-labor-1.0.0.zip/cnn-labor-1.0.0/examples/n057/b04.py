db[o] = np.sum(dY[np.arange(N), o, :, :]) / (H_out * W_out)
