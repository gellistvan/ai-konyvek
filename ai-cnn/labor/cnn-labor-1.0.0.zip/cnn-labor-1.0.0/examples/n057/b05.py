import numpy as np

def weight_grad_from_dY(dY, X, k, stride=1, pad=0):
    N, C_in, H, W = X.shape
    C_out = dY.shape[1]
    kh, kw = k
    H_out, W_out = dY.shape[2], dY.shape[3]
    Xp = np.pad(X, ((0, 0), (0, 0), (pad, pad), (pad, pad)))
    dK = np.zeros((C_out, C_in, kh, kw), dtype=np.float64)
    for o in range(C_out):
        for c in range(C_in):
            for u in range(kh):
                for v in range(kw):
                    window = Xp[:, c,
                               u:u + stride * (H_out - 1) + 1:stride,
                               v:v + stride * (W_out - 1) + 1:stride]
                    dK[o, c, u, v] = np.sum(dY[:, o] * window)
    return dK
