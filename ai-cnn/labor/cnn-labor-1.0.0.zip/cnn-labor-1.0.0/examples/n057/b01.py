# lab/n057/weight_grad_check.py
import numpy as np

def conv2d_forward(X, K, b, stride=1, pad=0):
    """NCHW cross-correlation, groups=1, dilation=1, float64."""
    N, C_in, H, W = X.shape
    C_out, C_in_k, kh, kw = K.shape
    assert C_in == C_in_k
    H_out = (H + 2 * pad - kh) // stride + 1
    W_out = (W + 2 * pad - kw) // stride + 1
    Xp = np.pad(X, ((0, 0), (0, 0), (pad, pad), (pad, pad)))
    Y = np.zeros((N, C_out, H_out, W_out), dtype=np.float64)
    for n in range(N):
        for o in range(C_out):
            for i in range(H_out):
                for j in range(W_out):
                    acc = b[o]
                    for c in range(C_in):
                        for u in range(kh):
                            for v in range(kw):
                                acc += Xp[n, c, i * stride + u,
                                         j * stride + v] * K[o, c, u, v]
                    Y[n, o, i, j] = acc
    return Y

def conv2d_weight_grad(X, K, dY, stride=1, pad=0):
    """Weight and bias gradient from the derived theorem (b nem kell hozzá)."""
    N, C_in, H, W = X.shape
    C_out, _, kh, kw = K.shape
    H_out = dY.shape[2]
    W_out = dY.shape[3]
    Xp = np.pad(X, ((0, 0), (0, 0), (pad, pad), (pad, pad)))
    dK = np.zeros_like(K, dtype=np.float64)
    db = np.zeros(C_out, dtype=np.float64)
    for o in range(C_out):
        for c in range(C_in):
            for u in range(kh):
                for v in range(kw):
                    total = 0.0
                    for n in range(N):
                        for i in range(H_out):
                            for j in range(W_out):
                                total += dY[n, o, i, j] * Xp[
                                    n, c, i * stride + u, j * stride + v]
                    dK[o, c, u, v] = total
        db[o] = np.sum(dY[:, o, :, :])
    return dK, db

def finite_diff_check(X, K, b, eps=1e-5, stride=1, pad=0):
    """Central difference for one scalar loss L = 0.5 * sum(Y ** 2)."""
    C_out, kh, kw = K.shape[0], K.shape[2], K.shape[3]

    def loss(K, b):
        Y = conv2d_forward(X, K, b, stride, pad)
        return 0.5 * np.sum(Y ** 2)

    dK_num = np.zeros_like(K, dtype=np.float64)
    for o in range(C_out):
        for c in range(K.shape[1]):
            for u in range(kh):
                for v in range(kw):
                    Kp = K.copy(); Km = K.copy()
                    Kp[o, c, u, v] += eps
                    Km[o, c, u, v] -= eps
                    dK_num[o, c, u, v] = (loss(Kp, b) - loss(Km, b)) / (2 * eps)
    db_num = np.zeros(C_out, dtype=np.float64)
    for o in range(C_out):
        bp = b.copy(); bm = b.copy()
        bp[o] += eps; bm[o] -= eps
        db_num[o] = (loss(K, bp) - loss(K, bm)) / (2 * eps)
    return dK_num, db_num

if __name__ == "__main__":
    rng = np.random.default_rng(20261020)
    # 3x3 single-position case
    X1 = np.array([[[[1.0, 2.0, 1.0],
                     [0.0, 1.0, 3.0],
                     [2.0, 0.0, 1.0]]]])
    K1 = np.array([[[[1.0, 0.0, 0.0],
                     [0.0, 1.0, 0.0],
                     [0.0, 0.0, -1.0]]]])
    b1 = np.array([5.0])
    Y1 = conv2d_forward(X1, K1, b1, 1, 0)
    dY1 = Y1  # since upstream for L = 0.5*sum(Y**2) is Y
    dK1, db1 = conv2d_weight_grad(X1, K1, dY1, stride=1, pad=0)
    dK1_num, db1_num = finite_diff_check(X1, K1, b1, stride=1, pad=0)
    assert np.allclose(dK1, dK1_num, atol=1e-8, rtol=1e-5), (dK1, dK1_num)
    assert np.allclose(db1, db1_num, atol=1e-8, rtol=1e-5), (db1, db1_num)
    print("3x3 case: dK =", dK1[0, 0].ravel().tolist(), "db =", db1.ravel().tolist())

    # Független PyTorch-autograd ellenőrzés ugyanazon a 3x3-as eseten (float64)
    import torch
    Xt = torch.tensor(X1, dtype=torch.float64, requires_grad=True)
    Kt = torch.tensor(K1, dtype=torch.float64, requires_grad=True)
    bt = torch.tensor(b1, dtype=torch.float64, requires_grad=True)
    Yt = torch.nn.functional.conv2d(Xt, Kt, bt, stride=1, padding=0)
    (0.5 * (Yt ** 2).sum()).backward()
    assert np.allclose(Kt.grad.numpy(), dK1, atol=1e-10)
    assert np.allclose(bt.grad.numpy(), db1, atol=1e-10)
    print("PyTorch-autograd egyezés: OK")

    # 4x4 input, N=2, C_in=2, C_out=2, kernel 3x3, stride 1, no padding
    X2 = rng.normal(size=(2, 2, 4, 4))
    K2 = rng.normal(size=(2, 2, 3, 3))
    b2 = rng.normal(size=(2,))
    Y2 = conv2d_forward(X2, K2, b2, 1, 0)
    dY2 = Y2
    dK2, db2 = conv2d_weight_grad(X2, K2, dY2, stride=1, pad=0)
    # Ugyanazzal a bemenettel, kernellel és biasszal ellenőrzünk:
    dK2_num, db2_num = finite_diff_check(X2, K2, b2, stride=1, pad=0)
    assert np.allclose(dK2, dK2_num, atol=1e-8, rtol=1e-5)
    assert np.allclose(db2, db2_num, atol=1e-8, rtol=1e-5)
    print("4x4 case: dK shape", dK2.shape, "db shape", db2.shape, "OK")
