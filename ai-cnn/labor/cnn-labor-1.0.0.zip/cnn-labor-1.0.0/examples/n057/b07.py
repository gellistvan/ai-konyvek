db[o] = np.sum(dY[:, o, :, :])
