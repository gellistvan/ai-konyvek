cd lab/n057
python weight_grad_check.py
