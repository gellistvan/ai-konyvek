dW = G.T @ X
dX = G @ W
