# lab_n038.py
# Munkakönyvtár: a fejezet lab könyvtára.
# Futtatás: python lab_n038.py
import numpy as np

def relu(x):
    return np.maximum(0.0, x)

def linear_forward(X, W, b):
    Z = X @ W.T + b
    cache = (X, W)          # b a backwardhoz nem kell
    return Z, cache

def relu_forward(Z):
    H = relu(Z)
    cache = Z               # a maszkot a pre-aktivációból képezzük
    return H, cache

def linear_backward(G, cache):
    X, W = cache
    dW = G.T @ X
    db = G.sum(axis=0)      # biasgradiens: batch szerinti összeg
    dX = G @ W
    return dX, dW, db

def relu_backward(dH, cache):
    Z = cache
    dZ = dH * (Z > 0)       # ReLU-maszk; a nullponti konvenció 0
    return dZ

# Determinisztikus kis bemenet, float64 CPU.
X = np.array([[1.,2.,3.,4.],
              [5.,6.,7.,8.],
              [9.,10.,11.,12.]], dtype=np.float64)      # (3,4)
W1 = np.array([[0.1,0.2,0.3,0.4],
               [0.5,0.6,0.7,0.8],
               [0.9,1.0,1.1,1.2],
               [1.3,1.4,1.5,1.6],
               [1.7,1.8,1.9,2.0]], dtype=np.float64)    # (5,4)
b1 = np.array([0.01,-0.02,0.03,-0.04,0.05], dtype=np.float64)
W2 = np.array([[0.1,0.2,0.3,0.4,0.5],
               [-0.1,-0.2,0.1,0.2,0.3]], dtype=np.float64)  # (2,5)
b2 = np.array([0.0,0.1], dtype=np.float64)
y = np.array([[1.,0.],
              [0.,1.],
              [1.,1.]], dtype=np.float64)               # (3,2)

# Forward.
Z1, cache1 = linear_forward(X, W1, b1)   # (3,5)
H1, rcache = relu_forward(Z1)            # (3,5)
Z2, cache2 = linear_forward(H1, W2, b2)  # (3,2)

# Loss: batch-mean, félenkénti MSE.  L = 1/(2NK) * sum (Z2-y)^2
N, K = y.shape
L = 0.5 * np.mean((Z2 - y) ** 2)

# Backward; a mean reduction skalája az upstream G2-ben van.
G2 = (Z2 - y) / (N * K)
dH1, dW2, db2 = linear_backward(G2, cache2)
dZ1 = relu_backward(dH1, rcache)
dX, dW1, db1 = linear_backward(dZ1, cache1)

print("L=", L)
print("Z1", Z1.shape, "H1", H1.shape, "Z2", Z2.shape)
print("dW1", dW1.shape, "db1", db1.shape, "dX", dX.shape)
print("dW2", dW2.shape, "db2", db2.shape)
assert Z1.shape == (3, 5) and H1.shape == (3, 5) and Z2.shape == (3, 2)
assert dW1.shape == W1.shape and db1.shape == b1.shape and dX.shape == X.shape
assert dW2.shape == W2.shape and db2.shape == b2.shape

# Független numerikus ellenőrzés centrális differenciával; a bemeneti dX is.
def loss_of(params):
    A, c, B, d, Xv = params
    return 0.5 * np.mean((relu(Xv @ A.T + c) @ B.T + d - y) ** 2)

base_params = [W1.copy(), b1.copy(), W2.copy(), b2.copy(), X.copy()]
analytical = [dW1, db1, dW2, db2, dX]
eps = 1e-6
max_abs = 0.0
max_rel = 0.0
for p, g in zip(base_params, analytical):
    pf = p.reshape(-1)
    gf = g.reshape(-1)
    for idx in range(pf.size):
        old = pf[idx]
        pf[idx] = old - eps
        lm = loss_of(base_params)
        pf[idx] = old + eps
        lp = loss_of(base_params)
        pf[idx] = old
        num = (lp - lm) / (2.0 * eps)
        max_abs = max(max_abs, abs(num - gf[idx]))
        denom = max(abs(num), abs(gf[idx]), 1e-12)
        max_rel = max(max_rel, abs(num - gf[idx]) / denom)
print(f"max_abs_grad_err={max_abs:.3e}")
print(f"max_rel_grad_err={max_rel:.3e}")
print("max_rel_grad_err < 1e-6:", max_rel < 1e-6)
assert max_rel < 1e-6
