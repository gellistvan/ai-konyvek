def linear_backward_wrong(G, cache):
    X, W = cache
    dW = X.T @ G
    db = G.sum(axis=0)
    dX = W.T @ G
    return dX, dW, db
