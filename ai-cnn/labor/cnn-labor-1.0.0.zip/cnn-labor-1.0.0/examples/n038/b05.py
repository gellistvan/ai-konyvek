import numpy as np

def linear_backward(G, cache):
    X, W = cache
    dW = G.T @ X
    db = G.sum(axis=0)
    dX = G @ W
    return dX, dW, db

X = np.array([[1., 2., 3.], [4., 5., 6.]], dtype=np.float64)
W = np.array([[1., 0., 1.], [0., 2., 0.], [1., 1., 0.], [0., 0., 1.]], dtype=np.float64)
b = np.array([1., -1., 2., 0.], dtype=np.float64)
G = np.array([[2., 1., 0., -1.], [-1., 3., 1., 2.]], dtype=np.float64)

dX, dW, db = linear_backward(G, (X, W))
print("dW =", dW.tolist())
print("db =", db.tolist())
print("dX =", dX.tolist())
assert dW.shape == W.shape and db.shape == b.shape and dX.shape == X.shape
assert np.allclose(dW, [[-2., -1., 0.], [13., 17., 21.], [4., 5., 6.], [7., 8., 9.]], rtol=1e-9, atol=1e-12)
assert np.allclose(db, [1., 4., 1., 1.], rtol=1e-9, atol=1e-12)
assert np.allclose(dX, [[2., 2., 1.], [0., 7., 1.]], rtol=1e-9, atol=1e-12)
