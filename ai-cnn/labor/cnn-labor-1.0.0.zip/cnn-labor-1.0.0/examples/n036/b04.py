def relu_backward(a, grad_out):
    # ReLU-derivált
    return (a > 0) * grad_out
