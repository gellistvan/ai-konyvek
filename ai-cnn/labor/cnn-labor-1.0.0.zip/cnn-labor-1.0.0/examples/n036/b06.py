# lab/n036/feladat_f3.py
import numpy as np

def tanh(x):
    return np.tanh(x)

def dtanh(x):
    return 1.0 - np.tanh(x) ** 2

def forward(x, ws):
    acts = []
    h = x
    for w in ws:
        a = np.float64(w) * np.float64(h)
        acts.append(a)
        h = tanh(a)
    return np.float64(h), acts

def analytic_grad(ws, acts):
    g = np.float64(1.0)
    for w, a in reversed(list(zip(ws, acts))):
        g = g * np.float64(w) * dtanh(a)
    return g

rng = np.random.default_rng(20261020)
ws = [np.float64(rng.uniform(0.5, 1.5)) for _ in range(3)]
x0 = np.float64(1.0)

y, acts = forward(x0, ws)
g_an = analytic_grad(ws, acts)

delta = np.float64(1e-6)
yp, _ = forward(np.float64(x0 + delta), ws)
ym, _ = forward(np.float64(x0 - delta), ws)
g_num = (yp - ym) / (np.float64(2.0) * delta)
print("sulyok:", ws)
print("analitikus:", g_an)
print("numerikus:  ", g_num)
print("abszolut elteres:", abs(g_an - g_num))
assert abs(g_an - g_num) < 1e-5
