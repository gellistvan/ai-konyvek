def relu_backward(a, grad_out):
    # ReLU deriváltja
    return (a > 0) * grad_out
