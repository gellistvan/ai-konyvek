import numpy as np

def relu_backward(a, grad_out):
    return (a > 0) * grad_out

for a in (1.0, -1.0):
    x, delta = np.float64(a), np.float64(1e-6)
    fd = (max(0.0, x + delta) - max(0.0, x - delta)) / (2.0 * delta)
    print(f"a={a:+.0f}  backward={float(relu_backward(np.float64(a), np.float64(1.0))):.1f}  fd={fd:.1f}")
