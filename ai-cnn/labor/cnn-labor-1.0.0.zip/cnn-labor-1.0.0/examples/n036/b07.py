def relu_backward(a, grad_out):
    # Visszaterjesztési konvenció: a 0-beli érték 0, nem klasszikus derivált.
    # A klasszikus derivált csak a != 0 pontokban létezik.
    # A maszkos szorzás skalárra és ndarray-re egyaránt működik.
    return (a > 0) * grad_out
