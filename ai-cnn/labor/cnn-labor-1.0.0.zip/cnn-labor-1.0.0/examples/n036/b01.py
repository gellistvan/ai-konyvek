# lab/n036/activation_gradients.py
import pathlib

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def sigmoid(z):
    return np.float32(1.0) / (np.float32(1.0) + np.exp(-z))

def relu(z):
    return np.maximum(np.float32(0.0), z)

def drelu(z):
    # Visszaterjesztési konvenció: z=0-ban 0; ott klasszikus derivált nincs.
    return (z > 0).astype(np.float32)

def dsigmoid(z):
    s = sigmoid(z)
    return s * (np.float32(1.0) - s)

def dtanh(z):
    t = np.tanh(z)
    return np.float32(1.0) - t * t

def scalar_mlp(x, depth, w, phi, dphi):
    """Skaláris, bias nélküli MLP. Visszaadja a kimenetet és a dx gradienst."""
    h = np.float32(x)
    local_derivatives = []
    for _ in range(depth):
        a = np.float32(w) * h
        local_derivatives.append(np.float32(w) * np.float32(dphi(a)))
        h = phi(a)
    grad = np.prod(local_derivatives, dtype=np.float32)
    return np.float32(h), np.float32(grad)

def scalar_mlp_float64(x, depth, w):
    """Ugyanaz a tanh-háló float64-ben, a középső differenciához."""
    h = np.float64(x)
    for _ in range(depth):
        h = np.tanh(np.float64(w) * h)
    return h

def main():
    x = np.float32(0.0)   # tanh-nál nem telített pont
    w = np.float32(0.8)
    delta = 1e-5
    for depth in (4, 12):
        y, g = scalar_mlp(x, depth, w, np.tanh, dtanh)
        fd = (scalar_mlp_float64(np.float64(x) + delta, depth, w)
              - scalar_mlp_float64(np.float64(x) - delta, depth, w)) / (2.0 * delta)
        print(f"depth={depth:2d}  output={y:.6f}  input_grad={g:.6f}  fd={fd:.6f}")
        assert np.isclose(float(y), 0.0, atol=1e-6)
        assert np.isclose(float(g), 0.8 ** depth, rtol=1e-5)
        assert np.isclose(float(g), fd, rtol=1e-6, atol=1e-12)

    z = np.linspace(-5, 5, 501, dtype=np.float32)
    plt.figure(figsize=(8, 4))
    plt.plot(z, sigmoid(z), label="sigmoid")
    plt.plot(z, dsigmoid(z), label="sigmoid derivált")
    plt.plot(z, np.tanh(z), label="tanh")
    plt.plot(z, dtanh(z), label="tanh derivált")
    plt.plot(z, relu(z), label="ReLU")
    plt.plot(z, drelu(z), label="ReLU derivált (0-ban konvenció: 0)")
    plt.grid(True)
    plt.legend()
    plt.title("Aktivációk és lokális deriváltak")
    out = pathlib.Path("lab/n036")
    out.mkdir(parents=True, exist_ok=True)
    plt.savefig(out / "activations.png", dpi=150)
    print(f"mentve: {out / 'activations.png'}")

if __name__ == "__main__":
    main()
