python lab/n036/activation_gradients.py
