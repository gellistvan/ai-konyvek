python lab/n032/checkpoint_lab.py
