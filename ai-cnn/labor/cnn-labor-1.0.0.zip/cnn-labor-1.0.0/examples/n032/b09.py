for z, y in [(1000.0, 0.0), (-1000.0, 1.0)]:
    print(z, y, bce_logits_stable(z, y))
