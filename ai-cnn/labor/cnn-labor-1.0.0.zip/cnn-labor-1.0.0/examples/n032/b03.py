import json
import os

import numpy as np

SEED = 20261020
rng = np.random.default_rng(SEED)


def uniform_bound(n_h, m, delta):
    return float(np.sqrt((np.log(n_h) + np.log(1.0 / delta)) / (2.0 * m)))


def simulate_coverage(n_sim=2000, m=64, delta=0.05, seed=123):
    rng_cov = np.random.default_rng(seed)
    b = uniform_bound(4, m, delta)
    true_risk = np.array([0.0, 1.0, 0.5, 0.5])
    covered = 0
    for _ in range(n_sim):
        X = rng_cov.uniform(-1.0, 1.0, size=(m, 2))
        y = (X[:, 0] > 0).astype(np.float64)
        pred = np.vstack([
            X[:, 0] > 0,
            X[:, 0] <= 0,
            X[:, 1] > 0,
            X[:, 1] <= 0,
        ])
        err = (pred != y).mean(axis=1)
        if np.all(true_risk <= err + b):
            covered += 1
    return covered / n_sim, b


def bce_logits_stable_f64(z, y):
    """z: (N,) logits, y: (N,) float cél {0,1}. Átlagos BCE, stabil."""
    z = np.asarray(z, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    assert z.shape == y.shape and z.ndim == 1
    return float(np.mean(np.maximum(z, 0) - y * z + np.log1p(np.exp(-np.abs(z)))))


def make_data(n, rng):
    X = rng.normal(0.0, 1.0, size=(n, 2)).astype(np.float32)
    assert X.shape == (n, 2)
    logit_p = (2.0 * X[:, 0] - X[:, 1]).astype(np.float32)
    p = 1.0 / (1.0 + np.exp(-logit_p))
    y = (rng.random(n) < p).astype(np.float32)
    return X, y
