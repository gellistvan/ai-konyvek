def loss_and_grad(w, b, X, y, lam):
    z = X @ w + b
    p = np.exp(-np.logaddexp(0.0, -z))  # stabil szigmoid
    loss = bce_logits_stable_f64(z, y) + 0.5 * lam * float(w @ w)
    g = (p - y) / len(y)
    return loss, X.T @ g + lam * w, np.sum(g)


def grad_check(X8, y8, lam=1e-3):
    w0 = rng.normal(0.0, 0.5, size=2)
    b0 = np.float64(0.2)
    _, gw, gb = loss_and_grad(w0, b0, X8, y8, lam)
    max_abs = 0.0
    for j in range(2):
        wp, wm = w0.copy(), w0.copy()
        wp[j] += 1e-6
        wm[j] -= 1e-6
        lp, _ = loss_and_grad(wp, b0, X8, y8, lam)[:2]
        lm, _ = loss_and_grad(wm, b0, X8, y8, lam)[:2]
        num = (lp - lm) / (2e-6)
        max_abs = max(max_abs, abs(num - gw[j]))
    bp, bm = b0 + 1e-6, b0 - 1e-6
    num_b = (loss_and_grad(w0, bp, X8, y8, lam)[0]
             - loss_and_grad(w0, bm, X8, y8, lam)[0]) / (2e-6)
    max_abs = max(max_abs, abs(num_b - gb))
    return float(max_abs)
