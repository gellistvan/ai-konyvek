def main():
    n_train, n_val, n_test = 1800, 200, 2000
    Xt, yt = make_data(n_train, rng)
    Xv, yv = make_data(n_val, rng)
    Xs, ys = make_data(n_test, rng)
    assert Xt.shape == (n_train, 2) and Xv.shape == (n_val, 2)
    assert Xs.shape == (n_test, 2)

    # Baseline: a tanító címkearány mint konstans valószínűség
    q = float(np.mean(yt))
    base_ce = -float(np.mean(ys * np.log(q) + (1.0 - ys) * np.log(1.0 - q)))
    # A konstans jostlat a tanito q-bol jon; a teszt csak kiertekel.
    base_acc = float(np.mean(ys == float(q > 0.5)))

    results = {}
    for lr in (0.1, 0.5):
        w, b = train_one(Xt, yt, lr=lr, epochs=50, batch=16, lam=1e-3)
        zv = Xv.astype(np.float32) @ w + b
        val_loss = bce_logits_stable_f64(zv, yv)
        results[lr] = {"w": w, "b": b, "val_loss": val_loss}

    best_lr = min(results, key=lambda k: results[k]["val_loss"])
    w, b = results[best_lr]["w"], results[best_lr]["b"]
    zs = Xs.astype(np.float32) @ w + b
    test_ce = bce_logits_stable_f64(zs, ys)
    test_acc = float(np.mean((zs > 0.0) == (ys > 0.0)))

    X8 = Xt[:8].astype(np.float64)
    y8 = yt[:8].astype(np.float64)
    grad_err = grad_check(X8, y8)

    cov, band = simulate_coverage(n_sim=2000, m=64, delta=0.05, seed=123)
    assert 0.0 <= cov <= 1.0
    assert grad_err < 1e-8

    manifest = {
        "coverage_simulation": {
            "theorem": "finite_H_uniform_bound",
            "H_size": 4,
            "m": 64,
            "delta": 0.05,
            "assumptions_checked": [
                "finite fixed H (4 rules)", "iid sample",
                "0/1 loss in [0,1]", "delta fixed",
            ],
            "bound_band": band,
            "coverage": cov,
        },
        "logistic_regression": {
            "note": ("folytonos parameterteru modell; a Hoeffding-unio"
                     "korlat nem alkalmazhato ra, a teszt CE es pontossag "
                     "leiro meroszam"),
        },
        "baseline": {"ce": base_ce, "acc": base_acc},
        "chosen_lr": best_lr,
        "final_test": {"ce": test_ce, "acc": test_acc},
        "grad_check_max_abs_err": grad_err,
        "seed": SEED,
        "device": "CPU",
        "dtype": "float32 training, float64 checks",
    }
    os.makedirs("lab/n032", exist_ok=True)
    with open("lab/n032/evidence.json", "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2)
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
