import numpy as np


def uniform_bound(n_h, m, delta):
    return float(np.sqrt((np.log(n_h) + np.log(1.0 / delta)) / (2.0 * m)))


def simulate_coverage(n_sim=2000, m=64, delta=0.05, seed=123):
    rng = np.random.default_rng(seed)
    b = uniform_bound(4, m, delta)
    true_risk = np.array([0.0, 1.0, 0.5, 0.5])
    covered = 0
    for _ in range(n_sim):
        X = rng.uniform(-1.0, 1.0, size=(m, 2))
        y = (X[:, 0] > 0).astype(np.float64)
        pred = np.vstack([
            X[:, 0] > 0,
            X[:, 0] <= 0,
            X[:, 1] > 0,
            X[:, 1] <= 0,
        ])
        err = (pred != y).mean(axis=1)
        if np.all(true_risk <= err + b):
            covered += 1
    return covered / n_sim, b
