import numpy as np


def bce_logits_stable(z, y):
    z = np.asarray(z, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    return np.maximum(z, 0) - y * z + np.log1p(np.exp(-np.abs(z)))
