def train_one(X, y, lr, epochs, batch, lam):
    n, d = X.shape
    w = np.zeros(d, dtype=np.float32)
    b = np.float32(0.0)
    for _ in range(epochs):
        idx = rng.permutation(n)
        for start in range(0, n, batch):
            bi = idx[start:start + batch]
            Xb = X[bi].astype(np.float32)
            yb = y[bi]
            z = Xb @ w + b
            p = np.exp(-np.logaddexp(0.0, -z))  # stabil szigmoid
            g = (p - yb) / len(bi)
            gw = Xb.T @ g + lam * w
            gb = np.sum(g)
            w -= lr * gw
            b -= lr * gb
    return w, b
