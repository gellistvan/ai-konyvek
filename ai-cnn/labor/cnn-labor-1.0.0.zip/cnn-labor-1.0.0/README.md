# cnn-labor — a „Neurális hálózatok és CNN-ek” tankönyv laborcsomagja

A csomag a könyv jelen kiadásának forrásszövegéből készült (lásd
`RELEASE_MANIFEST.json`: verzió, a 160 alfejezet SHA-256 lenyomata, a fájlok
lenyomatai). A korábbi V8-as példatár utódja.

## Telepítés

Előfeltétel: Python 3.12 és az `uv` (`python -m pip install uv`). GPU nem kell.

```bash
cd lab
uv sync                          # a lockolt környezet: NumPy 2.3.5, PyTorch 2.14.1 (CPU)
uv run python quickcheck.py      # adatszerződés és SHA-256 lenyomatok
```

pip-alternatíva: `python -m pip install -r requirements.txt --extra-index-url
https://download.pytorch.org/whl/cpu`.

## Adat

A `lab/data/` a GlyphLab eredeti generátorával (`lab/generate_data.py`, seed
`20261020`, generátorverzió 1.0) készült, és üres könyvtárból újra előállítható:

```bash
cd lab
uv run python generate_data.py --output data
uv run python quickcheck.py
```

A szerződést a `lab/ADATOK.md`, a lenyomatokat a `lab/data/manifest.json` rögzíti.

## A könyv alapútja

```bash
cd lab
uv run python -m pytest -q ../tests        # adat, katalógus, projektfájlok
uv run python ../labbook smoke              # quickcheck + Projekt II + Projekt III
```

A `labbook` parancsai (a csomag gyökeréből, a `lab/` környezet Pythonjával):
`list [nNNN]`, `run nNNN BLOKK`, `data`, `project2`, `project3`, `smoke`.

## Szerkezet

| Könyvtár | Tartalom |
|---|---|
| `lab/` | futtatható laborfájlok: a bemeneti labor és a könyv `lab/...` fejlécű kódblokkjai |
| `examples/nNNN/` | a könyv minden kódblokkja, szó szerint |
| `notebooks/` | alfejezetenként egy notebook a Python-blokkokkal |
| `catalog.json` | blokk → fejezet, sor, nyelv, laborfájl, „szándékosan hibás” jelölés |
| `reference/chapters/` | a forrás alfejezetek, amelyekből a csomag készült |
| `labbook/` | parancssori futtató |
| `tests/` | automatikus ellenőrzések |

A könyv egyes blokkjai szándékosan hibásak vagy kontextusfüggők; ezeket a
`catalog.json` és a `labbook list` jelöli. Licenc: `LICENSE` (kód MIT, adat és
dokumentáció CC BY 4.0).
