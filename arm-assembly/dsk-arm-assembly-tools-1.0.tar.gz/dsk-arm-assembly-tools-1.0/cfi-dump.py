import sys
from elftools.elf.elffile import ELFFile
from elftools.dwarf.callframe import FDE
f=ELFFile(open(sys.argv[1],'rb')); want=sys.argv[2:]
sym={s.name:s['st_value'] for s in f.get_section_by_name('.symtab').iter_symbols()}
d=f.get_dwarf_info()
ents=d.EH_CFI_entries() if d.has_EH_CFI() else d.CFI_entries()
for e in ents:
    if not isinstance(e,FDE): continue
    lo=e['initial_location']
    for n in want:
        if sym.get(n)==lo:
            t=e.get_decoded()
            print(n, 'FDE', hex(lo), 'len', e['address_range'])
            for row in t.table:
                cfa=row['cfa']; regs={k:(v.type,v.arg) for k,v in row.items() if k not in('pc','cfa')}
                print('  +%3d CFA=r%s+%s'%(row['pc']-lo,cfa.reg,cfa.offset), ' '.join(f'r{k}@{a}' for k,(ty,a) in sorted(regs.items()) if ty=='OFFSET'))
