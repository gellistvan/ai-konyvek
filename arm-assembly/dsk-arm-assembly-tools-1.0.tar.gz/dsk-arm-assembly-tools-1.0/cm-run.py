#!/usr/bin/env python3
"""Minimal Cortex-M3 (mps2-an385-like) bare-metal runner on top of Unicorn.

Usage: cm-run.py firmware.elf [--max N] [--trace-reset] [--prio-bits N]
                              [--uart-stdin] [--rx-gap N] [--no-irq] [--timer1-stops-in-wfi]

Memory: 0x00000000-0x003FFFFF code SSRAM, 0x20000000-0x203FFFFF SRAM (4 MiB;
the 0x20400000 mirror is NOT modelled), GPIO 0x40010000-0x40013FFF read-as-zero /
write-ignored (not implemented, like QEMU's mps2-an385), PPB as RAM + NVIC model.
Reset like the hardware: SP <- word[0], PC <- word[1] (bit0 must be 1).

Peripheral models (functional, NOT cycle accurate; 1 instruction = 1 "cycle"):
  * CMSDK UART0 @0x40004000: DATA write -> stdout; with --uart-stdin, bytes read
    from stdin are delivered one by one into DATA/STATE.RXFULL (at most one per
    --rx-gap instructions); RX interrupt (IRQ0) if CTRL.RXINTEN; STATE.TXFULL is
    never set; INTSTATUS is write-1-to-clear.
  * CMSDK Timer0 @0x40000000: RELOAD write also sets VALUE; counts down one per
    instruction; on reaching 0 reloads, sets INTSTATUS and pends IRQ8 if
    CTRL.IRQEN; INTSTATUS is write-1-to-clear.
  * CMSDK Timer1 @0x40001000: same register model as Timer0, free-running
    count-down time base (no interrupt delivery); with --timer1-stops-in-wfi it
    does not advance while the core sleeps in WFI.
  * NVIC: ISER/ICER (enable state), ISPR/ICPR (pending state, W1S/W1C), IABR 0,
    IPR bytes keep the top --prio-bits bits (default 3), AIRCR keeps PRIGROUP.
    Interrupts are taken between instruction chunks when PRIMASK = 0 and the
    priority is higher than the active one: 8-word frame (+ alignment word) on
    MSP, LR = EXC_RETURN; exception return through EXC_RETURN is recognised.
  * SysTick exception (15): software pending only, via ICSR.PENDSTSET/PENDSTCLR
    (0xE000ED04 bit 26/25); priority from SHPR3[31:24]. The SysTick timer
    (SYST_CSR/RVR/CVR) is NOT modelled.
  * UART RX and Timer0 interrupt lines are level-sensitive (a source flag that
    is not cleared re-pends the IRQ after exception return).
  * WFI fast-forwards to the next timer/UART event.
  * DWT CYCCNT does NOT advance (as on QEMU 8.2.2 mps2-an385).
Semihosting via BKPT 0xAB: SYS_WRITEC (3), SYS_WRITE0 (4), SYS_EXIT (0x18).
Exit code: semihosting exit status, 139 on fault, 124 on instruction limit.
"""
import queue
import struct
import sys
import threading

from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM, CS_MODE_THUMB, CS_MODE_MCLASS
from unicorn import (Uc, UcError, UC_ARCH_ARM, UC_MODE_THUMB, UC_MODE_MCLASS,
                     UC_HOOK_INTR, UC_HOOK_MEM_WRITE, UC_HOOK_MEM_READ, UC_HOOK_CODE, UC_PROT_ALL)
from unicorn.arm_const import (UC_ARM_REG_SP, UC_ARM_REG_PC, UC_ARM_REG_R0, UC_ARM_REG_R1,
                               UC_ARM_REG_R2, UC_ARM_REG_R3, UC_ARM_REG_R12,
                               UC_ARM_REG_LR, UC_ARM_REG_XPSR, UC_ARM_REG_PRIMASK,
                               UC_CPU_ARM_CORTEX_M3)

CODE = (0x00000000, 0x00400000)
SRAM = (0x20000000, 0x00400000)
UART0 = 0x40004000
TIMER0 = 0x40000000
TIMER1 = 0x40001000
VERSION = ('cm-run 1.2 (2026-10-19): Timer0 IRQ, Timer1 időalap, UART0 TX/RX, NVIC, '
           'SysTick-pending (ICSR), WFI, semihosting')
PPB = (0xE0000000, 0x00100000)
EXCRET_PAGE = 0xFFFFF000
CHUNK = 2000


def arg(argv, name, default):
    return int(argv[argv.index(name) + 1], 0) if name in argv else default


def main(argv):
    if '--version' in argv:
        print(VERSION)
        print(__doc__)
        return 0
    path = argv[0]
    limit = arg(argv, '--max', 50_000_000)
    prio_bits = arg(argv, '--prio-bits', 3)
    rx_gap = arg(argv, '--rx-gap', 20_000)
    irq_on = '--no-irq' not in argv
    stdin_mode = '--uart-stdin' in argv
    uc = Uc(UC_ARCH_ARM, UC_MODE_THUMB | UC_MODE_MCLASS)
    try:
        uc.ctl_set_cpu_model(UC_CPU_ARM_CORTEX_M3)
    except Exception:
        pass
    for base, size in (CODE, SRAM, PPB):
        uc.mem_map(base, size, UC_PROT_ALL)
    uc.mem_map(0x40000000, 0x10000, UC_PROT_ALL)
    uc.mem_map(0x40010000, 0x4000, UC_PROT_ALL)
    uc.mem_map(EXCRET_PAGE, 0x1000, UC_PROT_ALL)
    uc.mem_write(EXCRET_PAGE, b'\x42\xbe' * 0x800)      # BKPT #0x42 everywhere
    wfi_addrs, unmask_addrs = [], []
    with open(path, 'rb') as f:
        elf = ELFFile(f)
        for seg in elf.iter_segments():
            if seg['p_type'] == 'PT_LOAD' and seg['p_filesz']:
                uc.mem_write(seg['p_paddr'], seg.data())
        md = Cs(CS_ARCH_ARM, CS_MODE_THUMB | CS_MODE_MCLASS)
        for sec in elf.iter_sections():                # find WFI instructions in code
            if sec['sh_flags'] & 0x4 and sec['sh_type'] != 'SHT_NOBITS':
                for i in md.disasm(sec.data(), sec['sh_addr']):
                    if i.mnemonic == 'wfi':
                        wfi_addrs.append(i.address)
                    elif i.mnemonic.startswith('cpsie') or (i.mnemonic == 'msr' and 'primask' in i.op_str):
                        unmask_addrs.append(i.address + i.size)   # stop right after unmasking
    sp, pc = struct.unpack('<II', bytes(uc.mem_read(0, 8)))
    st = {'exit': None, 'cycles': 0, 'wfi': False, 'active': []}
    if '--trace-reset' in argv:
        print(f'cm-run: reset: SP <- 0x{sp:08x}, vector[1] = 0x{pc:08x} '
              f'(bit0={pc & 1}), PC <- 0x{pc & ~1:08x}', file=sys.stderr)
    if not pc & 1:
        print(f'cm-run: reset vector 0x{pc:08x} has bit0 = 0 -> INVSTATE UsageFault', file=sys.stderr)
        return 139

    # ---------------- NVIC ----------------
    nvic = {'en': [0] * 8, 'pend': [0] * 8, 'prigroup': 0, 'ipr': {}, 'st_pend': False, 'shpr3': 0}
    prio_mask = (0xFF << (8 - prio_bits)) & 0xFF

    def pend(irq):
        nvic['pend'][irq // 32] |= 1 << (irq % 32)

    def nvic_write(uc_, access, addr, size, value, _):
        off = addr - 0xE000E000
        if 0x100 <= off < 0x120 and size == 4:
            nvic['en'][(off - 0x100) // 4] |= value
        elif 0x180 <= off < 0x1A0 and size == 4:
            nvic['en'][(off - 0x180) // 4] &= ~value
        elif 0x200 <= off < 0x220 and size == 4:
            nvic['pend'][(off - 0x200) // 4] |= value
        elif 0x280 <= off < 0x2A0 and size == 4:
            nvic['pend'][(off - 0x280) // 4] &= ~value
        elif 0x400 <= off < 0x4F0:
            for i, b in enumerate(value.to_bytes(4, 'little')[:size]):
                nvic['ipr'][off - 0x400 + i] = b & prio_mask
        elif off == 0xD0C and size == 4 and (value >> 16) == 0x05FA:
            nvic['prigroup'] = (value >> 8) & 7
        elif off == 0xD04 and size == 4:                 # ICSR: PENDSTSET / PENDSTCLR
            if value & (1 << 26):
                nvic['st_pend'] = True
            if value & (1 << 25):
                nvic['st_pend'] = False
        elif 0xD20 <= off < 0xD24:                       # SHPR3 (SysTick: bits 31:24)
            for i, b in enumerate(value.to_bytes(4, 'little')[:size]):
                k = 8 * (off - 0xD20 + i)
                nvic['shpr3'] = (nvic['shpr3'] & ~(0xFF << k)) | ((b & prio_mask) << k)

    def nvic_read(uc_, access, addr, size, value, _):
        off = addr - 0xE000E000
        word = None
        if 0x100 <= off < 0x120 or 0x180 <= off < 0x1A0:
            word = nvic['en'][((off - 0x100) % 0x80) // 4]
        elif 0x200 <= off < 0x220 or 0x280 <= off < 0x2A0:
            word = nvic['pend'][((off - 0x200) % 0x80) // 4]
        elif 0x300 <= off < 0x320:
            word = 0
        elif off == 0xD0C:
            word = 0xFA050000 | (nvic['prigroup'] << 8)
        elif off == 0xD04:
            word = (1 << 26) if nvic['st_pend'] else 0
        elif 0xD20 <= off < 0xD24:
            word = nvic['shpr3']
        if word is not None:
            uc_.mem_write(addr & ~3, struct.pack('<I', word & 0xFFFFFFFF))
        elif 0x400 <= off < 0x4F0:
            base = off & ~3
            uc_.mem_write(0xE000E000 + base, bytes(nvic['ipr'].get(base - 0x400 + i, 0) for i in range(4)))

    # ---------------- UART0 ----------------
    uart = {'ctrl': 0, 'state': 0, 'int': 0, 'rx': 0, 'last_rx': -rx_gap}
    rxq = queue.Queue()

    def uart_write(uc_, access, addr, size, value, _):
        off = addr - UART0
        if off == 0x00:
            sys.stdout.write(chr(value & 0xFF))
            sys.stdout.flush()
        elif off == 0x08:
            uart['ctrl'] = value
        elif off == 0x0C:
            uart['int'] &= ~value

    def uart_read(uc_, access, addr, size, value, _):
        off = addr - UART0
        if off == 0x00:
            word = uart['rx']
            uart['state'] &= ~2                      # reading DATA clears RXFULL
        elif off == 0x04:
            word = uart['state']                     # TXFULL (bit0) never set
        elif off == 0x08:
            word = uart['ctrl']
        elif off == 0x0C:
            word = uart['int']
        else:
            return
        uc_.mem_write(addr & ~3, struct.pack('<I', word))

    def uart_tick():
        if uart['state'] & 2 or rxq.empty() or st['cycles'] - uart['last_rx'] < rx_gap:
            return
        if not uart['ctrl'] & 2:                     # RXEN
            return
        uart['rx'] = rxq.get()
        uart['state'] |= 2
        uart['last_rx'] = st['cycles']
        if uart['ctrl'] & 8:                         # RXINTEN
            uart['int'] |= 2
            pend(0)

    if stdin_mode:
        def reader():
            while True:
                b = sys.stdin.buffer.read(1)
                if not b:
                    return
                rxq.put(b[0])
        threading.Thread(target=reader, daemon=True).start()

    # ---------------- Timer0 ----------------
    tim = {'ctrl': 0, 'value': 0, 'reload': 0, 'int': 0}

    def tim_write(uc_, access, addr, size, value, _):
        off = addr - TIMER0
        if off == 0x00:
            tim['ctrl'] = value
        elif off == 0x04:
            tim['value'] = value
        elif off == 0x08:
            tim['reload'] = value
            tim['value'] = value                     # RELOAD write also sets VALUE
        elif off == 0x0C:
            tim['int'] &= ~value

    def tim_read(uc_, access, addr, size, value, _):
        off = addr - TIMER0
        word = {0x00: tim['ctrl'], 0x04: tim['value'], 0x08: tim['reload'], 0x0C: tim['int']}.get(off)
        if word is not None:
            uc_.mem_write(addr & ~3, struct.pack('<I', word & 0xFFFFFFFF))

    tim1 = {'ctrl': 0, 'value': 0, 'reload': 0, 'int': 0}
    t1_stops_in_wfi = '--timer1-stops-in-wfi' in argv

    def tim1_write(uc_, access, addr, size, value, _):
        off = addr - TIMER1
        if off == 0x00:
            tim1['ctrl'] = value
        elif off == 0x04:
            tim1['value'] = value
        elif off == 0x08:
            tim1['reload'] = value
            tim1['value'] = value
        elif off == 0x0C:
            tim1['int'] &= ~value

    def tim1_read(uc_, access, addr, size, value, _):
        off = addr - TIMER1
        word = {0x00: tim1['ctrl'], 0x04: tim1['value'], 0x08: tim1['reload'], 0x0C: tim1['int']}.get(off)
        if word is not None:
            uc_.mem_write(addr & ~3, struct.pack('<I', word & 0xFFFFFFFF))

    def tim1_advance(n):
        if not tim1['ctrl'] & 1:
            return
        period = tim1['reload'] + 1
        if n <= tim1['value']:
            tim1['value'] -= n
            return
        n -= tim1['value'] + 1
        tim1['value'] = tim1['reload'] - (n % period)
        tim1['int'] |= 1

    def tim_advance(n):
        if not tim['ctrl'] & 1:
            return
        while n > 0:
            if n <= tim['value']:
                tim['value'] -= n
                return
            n -= tim['value'] + 1
            tim['value'] = tim['reload']
            tim['int'] |= 1
            if tim['ctrl'] & 8:
                pend(8)

    def next_event():
        cand = [CHUNK]
        if tim['ctrl'] & 1:
            cand.append(tim['value'] + 1)
        if not rxq.empty():
            cand.append(max(1, rx_gap - (st['cycles'] - uart['last_rx'])))
        return max(1, min(cand))

    # ---------------- exceptions ----------------
    REGS = (UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3, UC_ARM_REG_R12, UC_ARM_REG_LR)

    def levels():                                    # interrupt lines are level-sensitive:
        if uart['int'] & 2 and uart['ctrl'] & 8:     # while the source flag is set, the
            pend(0)                                  # NVIC pending bit is set again
        if tim['int'] & 1 and tim['ctrl'] & 8:
            pend(8)

    def take_irq():
        levels()
        if not irq_on or uc.reg_read(UC_ARM_REG_PRIMASK) & 1:
            return
        best = None
        if nvic['st_pend']:                          # SysTick = exception 15 = "IRQ -1";
            best = ((nvic['shpr3'] >> 24) & 0xFF, -1)  # checked first: wins a priority tie
        for w in range(8):
            act = nvic['pend'][w] & nvic['en'][w]
            while act:
                bit = act & -act
                irq = 32 * w + bit.bit_length() - 1
                pr = nvic['ipr'].get(irq, 0)
                if best is None or pr < best[0]:
                    best = (pr, irq)
                act &= ~bit
        if best is None:
            return
        pr, irq = best
        if st['active'] and pr >= st['active'][-1][0]:
            return
        if irq < 0:
            nvic['st_pend'] = False
        else:
            nvic['pend'][irq // 32] &= ~(1 << (irq % 32))
        sp_ = uc.reg_read(UC_ARM_REG_SP)
        xpsr = uc.reg_read(UC_ARM_REG_XPSR)
        pad = 4 if sp_ % 8 else 0
        sp_ -= pad + 32
        ret_pc = uc.reg_read(UC_ARM_REG_PC) & ~1
        frame = [uc.reg_read(r) for r in REGS] + [ret_pc, (xpsr & ~0x200) | (0x200 if pad else 0) | 0x01000000]
        uc.mem_write(sp_, struct.pack('<8I', *frame))
        uc.reg_write(UC_ARM_REG_SP, sp_)
        uc.reg_write(UC_ARM_REG_LR, 0xFFFFFFF1 if st['active'] else 0xFFFFFFF9)
        vec = struct.unpack('<I', bytes(uc.mem_read(4 * (16 + irq), 4)))[0]
        st['active'].append((pr, irq))
        uc.reg_write(UC_ARM_REG_PC, vec | 1)

    def exc_return(uc_):
        sp_ = uc_.reg_read(UC_ARM_REG_SP)
        frame = struct.unpack('<8I', bytes(uc_.mem_read(sp_, 32)))
        for r, v in zip(REGS, frame[:6]):
            uc_.reg_write(r, v)
        xpsr = frame[7]
        uc_.reg_write(UC_ARM_REG_SP, sp_ + 32 + (4 if xpsr & 0x200 else 0))
        uc_.reg_write(UC_ARM_REG_XPSR, (uc_.reg_read(UC_ARM_REG_XPSR) & 0x0FFFFFFF) | (xpsr & 0xF0000000))
        if st['active']:
            st['active'].pop()
        uc_.reg_write(UC_ARM_REG_PC, frame[6] | 1)

    def on_intr(uc_, intno, _):
        cur = uc_.reg_read(UC_ARM_REG_PC)
        if cur >= EXCRET_PAGE:
            exc_return(uc_)
            uc_.emu_stop()
            return
        insn = struct.unpack('<H', bytes(uc_.mem_read(cur, 2)))[0]
        if insn == 0xBEAB:            # BKPT 0xAB: semihosting
            op, a1 = uc_.reg_read(UC_ARM_REG_R0), uc_.reg_read(UC_ARM_REG_R1)
            if op == 0x03:
                sys.stdout.write(chr(uc_.mem_read(a1, 1)[0]))
            elif op == 0x04:
                s = b''
                while True:
                    c = bytes(uc_.mem_read(a1 + len(s), 1))
                    if c == b'\0':
                        break
                    s += c
                sys.stdout.write(s.decode('utf-8', 'replace'))
            elif op == 0x18:
                st['exit'] = 0 if a1 == 0x20026 else 1
                uc_.emu_stop()
                return
            sys.stdout.flush()
            uc_.reg_write(UC_ARM_REG_PC, (cur + 2) | 1)
            return
        print(f'cm-run: exception {intno} at pc=0x{cur:08x}', file=sys.stderr)
        st['exit'] = 139
        uc_.emu_stop()

    def raz(uc_, access, addr, size, value, _):
        uc_.mem_write(addr & ~3, bytes(4))

    uc.hook_add(UC_HOOK_MEM_READ, raz, begin=0x40010000, end=0x40013FFF)
    uc.hook_add(UC_HOOK_MEM_WRITE, uart_write, begin=UART0, end=UART0 + 0x1F)
    uc.hook_add(UC_HOOK_MEM_READ, uart_read, begin=UART0, end=UART0 + 0x1F)
    uc.hook_add(UC_HOOK_MEM_WRITE, tim_write, begin=TIMER0, end=TIMER0 + 0x0F)
    uc.hook_add(UC_HOOK_MEM_READ, tim_read, begin=TIMER0, end=TIMER0 + 0x0F)
    uc.hook_add(UC_HOOK_MEM_WRITE, tim1_write, begin=TIMER1, end=TIMER1 + 0x0F)
    uc.hook_add(UC_HOOK_MEM_READ, tim1_read, begin=TIMER1, end=TIMER1 + 0x0F)
    uc.hook_add(UC_HOOK_MEM_WRITE, nvic_write, begin=0xE000E100, end=0xE000ED23)
    uc.hook_add(UC_HOOK_MEM_READ, nvic_read, begin=0xE000E100, end=0xE000ED23)
    uc.hook_add(UC_HOOK_INTR, on_intr)

    def on_wfi(uc_, addr, size, _):
        st['wfi'] = True                               # do not let the core halt:
        uc_.reg_write(UC_ARM_REG_PC, (addr + 2) | 1)  # skip it and sleep in the loop
        uc_.emu_stop()

    for a in wfi_addrs:
        uc.hook_add(UC_HOOK_CODE, on_wfi, begin=a, end=a)

    def on_unmask(uc_, addr, size, _):
        if st.get('resume') == addr:                 # we stopped here once already: go on
            st['resume'] = None
            return
        if nvic['st_pend'] or any(nvic['pend'][w] & nvic['en'][w] for w in range(8)):
            st['resume'] = addr
            uc_.emu_stop()                           # let take_irq() run before the next instruction

    for a in unmask_addrs:
        uc.hook_add(UC_HOOK_CODE, on_unmask, begin=a, end=a)
    uc.reg_write(UC_ARM_REG_SP, sp)
    uc.reg_write(UC_ARM_REG_LR, 0xFFFFFFFF)
    pc_now = pc | 1

    while st['exit'] is None and st['cycles'] < limit:
        n = next_event()
        if st['wfi'] and (nvic['st_pend'] or any(nvic['pend'][w] & nvic['en'][w] for w in range(8))):
            st['wfi'] = False                        # a pending enabled IRQ wakes WFI (even with PRIMASK = 1)
            n = 1
        if not st['wfi']:
            try:
                uc.emu_start(pc_now, 0xFFFFFFFF, count=n)
            except UcError as e:
                cur = uc.reg_read(UC_ARM_REG_PC)
                print(f'cm-run: {e} at pc=0x{cur:08x} (fault)', file=sys.stderr)
                return 139
        st['cycles'] += n
        if not (st['wfi'] and t1_stops_in_wfi):
            tim1_advance(n)
        tim_advance(n)
        uart_tick()
        take_irq()
        pc_now = uc.reg_read(UC_ARM_REG_PC) | 1
        if st['wfi'] and not (tim['ctrl'] & 1) and rxq.empty() and not stdin_mode:
            break                                    # asleep and nothing can wake us
    if st['exit'] is None:
        print('cm-run: instruction limit reached (still running)', file=sys.stderr)
        return 124
    return st['exit']


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
