/* lab_sgemm_ref.c — double pontosságú korrektségi referencia (a057). */
#include "lab_sgemm.h"

void lab_sgemm_ref(size_t n, const float *A, const float *B, double *C)
{
    for (size_t i = 0; i < n; ++i) {
        for (size_t j = 0; j < n; ++j) {
            double acc = 0.0;
            for (size_t k = 0; k < n; ++k)   /* ugyanaz a k-sorrend, mint a modulban */
                acc += (double)A[i * n + k] * (double)B[k * n + j];
            C[i * n + j] = acc;
        }
    }
}
