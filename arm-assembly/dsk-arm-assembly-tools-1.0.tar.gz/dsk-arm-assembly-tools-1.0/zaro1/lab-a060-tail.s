// lab-a060-tail.s — A64 ISA, AArch64 Linux; SZÁNDÉKOSAN HIBÁS farokkezelés (3. feladat)
// void lab_add_f32(float *c, const float *a, size_t n): c[i] += a[i], 0 <= i < n
// Előfeltétel: c és a legalább n elemű, nem fedik át egymást; n = 0 esetén nincs hozzáférés.
// Levélfüggvény: nem hív mást, keretet nem épít, és csak caller-saved regisztereket
// (x0–x6, x9, v0, v1) használ, ezért nincs megőrzendő állapota.
    .text
    .global lab_add_f32
    .type   lab_add_f32, %function
lab_add_f32:
    bic     x4, x2, #3              // x4 = 4 * floor(n/4): a vektoros rész vége (elemben)
    mov     x6, #0                  // i = 0
    cbz     x4, .Ltail              // n < 4: nincs vektoros rész
.Lvec:
    lsl     x9, x6, #2              // bájteltolás = 4 * i
    ldr     q0, [x0, x9]
    ldr     q1, [x1, x9]
    fadd    v0.4s, v0.4s, v1.4s     // c[i..i+3] += a[i..i+3]
    str     q0, [x0, x9]
    add     x6, x6, #4
    cmp     x6, x4
    b.lo    .Lvec
.Ltail:
    and     x5, x2, #3              // x5 = n mod 4: a farok hossza
    cbz     x5, .Ldone
.Ltail_loop:
    ldr     s0, [x0, x6, lsl #2]
    ldr     s1, [x1, x6, lsl #2]
    fadd    s0, s0, s1              // c[i] += a[i]
    str     s0, [x0, x6, lsl #2]
    sub     x5, x5, #1
    cbnz    x5, .Ltail_loop
.Ldone:
    ret
    .size   lab_add_f32, . - lab_add_f32

    .section .note.GNU-stack,"",%progbits
