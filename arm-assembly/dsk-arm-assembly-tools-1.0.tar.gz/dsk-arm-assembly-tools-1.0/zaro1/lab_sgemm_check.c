/* lab_sgemm_check.c — az a057 numerikus szerződésének ellenőrzője. */
#include <float.h>
#include <math.h>
#include <stdint.h>
#include "lab_sgemm_check.h"

int lab_fpcr_ok(void)
{
    uint64_t fpcr;
    __asm__ volatile("mrs %0, fpcr" : "=r"(fpcr));
    const uint64_t mask = (3u << 22)    /* RMode: 00 = RNE        */
                        | (1u << 24)    /* FZ: nincs flush-to-zero */
                        | (1u << 25)    /* DN: nincs default NaN   */
                        | 0x7u;         /* NEP, AH, FIZ            */
    return (fpcr & mask) == 0;
}

static double abs_sum(size_t n, const float *A, const float *B, size_t i, size_t j)
{
    double s = 0.0;
    for (size_t k = 0; k < n; ++k)
        s += fabs((double)A[i * n + k]) * fabs((double)B[k * n + j]);
    return s;
}

int lab_sgemm_in_contract(size_t n, const float *A, const float *B)
{
    for (size_t e = 0; e < n * n; ++e)
        if (!isfinite(A[e]) || !isfinite(B[e]))
            return 0;
    /* A float*float szorzatok double-ben pontosak (24 + 24 <= 53 bit); n nemnegatív
     * tag összegének hibája <= gamma_{n-1} * pontos összeg. A (1 + g) szorzás saját
     * kerekítésével együtt gamma_{n+2} fedi: számított * (1 + g) <= LAB_SMAX esetén a
     * pontos összeg biztosan <= LAB_SMAX. */
    const double nu = (double)(n + 2) * 0x1p-53;
    const double g = nu / (1.0 - nu);
    for (size_t i = 0; i < n; ++i)
        for (size_t j = 0; j < n; ++j)
            if (!(abs_sum(n, A, B, i, j) * (1.0 + g) <= LAB_SMAX))
                return 0;
    return 1;
}

int lab_sgemm_check(size_t n, const float *A, const float *B,
                    const float *C, const double *R, size_t *bad)
{
    for (size_t i = 0; i < n; ++i)
        for (size_t j = 0; j < n; ++j) {
            size_t e = i * n + j;
            double c = (double)C[e];
            double bound = LAB_ATOL + LAB_RTOL * abs_sum(n, A, B, i, j);
            /* A !(x <= y) alak NaN-ra is igaz: a NaN-os elem FAIL. */
            if (!isfinite(c) || !(fabs(c - R[e]) <= bound)) {
                *bad = e;
                return 1;
            }
        }
    return 0;
}
