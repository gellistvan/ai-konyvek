/* lab-a060-tail-test.c — a lab_add_f32 tesztje n = 0..12-re, független C-orákulummal */
#include <stdio.h>
#include <stddef.h>

void lab_add_f32(float *c, const float *a, size_t n);

int main(void)
{
    int fails = 0;
    for (size_t n = 0; n <= 12; n++) {
        float c[12], a[12], want[12];
        for (size_t i = 0; i < n; i++) {
            c[i] = (float)(100 * i);          /* kis egészek: a float-összeg pontos */
            a[i] = (float)(i + 1);
            want[i] = c[i] + a[i];
        }
        lab_add_f32(n ? c : NULL, n ? a : NULL, n);
        size_t bad = n;
        for (size_t i = 0; i < n && bad == n; i++)
            if (c[i] != want[i]) bad = i;
        if (bad == n)
            printf("n=%2zu (n mod 4 = %zu) OK\n", n, n % 4);
        else
            printf("n=%2zu (n mod 4 = %zu) HIBA: c[%zu] = %g, elvárt %g\n",
                   n, n % 4, bad, (double)c[bad], (double)want[bad]);
        fails += bad != n;
    }
    puts(fails ? "TAIL: FAIL" : "TAIL: PASS");
    return fails != 0;
}
