/* lab_sgemm_test.c — korrektségi teszthajtó az a057 numerikus szerződésével. */
#define _DEFAULT_SOURCE
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include "lab_sgemm.h"
#include "lab_sgemm_check.h"

/* Őrzött puffer: [őrbájtok | adat | PROT_NONE védőlap]. Az adat vége pontosan
   a védőlapnál ér véget, így a túlindexelt olvasás vagy írás laphibát okoz;
   az adat előtti írást az őrbájtok megváltozása mutatja. */
#define LAB_GUARD_BYTE 0xA5
typedef struct { unsigned char *map, *data; size_t maplen, front; } guarded_t;

static float *guarded_alloc(guarded_t *g, size_t bytes)
{
    size_t pg = (size_t)sysconf(_SC_PAGESIZE);
    size_t body = (64 + bytes + pg - 1) / pg * pg;   /* legalább 64 őrbájt */
    g->maplen = body + pg;
    g->map = mmap(NULL, g->maplen, PROT_READ | PROT_WRITE,
                  MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (g->map == MAP_FAILED) { perror("mmap"); exit(2); }
    if (mprotect(g->map + body, pg, PROT_NONE)) { perror("mprotect"); exit(2); }
    g->front = body - bytes;
    g->data = g->map + g->front;
    memset(g->map, LAB_GUARD_BYTE, g->front);
    return (float *)(void *)g->data;
}

static int guard_intact(const guarded_t *g)
{
    for (size_t i = 0; i < g->front; ++i)
        if (g->map[i] != LAB_GUARD_BYTE) return 0;
    return 1;
}

static void guarded_free(guarded_t *g) { munmap(g->map, g->maplen); }

typedef enum {
    CONTENT_PATTERN, CONTENT_ZERO, CONTENT_ONES, CONTENT_MINUS_ONES,
    CONTENT_IDENTITY, CONTENT_RANDOM, CONTENT_LARGE, CONTENT_NEAR_MAX,
    CONTENT_OVERFLOW, CONTENT_FMA_EDGE, CONTENT_HALF_EDGE
} content_t;

static void fill_content(float *A, float *B, size_t n, content_t kind)
{
    size_t nelem = n * n;
    uint32_t seed = 0x2545F491u;
    for (size_t j = 0; j < nelem; ++j) {
        switch (kind) {
        case CONTENT_ZERO:       A[j] = 0.0f;  B[j] = 0.0f;  break;
        case CONTENT_ONES:       A[j] = 1.0f;  B[j] = 1.0f;  break;
        case CONTENT_MINUS_ONES: A[j] = -1.0f; B[j] = -1.0f; break;
        case CONTENT_IDENTITY:   /* B = I, tehát C = A */
            A[j] = (float)((int)(j % 17) - 8) / 8.0f;
            B[j] = (j / n == j % n) ? 1.0f : 0.0f;
            break;
        case CONTENT_RANDOM:     /* LCG, [-1, 1) egyenletes, rögzített mag */
            seed = seed * 1664525u + 1013904223u;
            A[j] = ((float)(seed >> 8) / (float)(1u << 24)) * 2.0f - 1.0f;
            seed = seed * 1664525u + 1013904223u;
            B[j] = ((float)(seed >> 8) / (float)(1u << 24)) * 2.0f - 1.0f;
            break;
        case CONTENT_LARGE:      /* nagyérték-teszt: n*1e12 << FLT_MAX */
            A[j] = 1.0e6f; B[j] = (j % 2) ? -1.0e6f : 1.0e6f;
            break;
        case CONTENT_NEAR_MAX:   /* szerződésen belül, a határ közelében: egynemű előjel,
                                    s_ij = n * A = 0x1.fffffcp126 <= FLT_MAX/2 */
            A[j] = (float)(0x1.fffffcp126 / (double)n); B[j] = 1.0f;
            break;
        case CONTENT_OVERFLOW:   /* szándékosan a szerződésen kívül */
            A[j] = 1.0e20f; B[j] = 1.0e20f;
            break;
        case CONTENT_FMA_EDGE:   /* n = 4: s_00 = 0x1.fffffd18p127 < FLT_MAX, mégis +Inf
                                    (V8 határ-ellenpélda); a szerződés elutasítja */
            A[j] = (j == 0) ? 0x1.fffffap127f : (j < n) ? 0x1.08p103f : 0.0f;
            B[j] = 1.0f;
            break;
        case CONTENT_HALF_EDGE:  /* n = 2: s_00 = FLT_MAX/2 + 1 > LAB_SMAX, de double-ben
                                    FLT_MAX/2 + 1 == FLT_MAX/2; a szűrő elutasítja */
            A[j] = (j == 0) ? FLT_MAX / 2 : (j == 1) ? 1.0f : 0.0f;
            B[j] = (j % n == 0) ? 1.0f : 0.0f;
            break;
        case CONTENT_PATTERN:
        default:                 /* int-kasztolás a kivonás előtt (size_t!) */
            A[j] = (float)((int)(j % 17) - 8) / 8.0f;
            B[j] = (float)((int)(j % 13) - 6) / 6.0f;
            break;
        }
    }
}

static const char *content_name[] = {
    "pattern", "zero", "ones", "minus-ones", "identity", "random", "large", "near-max",
    "overflow", "fma-edge", "half-edge"
};

/* A modul számítási modellje (a057, 3. pont): c_ij = 0-ról, k-sorrendben
   float FMA. A szerződésen kívüli esetek dokumentált elvárása ez a modell. */
static void sgemm_fma_model(size_t n, const float *A, const float *B, float *M)
{
    for (size_t i = 0; i < n; ++i)
        for (size_t j = 0; j < n; ++j) {
            float c = 0.0f;
            for (size_t k = 0; k < n; ++k)
                c = fmaf(A[i * n + k], B[k * n + j], c);
            M[i * n + j] = c;
        }
}

/* Érvényes eset: őrzött A, B, C; C előre NaN-bájtokkal (0xFF) töltve, így a
   meg nem írt elem is FAIL. Ellenőrzés: rc, A és B változatlansága, őrbájtok,
   a bemenet osztályozása (szerződésen belül/kívül), majd szerződésen belül a
   numerikus szerződés, kívül a float-FMA modellel való bitre egyezés. */
static int run_case(size_t n, content_t kind)
{
    size_t bytes = n * n * sizeof(float);
    guarded_t gA, gB, gC;
    float *A = guarded_alloc(&gA, bytes), *B = guarded_alloc(&gB, bytes);
    float *C = guarded_alloc(&gC, bytes);
    float  *A0 = malloc(bytes ? bytes : 1), *B0 = malloc(bytes ? bytes : 1);
    double *R = malloc(n ? n * n * sizeof(double) : 1);
    float  *M = malloc(bytes ? bytes : 1);
    if (!A0 || !B0 || !R || !M) { perror("malloc"); exit(2); }
    int want_in = kind != CONTENT_OVERFLOW && kind != CONTENT_FMA_EDGE
                  && kind != CONTENT_HALF_EDGE;

    fill_content(A, B, n, kind);
    memcpy(A0, A, bytes); memcpy(B0, B, bytes);
    memset(C, 0xFF, bytes);
    int in_contract = lab_sgemm_in_contract(n, A, B);

    int rc = lab_sgemm(n, A, B, C);
    lab_sgemm_ref(n, A, B, R);

    size_t bad = 0, ninf = 0;
    const char *why = NULL;
    if (in_contract != want_in) why = "osztályozás";
    else if (rc != LAB_SGEMM_OK) why = "rc";
    else if (memcmp(A, A0, bytes) || memcmp(B, B0, bytes)) why = "bemenet módosult";
    else if (!guard_intact(&gA) || !guard_intact(&gB) || !guard_intact(&gC)) why = "őrbájt";
    else if (in_contract) {
        if (lab_sgemm_check(n, A, B, C, R, &bad)) why = "numerikus";
    } else {
        /* Szerződésen kívül nincs numerikus elfogadás; dokumentált elvárás a
           float-FMA modell bitre pontos eredménye (overflow: minden elem +Inf,
           fma-edge: a 0. sor +Inf, a többi 0). */
        sgemm_fma_model(n, A, B, M);
        for (size_t e = 0; e < n * n && !why; ++e)
            if (memcmp(&C[e], &M[e], sizeof(float))) {
                bad = e;
                why = "eltér a float-FMA modelltől";
            }
        for (size_t e = 0; e < n * n; ++e)
            ninf += isinf(C[e]) != 0;
    }
    printf("[%s] n=%4zu  rc=%2d  %s", content_name[kind], n, rc, why ? "FAIL" : "OK");
    if (!want_in && !why) printf(" (szerződésen kívül, +Inf elemek: %zu)", ninf);
    if (why && n) printf(" (%s, első hibás elem: %zu, asm=%g ref=%g)", why, bad,
                         (double)C[bad], R[bad]);
    putchar('\n');
    guarded_free(&gA); guarded_free(&gB); guarded_free(&gC);
    free(A0); free(B0); free(R); free(M);
    return why != NULL;
}

/* Érvénytelen bemenet: a C puffert (ha van) speciális bitmintákkal töltjük
   (-0.0, NaN-payload, Inf), és a teljes kimeneti tartomány bájtjait az
   őrbájtokkal együtt memcmp-pel vetjük össze a hívás előtti másolattal. */
static int run_invalid_case(size_t n, int a_null, int b_null, int c_null,
                            const char *label)
{
    static const uint32_t pat[] = { 0x80000000u, 0x7fc12345u, 0xffa00001u,
                                    0x7f800000u, 0x449a5000u, 0x00000001u };
    guarded_t g;
    float *buf = guarded_alloc(&g, 16 * sizeof(float));
    for (size_t e = 0; e < 16; ++e)
        memcpy(&buf[e], &pat[e % 6], sizeof(uint32_t));
    size_t len = g.front + 16 * sizeof(float);
    unsigned char *before = malloc(len);
    if (!before) { perror("malloc"); exit(2); }
    memcpy(before, g.map, len);

    float dummy[4] = { 1, 2, 3, 4 };
    int rc = lab_sgemm(n, a_null ? NULL : dummy, b_null ? NULL : dummy,
                       c_null ? NULL : buf);
    int unchanged = memcmp(before, g.map, len) == 0;
    int ok = rc == LAB_SGEMM_EINVAL && unchanged;
    printf("invalid[%s] n=%zu  rc=%2d  %s\n", label, n, rc, ok ? "OK" : "FAIL");
    free(before); guarded_free(&g);
    return !ok;
}

/* Az ellenőrző önellenőrzése, a vizsgált modultól függetlenül: a referencia
   float-ra kerekített eredményének át kell mennie, a szándékosan elrontott
   példányoknak pedig le kell bukniuk. */
static int run_checker_selftest(void)
{
    enum { N = 17 };
    const size_t n = N;
    float A[N * N], B[N * N], C[N * N], D[N * N];
    double R[N * N];
    size_t bad;
    fill_content(A, B, n, CONTENT_RANDOM);
    lab_sgemm_ref(n, A, B, R);
    for (size_t e = 0; e < n * n; ++e) C[e] = (float)R[e];
    int fail = lab_sgemm_check(n, A, B, C, R, &bad) != 0;
    const float inject[] = { NAN, INFINITY, -INFINITY, 0.5f };
    const char *name[] = { "NaN", "+Inf", "-Inf", "+0.5" };
    for (int t = 0; t < 4; ++t) {
        memcpy(D, C, sizeof C);
        D[5 * n + 11] = (t == 3) ? D[5 * n + 11] + inject[t] : inject[t];
        int caught = lab_sgemm_check(n, A, B, D, R, &bad) && bad == 5 * n + 11;
        printf("selftest[%s beinjektálva] %s\n", name[t],
               caught ? "lebukott: OK" : "NEM bukott le: FAIL");
        fail |= !caught;
    }
    return fail;
}

int main(void)
{
    int fail = 0;
    setvbuf(stdout, NULL, _IOLBF, 0);   /* összeomláskor is látszik az utolsó sor */
    if (!lab_fpcr_ok()) { puts("FPCR nem a szerződés szerinti (RNE, FZ=0, DN=0)"); return 2; }

    fail |= run_checker_selftest();

    /* 1. réteg: határesetek és nagyobb méretek, mintázott tartalommal. */
    const size_t sizes[] = { 0, 1, 2, 3, 5, 7, 8, 16, 17, 63, 64, 65, 128, 256 };
    for (size_t i = 0; i < sizeof sizes / sizeof sizes[0]; ++i)
        fail |= run_case(sizes[i], CONTENT_PATTERN);

    /* 2. réteg: kis méretek, további farok-/blokkesetek. */
    const size_t small[] = { 4, 6, 12 };
    for (size_t i = 0; i < sizeof small / sizeof small[0]; ++i)
        fail |= run_case(small[i], CONTENT_PATTERN);

    /* 3. réteg: hét speciális tartalom n = 32 és 64 mellett (köztük a
       FLT_MAX/2-közeli near-max), véletlen tartalom n = 128 és 256 mellett is. */
    const size_t special[] = { 32, 64 };
    for (size_t i = 0; i < 2; ++i)
        for (content_t k = CONTENT_ZERO; k <= CONTENT_NEAR_MAX; ++k)
            fail |= run_case(special[i], k);
    fail |= run_case(128, CONTENT_RANDOM);
    fail |= run_case(256, CONTENT_RANDOM);

    /* Szerződésen kívüli esetek: az osztályozásnak el kell utasítania őket,
       a kimenet dokumentált elvárása a float-FMA modell. */
    fail |= run_case(8, CONTENT_OVERFLOW);
    fail |= run_case(4, CONTENT_FMA_EDGE);
    fail |= run_case(2, CONTENT_HALF_EDGE);

    /* Érvénytelen bemenetek. n = 2^31: n*n*4 már nem fér el 64 biten. */
    fail |= run_invalid_case(1, 1, 0, 0, "A=NULL");
    fail |= run_invalid_case(1, 0, 1, 0, "B=NULL");
    fail |= run_invalid_case(1, 0, 0, 1, "C=NULL");
    fail |= run_invalid_case((size_t)1 << 31, 0, 0, 0, "n-overflow");

    puts(fail ? "TESTS: FAIL" : "TESTS: PASS");
    return fail;
}
