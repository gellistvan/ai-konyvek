// lab-sum-a64.s — A64, AAPCS64: x0 = p, w1 = n; visszatérés w0-ban
    .text
    .global lab_sum_u32
    .type   lab_sum_u32, %function
lab_sum_u32:
    mov     w2, #0                // összeg: caller-saved w2, nincs mentés
    cbz     w1, 2f
1:  ldr     w3, [x0], #4          // post-index: p++
    add     w2, w2, w3
    subs    w1, w1, #1
    b.ne    1b
2:  mov     w0, w2
    ret                           // visszatérés az X30-ban kapott címre
    .size   lab_sum_u32, . - lab_sum_u32
    .section .note.GNU-stack,"",%progbits
