/* lab-abi-call32.h — AAPCS32 ABI-teszthívó Thumb-2-re (a lab_abi_call párja). */
#ifndef LAB_ABI_CALL32_H
#define LAB_ABI_CALL32_H
#include <stdint.h>
typedef void (*lab_abi_fn32)(void);
/* hibamaszk: bit 0..7 = R4..R11 sérült, bit 8 = SP nem a hívás előtti */
#define LAB_ABI32_R4  (1u << 0)
#define LAB_ABI32_SP  (1u << 8)
#define LAB_ABI32_BUSY (1u << 9)  /* újrabelépés: fn nem hívódott meg */
/* fn(a0, a1) hívása úgy, hogy előtte R4–R11 ismert mintát kap; visszatérés
   után ellenőrzi a mintákat és az SP-t. *result = a hívott R0-ja.
   NEM reentráns: a hívás előtti SP-t egyetlen statikus horgony őrzi;
   egymásba ágyazott hívásnál a belső LAB_ABI32_BUSY-t ad, *result = 0. */
uint32_t lab_abi_call32(lab_abi_fn32 fn, uint32_t a0, uint32_t a1, uint32_t *result);
#endif
