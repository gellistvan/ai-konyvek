/* lab-abi32-neg-test.c — a lab_abi_call32 negatív tesztje: eltolt SP-vel visszatérő
 * hívottak. */
#include <stdint.h>
#include "lab-abi-call32.h"

extern void lab_t32_bad_sp4(void), lab_t32_bad_sp8(void);
uint32_t lab_abi32_outer(lab_abi_fn32 fn, uint32_t *result);

static void sh_call(uint32_t op, const void *arg)
{
    register uint32_t r0 asm("r0") = op;
    register const void *r1 asm("r1") = arg;
    asm volatile ("bkpt 0xab" : "+r"(r0) : "r"(r1) : "memory");
}
static void out(const char *s) { sh_call(0x04u, s); }          /* SYS_WRITE0 */
static void out_hex(uint32_t v)
{
    char b[11] = "0x";
    for (int i = 0; i < 8; i++) b[2 + i] = "0123456789abcdef"[(v >> (28 - 4 * i)) & 0xFu];
    b[10] = '\0';
    out(b);
}

/* result körül őrszavak: a teszthívó csak a középső szót írhatja. */
static int expect(const char *name, lab_abi_fn32 fn)
{
    volatile uint32_t box[3] = { 0xC0DEC0DEu, 0, 0xC0DEC0DEu };
    uint32_t mask = lab_abi32_outer(fn, (uint32_t *)&box[1]);
    int ok = mask == LAB_ABI32_SP && box[1] == 3
          && box[0] == 0xC0DEC0DEu && box[2] == 0xC0DEC0DEu;
    out(name); out(" mask="); out_hex(mask); out(" result="); out_hex(box[1]);
    out(ok ? " OK\n" : " HIBA\n");
    return !ok;
}

int main(void)
{
    int fails = expect("bad_sp4", lab_t32_bad_sp4);
    fails += expect("bad_sp8", lab_t32_bad_sp8);
    out(fails ? "ABI32-NEG: FAIL\n" : "ABI32-NEG: PASS\n");
    sh_call(0x18u, (const void *)(fails ? 0x20023u : 0x20026u)); /* SYS_EXIT */
    return fails;
}
