@ lab-abi32-neg.s — a lab_abi_call32 negatív tesztjei (Thumb-2, Armv7-M)
    .syntax unified
    .thumb
    .text

@ HIBÁS hívottak: szabályosan, BX LR-rel térnek vissza, de eltolt SP-vel.
    .global lab_t32_bad_sp4
    .thumb_func
    .type   lab_t32_bad_sp4, %function
lab_t32_bad_sp4:
    sub     sp, sp, #4
    adds    r0, r0, r1
    bx      lr
    .size   lab_t32_bad_sp4, . - lab_t32_bad_sp4

    .global lab_t32_bad_sp8
    .thumb_func
    .type   lab_t32_bad_sp8, %function
lab_t32_bad_sp8:
    sub     sp, sp, #8
    adds    r0, r0, r1
    bx      lr
    .size   lab_t32_bad_sp8, . - lab_t32_bad_sp8

@ uint32_t lab_abi32_outer(lab_abi_fn32 fn, uint32_t *result)
@ A teszthívó saját hívója: R4–R11-be mintát tölt, meghívja a
@ lab_abi_call32(fn, 1, 2, result)-ot, majd ellenőrzi, hogy a mintái és az
@ SP-je megmaradt. Visszatérés: a teszthívó maszkja, bit 31 = a hívó állapota sérült.
    .global lab_abi32_outer
    .thumb_func
    .type   lab_abi32_outer, %function
lab_abi32_outer:
    push    {r4-r11, lr}          @ 9 regiszter
    sub     sp, sp, #4            @ + 4 bájt: SP 8-ra igazított
    mov     r3, r1                @ result
    mov     r12, r0               @ fn
    ldr     r4,  =0x14141414
    ldr     r5,  =0x15151515
    ldr     r6,  =0x16161616
    ldr     r7,  =0x17171717
    ldr     r8,  =0x18181818
    ldr     r9,  =0x19191919
    ldr     r10, =0x1A1A1A1A
    ldr     r11, =0x1B1B1B1B
    mov     r1, sp
    str     r1, [sp]              @ a saját SP-nk, a keretünk aljára
    mov     r0, r12
    movs    r1, #1
    movs    r2, #2
    bl      lab_abi_call32
    ldr     r1, [sp]
    mov     r2, sp
    cmp     r1, r2                @ a mi SP-nk változatlan?
    bne     9f
    ldr     r1, =0x14141414
    cmp     r4, r1
    bne     9f
    ldr     r1, =0x15151515
    cmp     r5, r1
    bne     9f
    ldr     r1, =0x16161616
    cmp     r6, r1
    bne     9f
    ldr     r1, =0x17171717
    cmp     r7, r1
    bne     9f
    ldr     r1, =0x18181818
    cmp     r8, r1
    bne     9f
    ldr     r1, =0x19191919
    cmp     r9, r1
    bne     9f
    ldr     r1, =0x1A1A1A1A
    cmp     r10, r1
    bne     9f
    ldr     r1, =0x1B1B1B1B
    cmp     r11, r1
    beq     1f
9:  orr     r0, r0, #0x80000000   @ a hívó állapota sérült
1:  add     sp, sp, #4
    pop     {r4-r11, pc}
    .size   lab_abi32_outer, . - lab_abi32_outer
