/* lab-sum.h — a közös C-szerződés mindkét ISA-ra */
#ifndef LAB_SUM_H
#define LAB_SUM_H
#include <stdint.h>
/* p[0..n-1] összege modulo 2^32; n == 0 esetén 0. */
uint32_t lab_sum_u32(const uint32_t *p, uint32_t n);
#endif
