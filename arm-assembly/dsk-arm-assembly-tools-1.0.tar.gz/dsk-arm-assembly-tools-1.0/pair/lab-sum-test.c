/* lab-sum-test.c — közös teszthajtó: ugyanaz a logika A64-en és Thumb-2-n.
 * Csak a platformréteg (kiírás, ABI-teszthívó, kilépés) különbözik. */
#include <stdint.h>
#include "lab-sum.h"

/* ---------- platformréteg ---------- */
#if defined(__aarch64__)
#include <stdio.h>
#include "lab-abi-call.h"
static void out(const char *s) { fputs(s, stdout); }
static uint32_t call_checked(const uint32_t *p, uint32_t n, uint32_t *mask)
{
    uint64_t x0 = 0;
    *mask = (uint32_t)lab_abi_call((lab_abi_fn)lab_sum_u32, (uintptr_t)p, n, 0, 0, 0, 0, &x0);
    return (uint32_t)x0;                      /* uint32_t visszatérés: csak W0 értelmes */
}
static int finish(int fails) { return fails != 0; }
#else
#include "lab-abi-call32.h"
static void sh_call(uint32_t op, const void *arg)
{
    register uint32_t r0 asm("r0") = op;
    register const void *r1 asm("r1") = arg;
    asm volatile ("bkpt 0xab" : "+r"(r0) : "r"(r1) : "memory");
}
static void out(const char *s) { sh_call(0x04u, s); }          /* SYS_WRITE0 */
static uint32_t call_checked(const uint32_t *p, uint32_t n, uint32_t *mask)
{
    uint32_t r0 = 0;
    *mask = lab_abi_call32((lab_abi_fn32)lab_sum_u32, (uint32_t)(uintptr_t)p, n, &r0);
    return r0;
}
static int finish(int fails)
{
    sh_call(0x18u, (const void *)(fails ? 0x20023u : 0x20026u)); /* SYS_EXIT */
    return fails != 0;
}
#endif

/* ---------- közös tesztlogika ---------- */
static void out_hex(uint32_t v)
{
    char b[11] = "0x";
    for (int i = 0; i < 8; i++) b[2 + i] = "0123456789abcdef"[(v >> (28 - 4 * i)) & 0xFu];
    b[10] = '\0';
    out(b);
}

static const uint32_t data[8] = { 1, 2, 3, 0xFFFFFFFFu,
                                  0x80000000u, 0x80000000u, 7, 0x12345678u };

int main(void)
{
    static const uint32_t ns[] = { 0, 1, 3, 4, 8 };
    int fails = 0;
    for (unsigned c = 0; c < sizeof ns / sizeof ns[0]; c++) {
        uint32_t n = ns[c], ref = 0, mask;
        for (uint32_t i = 0; i < n; i++) ref += data[i];       /* C-referencia, mod 2^32 */
        uint32_t got = call_checked(data, n, &mask);
        int ok = got == ref && mask == 0;
        fails += !ok;
        out("n="); out_hex(n); out(" sum="); out_hex(got);
        out(" abi_mask="); out_hex(mask); out(ok ? " OK\n" : " HIBA\n");
    }
    out(fails ? "SUMTEST: FAIL\n" : "SUMTEST: PASS\n");
    return finish(fails);
}
