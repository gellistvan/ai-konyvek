@ lab-sum-t32.s — Thumb-2, AAPCS32: r0 = p, r1 = n; visszatérés r0-ban
    .syntax unified
    .thumb
    .text
    .global lab_sum_u32
    .thumb_func                   @ a szimbólum Thumb-függvény: címének bit0-ja 1
    .type   lab_sum_u32, %function
lab_sum_u32:
    @ callee-saved regiszterek; páros darabszám: SP 8-ra igazított marad
    push    {r4, r5}
    movs    r4, #0
    cbz     r1, 2f
1:  ldr     r5, [r0], #4          @ post-index: p++
    adds    r4, r4, r5
    subs    r1, r1, #1
    bne     1b
2:  mov     r0, r4
    pop     {r4, r5}
    bx      lr                    @ visszatérés: LR bit0 = 1, Thumb marad
    .size   lab_sum_u32, . - lab_sum_u32
