@ lab-abi-call32.s — AAPCS32 megőrzési teszthívó (Thumb-2, Armv7-M)
@ r0 = fn, r1 = a0, r2 = a1, r3 = &result; visszatérés r0 = hibamaszk
    .syntax unified
    .thumb
    .text
    .global lab_abi_call32
    .thumb_func
    .type   lab_abi_call32, %function
lab_abi_call32:
    @ 10 regiszter = 40 bájt: SP 8-ra igazított marad; r3 = &result
    push    {r3-r11, lr}
    mov     r12, r0               @ fn (R12: scratch, a hívó szabadon használja)
    ldr     r4, =lab_abi32_sp     @ horgony: 0 = szabad, különben egy hívás már fut
    ldr     r5, [r4]
    cmp     r5, #0
    bne     3f                    @ újrabelépés: fn nem hívható
    mov     r5, sp
    str     r5, [r4]              @ a hívás előtti SP
    ldr     r4,  =0x44444444      @ minták a callee-saved regiszterekbe
    ldr     r5,  =0x55555555
    ldr     r6,  =0x66666666
    ldr     r7,  =0x77777777
    ldr     r8,  =0x88888888
    ldr     r9,  =0x99999999
    ldr     r10, =0xAAAAAAAA
    ldr     r11, =0xBBBBBBBB
    mov     r0, r1                @ a0
    mov     r1, r2                @ a1
    blx     r12                   @ BLX: LR = visszatérési cím | 1
    movs    r2, #0                @ hibamaszk
    ldr     r1, =0x44444444
    cmp     r4, r1
    it      ne
    orrne   r2, r2, #(1 << 0)
    ldr     r1, =0x55555555
    cmp     r5, r1
    it      ne
    orrne   r2, r2, #(1 << 1)
    ldr     r1, =0x66666666
    cmp     r6, r1
    it      ne
    orrne   r2, r2, #(1 << 2)
    ldr     r1, =0x77777777
    cmp     r7, r1
    it      ne
    orrne   r2, r2, #(1 << 3)
    ldr     r1, =0x88888888
    cmp     r8, r1
    it      ne
    orrne   r2, r2, #(1 << 4)
    ldr     r1, =0x99999999
    cmp     r9, r1
    it      ne
    orrne   r2, r2, #(1 << 5)
    ldr     r1, =0xAAAAAAAA
    cmp     r10, r1
    it      ne
    orrne   r2, r2, #(1 << 6)
    ldr     r1, =0xBBBBBBBB
    cmp     r11, r1
    it      ne
    orrne   r2, r2, #(1 << 7)
    ldr     r1, =lab_abi32_sp
    ldr     r3, [r1]              @ a hívás előtti SP a horgonyból
    mov     r12, sp
    cmp     r12, r3
    it      ne
    orrne   r2, r2, #(1 << 8)
    @ helyreállítás csak a horgonyból: a sérült SP-t nem használjuk
    mov     sp, r3
    movs    r3, #0
    str     r3, [r1]              @ a horgony újra szabad
    b       4f
3:  mov     r2, #(1 << 9)         @ LAB_ABI32_BUSY; a horgonyt nem írjuk felül
    movs    r0, #0
4:  ldr     r3, [sp]              @ a mentett &result
    str     r0, [r3]              @ *result = a hívott R0-ja
    mov     r0, r2
    pop     {r3-r11, pc}          @ visszatérés: a mentett LR közvetlenül a PC-be
    .size   lab_abi_call32, . - lab_abi_call32

    .bss
    .align  2
lab_abi32_sp:
    .space  4
