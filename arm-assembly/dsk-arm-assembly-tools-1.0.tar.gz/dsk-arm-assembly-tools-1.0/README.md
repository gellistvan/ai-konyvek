# A könyv kísérőcsomagja

Ez a csomag (`dsk-arm-assembly-tools`, verzió: `VERSION`) a könyv laborforrásait, a
helyettesítő futtatókat, a mutációs és negatív próbákat, valamint a próbák naplóit
tartalmazza. A könyv **fő futtatási útja** a GNU eszközlánc (`aarch64-linux-gnu-*`,
`arm-none-eabi-*`) és a QEMU (`qemu-aarch64`, `qemu-system-arm -machine mps2-an385`). A
helyettesítő futtatók (`lab-run.py`, `cm-run.py`) **kiegészítő** bizonyítékot adnak a saját,
alább rögzített hatókörükben; nem helyettesítik a QEMU- vagy hardverfuttatást, és nem
igazolják automatikusan a QEMU-parancsok működését.

## Gyors kezdés

```bash
tar xzf dsk-arm-assembly-tools-1.0.tar.gz && cd dsk-arm-assembly-tools-1.0
sha256sum -c MANIFEST.sha256                # minden csomagfájl ellenőrzőösszege
sha256sum -c logs/SHA256SUMS                # a mellékelt naplóké
# helyettesítő út (nincs szükség GNU ARM eszközláncra és QEMU-ra):
python3 -m venv tv && tv/bin/pip install unicorn==2.1.4 capstone==5.0.7 pyelftools==0.33 ziglang==0.17.0
PYTHON=tv/bin/python bash tests/run.sh substitute     # napló: logs/substitute-<dátum>.log
# a könyv fő útja (Ubuntu 24.04: gcc-aarch64-linux-gnu, gcc-arm-none-eabi, qemu-user,
# qemu-system-arm; a Python-csomagok a fenti venvből):
PYTHON=tv/bin/python bash tests/run.sh gnu-qemu       # napló: logs/gnu-qemu-<dátum>.log
```

A `tests/run.sh` üres, ideiglenes munkakönyvtárban, **kizárólag a csomag fájljaiból** épít és
futtat; minden próba `PASS`/`FAIL` sort ad, a kilépési kód 0, ha nincs `FAIL`. A napló elején a
csomagverzió, a manifest-ellenőrzés eredménye és a használt eszközök verziói állnak. A próbák:

| Terület | Próbák |
|---|---|
| I. rész | a029 ABI-teszthívó; a053 alapdemó, kézi canary öt bemenettel és három hibás kontrollal; a049 két bejárás + lefedettségi próba; a055 PAC nélkül/PAC-kal; a059 `lab_sgemm` tesztkészlet; a060 statikus audit a helyes kódra, öt mutánsra, a hiányzó x27/x28-mentésre és egy nem támogatott utasításra (SKIP); a060 hibás farokciklus; a061 `lab_sum_u32` A64 |
| II. rész | a061 `lab_sum_u32` Thumb-2 és `lab_abi_call32` negatív teszt; a070 Timer0 IRQ8 boot; a071 latenciapróba (DWT nélkül SKIP) és kontrollált SysTick-preempció + prioritásmutáns; a076 UART ready + echo; a077 megszakításos és busy-wait tick; minden firmware-nél név szerinti vektorellenőrzés |
| II. záróprojekt | ringteszt; `lab-m19` build; rendszerteszt (boot, echo, 50 bájtos burst, tick, reset, K5); reset 3 s hostkéséssel; hat hibás protokoll-DUT (`fake-dut.py`: többlet, csere, hiány, reset nélkül, gyors tick, hibás K5-sor) és egy helyes; a 2. megoldás statisztikai hostpróbája |

A `logs/` a csomag kiadásakor futtatott próbák naplóit tartalmazza (`substitute-*.log`, és ha
elkészült, `gnu-qemu-*.log`); a `logs/SHA256SUMS` ezek ellenőrzőösszege. A gnu-qemu napló a
könyv fő útjának bizonyítéka; ha hiányzik, a fő út az adott csomagverzióhoz **nincs** lefuttatva.
A `MANIFEST.sha256` a naplókon kívül minden fájlt lefed. A csomagot a könyv forrásából a
`scripts/make-kiserocsomag.sh` állítja elő, rögzített fájlsorrenddel és időbélyeggel.

## Futtatók

| Eszköz | Verzió | Mit futtat |
|---|---|---|
| `lab-run.py` | `python3 lab-run.py --version` | statikus AArch64 Linux ELF, user-mode (az I. rész laborjai); utasításlimit: `LAB_RUN_MAX` |
| `cm-run.py` | `python3 cm-run.py --version` | Cortex-M3 bare-metal ELF, `mps2-an385`-höz hasonló gép (a II. rész laborjai) |
| `cfi-dump.py` | — | egy ELF `.eh_frame`/`.debug_frame` CFI-táblájának kiírása függvényenként |
| `thumb-dump.py` | — | Thumb-2 disassembly (`objdump`-szerű félszavak + memóriasorrendű bájtok) |

A mérésekhez használt környezet (2026-10): Python 3.12.3, unicorn 2.1.4,
capstone 5.0.7, pyelftools 0.33; fordító: `zig cc` 0.17.0 (Clang, `ld.lld`;
`-target aarch64-linux-musl`, illetve `-target thumb-freestanding-eabi -mcpu=cortex_m3`).

```bash
python3 -m venv tv && tv/bin/pip install unicorn==2.1.4 capstone==5.0.7 pyelftools==0.33 ziglang==0.17.0
```

## `cm-run.py` támogatási mátrixa

| Modell | Támogatott | Nem támogatott / eltérés a QEMU-tól és a hardvertől |
|---|---|---|
| Reset | SP és PC a vektortáblából, bit0-ellenőrzés | — |
| Végrehajtás | Unicorn Thumb-2, M-profil | **nem cikluspontos**: 1 utasítás = 1 „ciklus”, az idő 2000 utasításos csomagokban lép |
| UART0 `0x40004000` | TX a stdoutra; `--uart-stdin`: RX a stdinről, `--rx-gap` ütemezéssel; `RXINT` W1C; IRQ0 | `TXFULL` sosem 1 (a várakozó ciklus nem próbálható ki); nincs baud-időzítés |
| Timer0 `0x40000000` | lefelé számlálás, RELOAD-írás a VALUE-t is beállítja, `INTSTATUS` W1C, IRQ8 kézbesítés | időzítés csak csomaghatáron |
| Timer1 `0x40001000` | szabadon futó időalap; `--timer1-stops-in-wfi` | megszakítást nem kér |
| SysTick (15. kivétel) | szoftveres pending: `ICSR.PENDSTSET`/`PENDSTCLR`, prioritás az `SHPR3[31:24]`-ből | a SysTick-időzítő (`SYST_CSR`/`RVR`/`CVR`) nincs modellezve |
| NVIC | `ISER`/`ICER`, `ISPR`/`ICPR`, IPR (`--prio-bits`, alapértelmezés 3), `AIRCR.PRIGROUP`; szintvezérelt kérések, preempció, `EXC_RETURN` | `IABR` mindig 0; a QEMU 8.2 NVIC-je 8 prioritásbitet valósít meg |
| GPIO `0x40010000` | olvasás 0, írás hatástalan | nincs GPIO (a QEMU 8.2.2 AN385-ben sincs) |
| DWT `CYCCNT` | — | **nem halad** (mint a QEMU 8.2.2 AN385-ön) |
| `WFI` | előretekerés a következő timer-/UART-eseményig | — |
| Semihosting (`BKPT 0xAB`) | `SYS_WRITEC`, `SYS_WRITE0`, `SYS_EXIT` | más hívás nincs |
| Kilépési kód | semihosting-állapot; 139 hiba (fault), 124 utasításlimit | — |

## `lab-run.py` támogatási mátrixa

| Modell | Támogatott | Nem támogatott |
|---|---|---|
| ELF | statikus, `_start` vagy musl/C belépés | dinamikus linkelés |
| Rendszerhívások | `write`, `writev`, `read`, `openat`, `close`, `exit`, `exit_group`, `brk`, `mmap` (anonim), `mprotect` (a védőlap valóban hibát okoz), `munmap`, `clock_gettime`, `getrandom`, `uname`, néhány no-op | szálak, jelek, fájlrendszer-írás |
| Végrehajtás | Unicorn AArch64, utasításlimit 200 millió (124-es kilépés) | nem cikluspontos; a PAuth-utasítások HINT-ként futnak |

## Laborforrások

`abi/` (a029), `a049/` (a049), `a053/` (a053), `a055/` (a055), `zaro1/` (a057–a060), `a060/` (a060 audit és
mutánsai), `pair/` (a061), `cm-labs/` (a070, a071, a076, a077; a `canon/` a kanonikus
`lab-mps2.ld` + `lab-startup.s` + `lab-check-vectors.py` hármas az a064–a066-ból), `lab-m19/`
(a078–a081). A könyv kódblokkjai ezekkel bájtra azonosak; a `cm-labs/aNNN/lab-aNNN-startup.s`
fájlok a könyv `cp`/`cat`/`sed`/`echo` lépéseinek eredményei. Nem a könyvből származnak (a
csomag saját próbaeszközei): `a060/mutants/`, `a055/lab-a055-leaf.c` és `a055/lab-a055-nonote.s` (az a055 3. feladatához),
`lab-m19/fake-dut.py`, `lab-m19/feladat2/measure-line-host-test.c`, `objdump-a64.py` (a GNU
`objdump -d --disassemble=` capstone-alapú helyettesítője az a060 auditjához), `tests/run.sh`.
A `lab-m19/feladat2/` az a080 2. megoldásának `measure_line()` cseréjét (`measure-line-stats.inc`,
a könyvben közölt blokk) és a hozzá tartozó hostpróbát (`measure-line-host-test.c`) tartalmazza.
