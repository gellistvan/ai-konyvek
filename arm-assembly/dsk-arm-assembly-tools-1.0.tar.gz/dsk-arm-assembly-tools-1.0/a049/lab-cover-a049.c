/* lab-cover-a049.c — a két bejárás lefedettségi próbája (oktatási ellenpróba, host C).
 * Az indexsorozatok pontosan a lab-seq-a049.s és a lab-stride-a049.s ciklusait
 * követik; a mutánsok szándékosan hibásak. Minden olvasás a visits[] számlálót is
 * növeli: ebből derül ki a kihagyás, a duplikáció és az eltérő olvasásszám. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#define N      1048576u
#define STRIDE 1024u

static uint32_t a[N];
static uint8_t visits[N];
static uint64_t reads, sum;

static void visit(uint32_t k)             /* egy olvasás: adat + látogatási nyom */
{
    sum += a[k];
    reads++;
    if (visits[k] < 255u)
        visits[k]++;
}

static void seq(void)       { for (uint32_t k = 0; k < N; k++) visit(k); }
static void stride(void)                  /* k = c + STRIDE·j, oszloponként */
{
    for (uint32_t c = 0; c < STRIDE; c++)
        for (uint32_t k = c; k < N; k += STRIDE)
            visit(k);
}
/* szándékosan hibás változatok */
static void mut_a0(void)    { for (uint32_t k = 0; k < N; k++) visit(0); }   /* mindig a[0] */
static void mut_skipdup(void)                    /* a[5] helyett a[4]: kihagyás + duplikáció */
{
    for (uint32_t k = 0; k < N; k++) visit(k == 5u ? 4u : k);
}
static void mut_extra(void) { seq(); visit(7); }                       /* egy többletolvasás */

static int run(const char *name, void (*f)(void))
{
    for (uint32_t k = 0; k < N; k++) visits[k] = 0;
    reads = sum = 0;
    f();
    uint64_t missing = 0, dup = 0;
    for (uint32_t k = 0; k < N; k++) {
        missing += visits[k] == 0;
        dup += visits[k] > 1;
    }
    const uint64_t want = (uint64_t)N * (N + 1u) / 2u;    /* a[i] = i + 1 összege */
    int ok = reads == N && missing == 0 && dup == 0;
    printf("%-14s olvasás=%-8llu hiányzó=%-8llu többször=%-3llu összeg %s  %s\n", name,
           (unsigned long long)reads, (unsigned long long)missing,
           (unsigned long long)dup, sum == want ? "egyezik" : "ELTÉR", ok ? "OK" : "HIBA");
    return ok;
}

int main(void)
{
    for (uint32_t k = 0; k < N; k++)
        a[k] = k + 1u;                    /* heterogén adat: minden elem különböző */
    int ok = run("sorrendi", seq) & run("stride", stride);
    puts("-- szándékosan hibás változatok (HIBA az elvárt):");
    int bad = !run("a[0] N-szer", mut_a0) & !run("kihagy+dupláz", mut_skipdup)
            & !run("többletolvasás", mut_extra);
    puts(ok && bad ? "COVER: PASS" : "COVER: FAIL");
    return !(ok && bad);
}
