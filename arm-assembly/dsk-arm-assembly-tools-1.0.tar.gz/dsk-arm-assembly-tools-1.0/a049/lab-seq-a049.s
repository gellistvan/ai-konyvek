// lab-seq-a049.s – sorrendi bejárás
// AArch64 (A64 ISA), Linux, qemu-aarch64 user-mode

    .section .data
    .balign 64              // cache-sor határára igazítunk
arr:
    .fill 1048576, 4, 1     // 4 MB, 1 048 576 darab 32 bites int, mind 1
    .set ARR_SIZE, 1048576

    .section .text
    .global _start
_start:
    mov x0, #0              // összeg
    ldr x1, =arr            // tömb alapcíme
    mov x2, #ARR_SIZE       // elemek száma
    mov x3, #0              // index

seq_loop:
    cmp x3, x2
    b.ge seq_done
    ldr w4, [x1, x3, lsl #2] // w4 = arr[x3]
    add x0, x0, x4           // összegzés
    add x3, x3, #1
    b seq_loop

seq_done:
    cmp x0, x2
    cset w0, ne
    mov x8, #93             // exit syscall
    svc #0

    .section .note.GNU-stack,"",%progbits
