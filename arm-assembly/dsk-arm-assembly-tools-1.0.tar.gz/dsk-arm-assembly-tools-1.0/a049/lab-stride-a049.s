// lab-stride-a049.s – stride-os bejárás
// AArch64 (A64 ISA), Linux, qemu-aarch64 user-mode

    .section .data
    .balign 64
arr:
    .fill 1048576, 4, 1
    .set ARR_SIZE, 1048576
    .set STRIDE, 1024       // 1024 * 4 bájt = 4096 bájt ugrás

    .section .text
    .global _start
_start:
    mov x0, #0
    ldr x1, =arr
    mov x2, #ARR_SIZE
    mov x5, #0              // oszlop a stride szerinti bejarashoz
stride_column:
    mov x3, x5

stride_loop:
    cmp x3, x2
    b.ge stride_next_column
    ldr w4, [x1, x3, lsl #2]
    add x0, x0, x4
    add x3, x3, #STRIDE
    b stride_loop

stride_next_column:
    add x5, x5, #1
    cmp x5, #STRIDE
    b.lt stride_column
stride_done:
    cmp x0, x2
    cset w0, ne
    mov x8, #93
    svc #0

    .section .note.GNU-stack,"",%progbits
