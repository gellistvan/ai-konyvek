/* lab-m19-drivers.c */
#include "lab-m19-drivers.h"

void uart0_init(uint32_t bauddiv)
{
    UART0->BAUDDIV = bauddiv;
    UART0->CTRL    = (1u << 0) | (1u << 1) | (1u << 3);   /* TXEN, RXEN, RXINTEN */
}

void timer0_init(uint32_t reload)
{
    TIMER0->CTRL      = 0;          /* előbb leállít */
    TIMER0->INTSTATUS = 1u;         /* függő kérés törlése (W1C) */
    TIMER0->RELOAD    = reload;     /* a VALUE-t is beállítja: az első periódus is pontos */
    TIMER0->CTRL      = (1u << 0) | (1u << 3);            /* ENABLE, IRQEN */
}

void uart_putc(char c)
{
    while (UART0->STATE & (1u << 0)) { }    /* amíg TXFULL = 1, várunk */
    UART0->DATA = (uint8_t)c;
}

void uart_puts(const char *s)
{
    while (*s) uart_putc(*s++);
}

void uart_put_u32(uint32_t v)
{
    char d[10];
    unsigned n = 0;
    do { d[n++] = (char)('0' + v % 10u); v /= 10u; } while (v);
    while (n) uart_putc(d[--n]);
}
