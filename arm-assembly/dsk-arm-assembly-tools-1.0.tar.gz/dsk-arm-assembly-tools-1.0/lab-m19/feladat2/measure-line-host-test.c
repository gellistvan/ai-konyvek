#include <stdio.h>
#include <stdint.h>
#include <math.h>
#define LAB_SAMPLES 64u
static int lab_have_dwt = 1;
static volatile uint32_t isr_body[LAB_SAMPLES], isr_body_n;
static uint32_t crit_enter(void) { return 0; }
static void crit_exit(uint32_t pm) { (void)pm; }
static void uart_puts(const char *s) { fputs(s, stdout); }
static void uart_put_u32(uint32_t v) { printf("%u", v); }
#include "measure-line-stats.inc"
static void fill(uint32_t n, uint32_t a, uint32_t b) {     /* a, b felváltva */
    for (uint32_t i = 0; i < n; i++) isr_body[i] = (i % 2) ? b : a;
    isr_body_n = n; measure_line();
}
int main(void)
{
    fill(64, 14, 14); fill(64, 20, 20); fill(64, 14, 20);
    fill(64, 0x04000000u, 0x04000000u); fill(64, 0x80000000u, 0x80000000u);
    fill(64, 0xFFFFFFFFu, 0xFFFFFFFFu); fill(64, 0xFFFFFFFEu, 0xFFFFFFFFu); fill(63, 1, 0xFFFFFFFFu);
    uint32_t skew[] = {10,10,10,10,10,10,10,11,11,12,30,60};
    for (uint32_t i = 0; i < 12; i++) isr_body[i] = skew[i];
    isr_body_n = 12; measure_line();
    /* véletlen összevetés egy 64 bites referenciával */
    uint64_t x = 88172645463325252ull; unsigned bad = 0;
    for (int t = 0; t < 200000; t++) {
        uint32_t n = 1 + (uint32_t)(x % 64); uint64_t s = 0; uint32_t w[64];
        for (uint32_t i = 0; i < n; i++) { x ^= x << 13; x ^= x >> 7; x ^= x << 17;
            w[i] = (t & 1) ? (uint32_t)x : (uint32_t)(x % 9000); s += w[i]; isr_body[i] = w[i]; }
        isr_body_n = n;
        FILE *o = stdout; stdout = fopen("/dev/null", "w"); measure_line(); fclose(stdout); stdout = o;
        /* újraszámolás a függvényen kívül: a mean képlet */
        uint32_t q = 0, r = 0; for (uint32_t i = 0; i < n; i++) { q += w[i] / n; r += w[i] % n; }
        if (q + r / n != (uint32_t)(s / n)) bad++;
    }
    printf("random mean-ellenőrzés: %u eltérés / 200000\n", bad);
    return 0;
}
