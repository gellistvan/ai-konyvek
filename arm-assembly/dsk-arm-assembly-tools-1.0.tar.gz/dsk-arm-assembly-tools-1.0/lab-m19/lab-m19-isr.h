/* lab-m19-isr.h */
#ifndef LAB_M19_ISR_H
#define LAB_M19_ISR_H
#include <stdint.h>
#include "lab-m19-ring.h"

extern ring_t rx_ring;                     /* termelő: UART0_Handler */
extern volatile uint32_t tick_count;       /* csak a TIMER0_Handler írja */

/* ISR-törzsidő-minták (DWT); a gyűjtés az ISR-ben, a kiértékelés a fő programban */
#define LAB_SAMPLES 64u
extern int lab_have_dwt;
extern volatile uint32_t isr_body[LAB_SAMPLES];
extern volatile uint32_t isr_body_n;

void UART0_Handler(void);
void TIMER0_Handler(void);
int  lab_dwt_start(void);
#endif
