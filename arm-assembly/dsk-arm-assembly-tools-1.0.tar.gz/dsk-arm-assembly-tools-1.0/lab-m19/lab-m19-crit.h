/* lab-m19-crit.h – kritikus szakasz M-profile-on, a PRIMASK megőrzésével */
#ifndef LAB_M19_CRIT_H
#define LAB_M19_CRIT_H
#include <stdint.h>

static inline uint32_t crit_enter(void)
{
    uint32_t pm;
    __asm volatile ("mrs %0, primask" : "=r"(pm));
    __asm volatile ("cpsid i" ::: "memory");
    return pm;
}

static inline void crit_exit(uint32_t pm)
{
    __asm volatile ("msr primask, %0\n\tisb" :: "r"(pm) : "memory");
}
#endif
