/* lab-m19-main.c — a lab-m19 alapfeladat (QEMU mps2-an385): UART0 + Timer0 */
#include <stdint.h>
#include "lab-m19-drivers.h"
#include "lab-m19-isr.h"
#include "lab-m19-crit.h"

#define NVIC_ISER0 (*(volatile uint32_t *)0xE000E100u)
#define NVIC_IPR   ((volatile uint8_t  *)0xE000E400u)

static void nvic_enable(uint32_t irqn, uint8_t raw_prio)
{
    NVIC_IPR[irqn] = raw_prio;               /* nyers, balra igazított IPR-bájt */
    NVIC_ISER0 = 1u << irqn;
}

static uint32_t tick_base, overrun_base;     /* 'R' nullpontja: csak a fő program írja */

static void status_line(void)                /* K3 */
{
    uint32_t pm = crit_enter();              /* koherens pillanatkép a két számlálóról */
    uint32_t t  = tick_count;
    uint32_t ov = rx_ring.overrun;
    crit_exit(pm);
    uart_puts("status: ticks=");
    uart_put_u32(t - tick_base);
    uart_puts(" overrun=");
    uart_put_u32(ov - overrun_base);
    uart_puts(" raw=");                      /* K4: a nyers számláló, a bázispróbához */
    uart_put_u32(t);
    uart_puts("\r\n");
}

static void measure_line(void)               /* K5 */
{
    if (!lab_have_dwt) {
        uart_puts("isr_body: SKIP (DWT CYCCNT nem halad)\r\n");
        return;
    }
    uint32_t n = isr_body_n, mn = 0xFFFFFFFFu, mx = 0, sum = 0;
    for (uint32_t i = 0; i < n; i++) {
        uint32_t v = isr_body[i];
        if (v < mn) mn = v;
        if (v > mx) mx = v;
        sum += v;
    }
    uart_puts("isr_body: n="); uart_put_u32(n);
    if (n) {
        uart_puts(" min="); uart_put_u32(mn);
        uart_puts(" max="); uart_put_u32(mx);
        uart_puts(" mean="); uart_put_u32(sum / n);
    }
    uart_puts("\r\n");
}

static void handle_byte(uint8_t c)
{
    if (c == 'S') {
        status_line();
    /* K4: új nullpont, nem a megosztott számlálók írása */
    } else if (c == 'R') {
        uint32_t pm = crit_enter();
        uint32_t base = tick_count;
        tick_base    = base;
        overrun_base = rx_ring.overrun;
        crit_exit(pm);
        uart_puts("reset ok base=");         /* a válasz a rögzített új bázist hordozza */
        uart_put_u32(base);
        uart_puts("\r\n");
    } else if (c == 'M') {
        measure_line();
    } else {
        uart_putc((char)c);                  /* K2: echo */
    }
}

int main(void)
{
    __asm volatile ("cpsid i" ::: "memory");
    uart0_init(LAB_SYSCLK_HZ / 115200u);
    lab_have_dwt = lab_dwt_start();
    timer0_init(LAB_SYSCLK_HZ / LAB_TICK_HZ - 1u);   /* 10 ms */
    nvic_enable(TIMER0_IRQn, 0x40u);
    nvic_enable(UART0_IRQn,  0x60u);
    uart_puts("lab-m19 boot\r\n");                    /* K1 */
    __asm volatile ("cpsie i" ::: "memory");

    uint32_t seen = 0;
    for (;;) {
        uint8_t c;
        while (ring_pop(&rx_ring, &c))
            handle_byte(c);
        uint32_t now = tick_count;           /* 32 bites, igazított olvasás: atomi */
        /* K6: minden tick feldolgozva, nem csak "volt-e" */
        while (seen != now) {
            seen++;
            if (seen % LAB_TICK_HZ == 0u)
                uart_puts("tick\r\n");
        }
        uint32_t pm = crit_enter();          /* versenymentes alvás */
        if (ring_empty(&rx_ring) && seen == tick_count)
            __asm volatile ("dsb\n\twfi" ::: "memory");
        crit_exit(pm);
    }
}
