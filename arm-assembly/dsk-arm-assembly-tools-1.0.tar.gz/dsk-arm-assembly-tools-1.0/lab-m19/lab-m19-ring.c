/* lab-m19-ring.c */
#include "lab-m19-ring.h"

int ring_push(ring_t *r, uint8_t b)
{
    uint16_t next = (uint16_t)((r->head + 1u) % RING_CAP);
    if (next == r->tail) {
        r->overrun++;                    /* tele: az új bájt elveszik, de számoljuk */
        return 0;
    }
    r->buf[r->head] = b;                 /* előbb az adat, ... */
    r->head = next;                      /* ... utána a közzététel */
    return 1;
}

int ring_pop(ring_t *r, uint8_t *out)
{
    if (r->tail == r->head) return 0;    /* üres: nem olvas, a tail helyben marad */
    *out = r->buf[r->tail];
    r->tail = (uint16_t)((r->tail + 1u) % RING_CAP);
    return 1;
}

int ring_empty(const ring_t *r) { return r->tail == r->head; }
