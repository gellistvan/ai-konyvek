/* lab-m19-ring-test.c — a ring buffer egységtesztje a HOSTON (gcc), hardver nélkül.
 *   gcc -std=c11 -Wall -Wextra -o lab-m19-ring-test lab-m19-ring-test.c lab-m19-ring.c */
#include <stdio.h>
#include <string.h>
#include "lab-m19-ring.h"

static int fails;
#define CHECK(name, cond) do {                                      \
        int ok_ = (cond);                                           \
        printf("%s  %s\n", ok_ ? "PASS" : "FAIL", name);            \
        fails += !ok_;                                              \
    } while (0)

int main(void)
{
    ring_t r;
    uint8_t b, out[RING_CAP];

    /* U1 alapeset: 3 bájt be, ugyanaz a 3 ki, ugyanabban a sorrendben */
    memset(&r, 0, sizeof r);
    ring_push(&r, 0x41); ring_push(&r, 0x42); ring_push(&r, 0x43);
    int n = 0;
    while (ring_pop(&r, &b)) out[n++] = b;
    CHECK("U1 alapeset: count = 3, sorrend ABC",
          n == 3 && out[0] == 0x41 && out[1] == 0x42 && out[2] == 0x43);

    /* U2 üres puffer: nem olvas, a tail helyben marad */
    uint16_t tail = r.tail;
    CHECK("U2 üres puffer: pop = 0, tail változatlan", ring_pop(&r, &b) == 0 && r.tail == tail);

    /* U3 tele puffer: RING_CAP-1 fér el; a többi eldobva és számolva */
    memset(&r, 0, sizeof r);
    int accepted = 0;
    for (int i = 0; i < 100; i++) accepted += ring_push(&r, (uint8_t)i);
    CHECK("U3 tele: pontosan RING_CAP-1 = 63 bájt fér el", accepted == RING_CAP - 1);
    CHECK("U3 tele: overrun = 100 - 63 = 37", r.overrun == 100u - (RING_CAP - 1));
    n = 0;
    while (ring_pop(&r, &b)) out[n++] = b;
    int order = n == RING_CAP - 1;
    for (int i = 0; i < n; i++) order = order && out[i] == (uint8_t)i;
    CHECK("U3 tele: a megtartott bájtok az első 63, sorrendben (az újak vesznek el)", order);

    /* U4 körbefordulás: sok kis adag a puffer végén át, veszteség nélkül */
    memset(&r, 0, sizeof r);
    int ok = 1; uint8_t next_in = 0, next_out = 0;
    for (int round = 0; round < 1000; round++) {
        for (int k = 0; k < 5; k++) ok &= ring_push(&r, next_in++);
        for (int k = 0; k < 5; k++) ok &= ring_pop(&r, &b) && b == next_out++;
    }
    CHECK("U4 körbefordulás: 5000 bájt kapacitáson belül, veszteség és csere nélkül",
          ok && r.overrun == 0);

    /* U5 határ: N-1 elem még befér, az N. elemre előírt az overflow */
    memset(&r, 0, sizeof r);
    int all = 1;
    for (unsigned i = 0; i < RING_CAP - 1; i++) all &= ring_push(&r, (uint8_t)i);
    CHECK("U5 határ: az N-1 = 63. elem még befér", all && r.overrun == 0);
    CHECK("U5 határ: az N. elem elutasítva, overrun = 1",
          ring_push(&r, 0xEE) == 0 && r.overrun == 1);

    /* U6 lassú fogyasztó: kettőt tesz be, egyet vesz ki; a sorrend megmarad,
       a veszteség pontosan az elutasított push-ok száma */
    memset(&r, 0, sizeof r);
    unsigned pushed = 0, rejected = 0, popped = 0;
    int inorder = 1;
    uint8_t seq[512]; unsigned nseq = 0;            /* az elfogadott bájtok sorrendje */
    for (int round = 0; round < 200; round++) {
        for (int k = 0; k < 2; k++) {
            uint8_t v = (uint8_t)pushed++;
            if (ring_push(&r, v)) seq[nseq++ % 512] = v; else rejected++;
        }
        if (ring_pop(&r, &b)) { inorder &= b == seq[popped % 512]; popped++; }
    }
    while (ring_pop(&r, &b)) { inorder &= b == seq[popped % 512]; popped++; }
    CHECK("U6 lassú fogyasztó: kivett = elfogadott, sorrendben", inorder && popped == nseq);
    CHECK("U6 lassú fogyasztó: overrun = elutasított push-ok",
          r.overrun == rejected && rejected > 0);

    puts(fails ? "RINGTEST: FAIL" : "RINGTEST: PASS");
    return fails != 0;
}
