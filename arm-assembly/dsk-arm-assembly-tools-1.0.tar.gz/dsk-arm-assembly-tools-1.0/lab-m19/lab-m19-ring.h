/* lab-m19-ring.h — SPSC ring buffer, hardverfüggetlen (hoston is tesztelhető).
 * Szerződés: egyetlen termelő hívja a ring_push-t (az ISR), egyetlen fogyasztó a
 * ring_pop-ot (a fő program). A head-et csak a termelő, a tail-t csak a fogyasztó
 * írja. Kapacitás: RING_CAP - 1 bájt. Tele puffernél a ring_push az ÚJ bájtot
 * eldobja, és az overrun számlálót növeli (veszteségpolitika). */
#ifndef LAB_M19_RING_H
#define LAB_M19_RING_H
#include <stdint.h>

#define RING_CAP 64u                     /* 2 hatványa; használható: 63 */

typedef struct {
    volatile uint8_t  buf[RING_CAP];
    volatile uint16_t head;              /* csak a termelő írja */
    volatile uint16_t tail;              /* csak a fogyasztó írja */
    volatile uint32_t overrun;           /* csak a termelő írja */
} ring_t;

int ring_push(ring_t *r, uint8_t b);     /* 1: betéve, 0: tele, eldobva */
int ring_pop(ring_t *r, uint8_t *out);   /* 1: kivéve, 0: üres */
int ring_empty(const ring_t *r);

#endif
