/* lab-m19-drivers.h */
#ifndef LAB_M19_DRIVERS_H
#define LAB_M19_DRIVERS_H
#include <stdint.h>

typedef struct {
    volatile uint32_t DATA;       /* 0x000 */
    volatile uint32_t STATE;      /* 0x004 bit0 TXFULL, bit1 RXFULL */
    volatile uint32_t CTRL;       /* 0x008 bit0 TXEN, bit1 RXEN, bit3 RXINTEN */
    volatile uint32_t INTSTATUS;  /* 0x00C olvasás: bit0 TXINT, bit1 RXINT; írás: W1C */
    volatile uint32_t BAUDDIV;    /* 0x010 legalább 16 */
} cmsdk_uart_t;

typedef struct {
    volatile uint32_t CTRL;       /* 0x000 bit0 ENABLE, bit3 IRQEN */
    volatile uint32_t VALUE;      /* 0x004 */
    volatile uint32_t RELOAD;     /* 0x008 írása a VALUE-t is beállítja */
    volatile uint32_t INTSTATUS;  /* 0x00C olvasás: pending; írás: W1C (INTCLEAR) */
} cmsdk_timer_t;

#define UART0  ((cmsdk_uart_t *)0x40004000u)
#define TIMER0 ((cmsdk_timer_t *)0x40000000u)

#define UART0_IRQn   0u           /* AN385: UART0 RX */
#define TIMER0_IRQn  8u           /* AN385: Timer0   */

#define LAB_SYSCLK_HZ  25000000u  /* QEMU AN385; laborparaméter */
#define LAB_TICK_HZ    100u       /* 10 ms tick */

void uart0_init(uint32_t bauddiv);
void timer0_init(uint32_t reload);
void uart_puts(const char *s);    /* blokkoló, pollozó TX (az alapfeladat szerződése) */
void uart_putc(char c);
void uart_put_u32(uint32_t v);

#endif
