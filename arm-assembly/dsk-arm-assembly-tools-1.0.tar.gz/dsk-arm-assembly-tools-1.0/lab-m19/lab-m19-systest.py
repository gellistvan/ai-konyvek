#!/usr/bin/env python3
"""lab-m19-systest.py — a lab-m19 alapfeladat rendszertesztje host-oldali soros bemenettel.

Használat:
  python3 lab-m19-systest.py                       # QEMU (alapértelmezett futtató)
  # más futtató, amely a UART0-t stdin/stdout-ra köti
  python3 lab-m19-systest.py --runner "<parancs>"
  További kapcsolók:
    --no-timing        a T1 frekvenciapróba SKIP (nem valós idejű futtatónál kötelező)
    --isr-band LO:HI   a K5b platformsáv: az ISR-törzsidő min..max ciklusban
    --reset-delay SEC  szünet a reset után (a K4 ütemezésfüggetlenségének ellenpróbája)
A firmware UART0-ját a futtató a folyamat stdin/stdout-jára köti; a teszt ide ír
bájtokat (RX-injektálás) és innen olvassa a választ. Kilépési kód: 0, ha nincs FAIL.

Két szint: a funkcionális próbák (K1-K4, K6, F2, K5a) a host időzítésétől
függetlenek; az időzítési próba (T1) és a hardveres sáv (K5b) külön eredmény.
"""
import queue
import re
import shlex
import subprocess
import sys
import threading
import time

QEMU = ("qemu-system-arm -machine mps2-an385 -cpu cortex-m3 -display none "
        "-monitor none -serial stdio -kernel lab-m19.elf")
TICK_HZ = 100
LAB_SAMPLES = 64
TICK_LINE = 'tick\r\n'
STATUS = r'status: ticks=(\d+) overrun=(\d+) raw=(\d+)\r\n'
# Heterogén, determinisztikus burst: a vezérlőparancsokat (S, R, M) és a "tick"
# részsztringet nem tartalmazó ábécéből, kapacitáson belül (50 < 63).
ALPHA = '0123456789ABCDEFGHJKLNOPQTUVWXYZ'
BURST = ''.join(ALPHA[(7 * i + 3) % len(ALPHA)] for i in range(50))


class Dut:
    def __init__(self, cmd):
        self.p = subprocess.Popen(shlex.split(cmd), stdin=subprocess.PIPE,
                                  stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        self.q = queue.Queue()
        self.buf = ''
        threading.Thread(target=self._reader, daemon=True).start()

    def _reader(self):
        while True:
            b = self.p.stdout.read(1)
            if not b:
                return
            self.q.put(b.decode('latin-1'))

    def send(self, s):
        try:
            self.p.stdin.write(s.encode())
            self.p.stdin.flush()
        except (BrokenPipeError, OSError):
            # a futtató kilépett: a várakozó olvasás bukik el
            pass

    def read_until(self, pattern, timeout=10.0):
        """Vár, amíg a pattern megjelenik; a találat végéig fogyasztja a puffert.
        Visszaadja a (találat előtti szöveg, match) párt; időtúllépésnél match = None."""
        rx = re.compile(pattern)
        end = time.monotonic() + timeout          # monotonic: a faliórás ugrás nem változtatja a határidőt
        while True:
            m = rx.search(self.buf)
            if m:
                before, self.buf = self.buf[:m.start()], self.buf[m.end():]
                return before, m
            try:
                self.buf += self.q.get(timeout=max(0.0, end - time.monotonic()))
            except queue.Empty:
                return self.buf, None

    def close(self):
        # Leállítás + learatás: a pipe-ok zárása, wait() időkorláttal, kilépett folyamat kezelése.
        try:
            if self.p.poll() is None:
                self.p.kill()
            try:
                self.p.wait(timeout=5.0)
            except subprocess.TimeoutExpired:
                pass
        finally:
            for pipe in (self.p.stdin, self.p.stdout):
                try:
                    if pipe:
                        pipe.close()
                except OSError:
                    pass


def strip_ticks(text):
    """Az aszinkron tick sorokat a protokoll bárhol beékelheti: ezeket eltávolítjuk."""
    return text.replace(TICK_LINE, '')


def framed_echo(dut, data):
    """Elküldi az adatot, majd egy 'S'-t; a status sorig érkezett bájtoknak (a tick
    sorok nélkül) PONTOSAN az adatnak kell lenniük: ez kizárja a hiányzó,
    duplikált, többlet- és felcserélt bájtot."""
    dut.send(data + 'S')
    before, m = dut.read_until(STATUS)
    got = strip_ticks(before)
    # Siker csak úgy lehet, ha a lezáró státuszkeret határidőn belül megérkezett ÉS a
    # payload pontos; a hiányzó keretet (timeout) nem fedi el a payload-egyezés.
    return m is not None and got == data, got, m


def status(dut):
    dut.send('S')
    _, m = dut.read_until(STATUS)
    return int(m.group(1)) if m else None


def status_raw(dut):
    """(ticks, raw): a bázishoz mért és a nyers számláló ugyanabból a pillanatképből."""
    dut.send('S')
    _, m = dut.read_until(STATUS)
    return (int(m.group(1)), int(m.group(3))) if m else None


def main(argv):
    cmd = argv[argv.index('--runner') + 1] if '--runner' in argv else QEMU
    timing = '--no-timing' not in argv
    delay = float(argv[argv.index('--reset-delay') + 1]) if '--reset-delay' in argv else 0.0
    band = None
    if '--isr-band' in argv:
        lo, hi = argv[argv.index('--isr-band') + 1].split(':')
        band = (int(lo), int(hi))
    dut = Dut(cmd)
    results = []

    def check(name, ok, detail=''):
        results.append((name, 'PASS' if ok else 'FAIL', detail))

    def skip(name, detail):
        results.append((name, 'SKIP', detail))

    try:
        _, m = dut.read_until(r'lab-m19 boot\r\n')
        check('K1 boot', m is not None)

        ok, got, m = framed_echo(dut, 'ab')               # K2: echo, pontosan
        check('K2 echo pontosan "ab"', ok,
              '' if ok else ('a lezáró státuszkeret nem érkezett meg (timeout), payload: ' + repr(got)
                              if m is None else repr(got)))

        ok, got, m = framed_echo(dut, BURST)               # F2: kapacitáson belüli burst
        check('F2 burst 50 heterogén bájt: pontos sorrend és hossz', ok,
              '' if ok else f'{len(got)} bájt érkezett')
        check('K3 status formátum, overrun=0', m is not None and m.group(2) == '0',
              m.group(0).strip() if m else 'nincs válasz')

        # K6: funkcionális, host-időzítéstől független
        t1 = int(m.group(1)) if m else None
        lines = 0
        for _ in range(2):
            _, mt = dut.read_until(re.escape(TICK_LINE), timeout=5.0)
            lines += mt is not None
        check('K6 periodikus tick sor (2 db)', lines == 2)
        t2 = status(dut)
        check('K6 két tick sor alatt a számláló legalább 100-zal nőtt',
              t1 is not None and t2 is not None and t2 - t1 >= TICK_HZ, f'{t1} -> {t2}')

        def reset_probe(name):                           # K4: a reset-válasz bázisa
            before = status_raw(dut)
            dut.send('R')
            _, mr = dut.read_until(r'reset ok base=(\d+)\r\n')
            time.sleep(delay)                            # ellenpróba: hostkésés
            after, later = status_raw(dut), status_raw(dut)
            base = int(mr.group(1)) if mr else None
            # A reset ténye a válaszban rögzített bázisból következik, nem abból, hogy
            # egy későbbi minta kisebb: a ticks = raw - bázis bármekkora késés mellett igaz.
            ok = (None not in (before, after, later, base) and base >= before[1]
                  and after[0] == after[1] - base and later[0] == later[1] - base
                  and later[1] >= after[1])
            fmt = lambda v: f'{v[0]}/{v[1]}' if v else '-'  # ticks/raw
            check(name, ok, f'bázis {base}, utána {fmt(after)}, később {fmt(later)}')

        reset_probe('K4 reset: ticks = raw - bázis, monoton')
        dut.read_until(re.escape(TICK_LINE), timeout=5.0)
        reset_probe('K4 ismételt reset: ugyanígy')

        if timing:                                       # T1: időzítési szerződés, külön
            ta, wa = status(dut), time.monotonic()
            time.sleep(2.0)
            tb, wb = status(dut), time.monotonic()
            rate = (tb - ta) / (wb - wa) if None not in (ta, tb) else 0.0
            check(f'T1 tickfrekvencia {TICK_HZ} Hz ±20% (host-órához mérve)',
                  0.8 * TICK_HZ <= rate <= 1.2 * TICK_HZ, f'{rate:.1f} Hz')
        else:
            skip('T1 tickfrekvencia', 'nem valós idejű futtató (--no-timing)')

        dut.send('M')                                    # K5: ISR-törzsidő
        _, m4 = dut.read_until(r'isr_body: ([^\r]*)\r\n')
        body = m4.group(1) if m4 else None
        if body is not None and body.startswith('SKIP'):
            skip('K5a ISR-törzsidő formátum', body)
            skip('K5b ISR-törzsidő platformsáv (P1)', body)
        else:
            mm = re.fullmatch(r'n=(\d+) min=(\d+) max=(\d+) mean=(\d+)'
                              r'(?: median=(\d+))?(?: sd=(\d+))?', body or '')
            ok = bool(mm)
            if ok:
                n, mn, mx, mean = (int(x) for x in mm.groups()[:4])
                med = mm.group(5)                    # a 2. feladat opcionális mezője
                ok = (0 < n <= LAB_SAMPLES and mn <= mean <= mx
                      and (med is None or mn <= int(med) <= mx))
            check('K5a ISR-törzsidő formátum: 0 < n <= 64, min <= mean <= max',
                  ok, body or 'nincs válasz')
            if band is None:
                skip('K5b ISR-törzsidő platformsáv (P1)', 'nincs --isr-band megadva')
            else:
                check(f'K5b ISR-törzsidő platformsáv (P1) {band[0]}..{band[1]}',
                      ok and band[0] <= mn and mx <= band[1], body or '')
    finally:
        dut.close()

    for name, res, detail in results:
        print(f'{res:4}  {name}' + (f'  [{detail}]' if detail else ''))
    fails = sum(r == 'FAIL' for _, r, _ in results)
    print('SYSTEST:', 'FAIL' if fails else 'PASS')
    return 1 if fails else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
