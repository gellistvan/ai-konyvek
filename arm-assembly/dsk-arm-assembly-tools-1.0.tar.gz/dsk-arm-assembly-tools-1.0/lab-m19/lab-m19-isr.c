/* lab-m19-isr.c */
#include "lab-m19-drivers.h"
#include "lab-m19-isr.h"

#define DEMCR      (*(volatile uint32_t *)0xE000EDFCu)
#define DWT_CTRL   (*(volatile uint32_t *)0xE0001000u)
#define DWT_CYCCNT (*(volatile uint32_t *)0xE0001004u)

ring_t rx_ring;
volatile uint32_t tick_count;
int lab_have_dwt;
volatile uint32_t isr_body[LAB_SAMPLES];
volatile uint32_t isr_body_n;

int lab_dwt_start(void)
{
    DEMCR |= 1u << 24;              /* TRCENA */
    DWT_CYCCNT = 0;
    DWT_CTRL |= 1u;                 /* CYCCNTENA */
    __asm volatile ("dsb\n\tisb" ::: "memory");
    uint32_t before = DWT_CYCCNT;
    for (int i = 0; i < 64; i++) __asm volatile ("nop");
    return DWT_CYCCNT != before;
}

void UART0_Handler(void)
{
    uint32_t t0 = lab_have_dwt ? DWT_CYCCNT : 0u;   /* ISR-TÖRZS eleje (nem az esemény ideje) */
    if (UART0->INTSTATUS & (1u << 1)) {             /* RXINT */
        UART0->INTSTATUS = 1u << 1;                 /* nyugtázás (W1C) */
        ring_push(&rx_ring, (uint8_t)UART0->DATA);  /* a DATA olvasása üríti az RXFULL-t */
    }
    if (lab_have_dwt && isr_body_n < LAB_SAMPLES)   /* csak mentés; formázás a fő programban */
        isr_body[isr_body_n++] = DWT_CYCCNT - t0;
}

void TIMER0_Handler(void)
{
    TIMER0->INTSTATUS = 1u;         /* nyugtázás (W1C) */
    tick_count++;                   /* egyetlen író: nincs RMW-verseny a fő programmal */
}
