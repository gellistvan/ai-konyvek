#!/usr/bin/env python3
"""Teszt-DUT a lab-m19 soros protokolljához; a hibamódok a rendszerteszt ellenpróbái."""
import sys
import threading
import time

mode = sys.argv[1] if len(sys.argv) > 1 else 'ok'
hz = 200 if mode == 'fast' else 100
M_REPLY = {'m-n0': 'isr_body: n=0', 'm-bad': 'isr_body: n=64 min=30 max=20 mean=25',
           'm-ok': 'isr_body: n=64 min=18 max=25 mean=21', 'm-wide': 'isr_body: n=64 min=18 max=90 mean=30'}
lock = threading.Lock()
t0 = time.monotonic()
base = 0
data_count = 0

def out(s):
    with lock:
        sys.stdout.write(s)
        sys.stdout.flush()

def ticks():
    return int((time.monotonic() - t0) * hz)

def ticker():
    seen = 0
    while True:
        time.sleep(0.002)
        now = ticks()
        while seen < now:
            seen += 1
            if seen % 100 == 0:
                out('tick\r\n')

out('lab-m19 boot\r\n')
threading.Thread(target=ticker, daemon=True).start()
pending = None
while True:
    c = sys.stdin.read(1)
    if not c:
        break
    if c == 'S' and mode == 'nostatus':
        continue                             # 'nostatus': a payloadot visszaechozza, az S választ elnyeli
    if c == 'S':
        if pending:
            out(pending); pending = None
        raw = ticks()
        out(f'status: ticks={raw - base} overrun=0 raw={raw}\r\n')
    elif c == 'R':
        new = ticks()
        if mode != 'noreset':                # 'noreset': a választ megadja, a bázist nem állítja
            base = new
        out(f'reset ok base={new}\r\n')
    elif c == 'M':
        out(M_REPLY.get(mode, 'isr_body: SKIP (DWT CYCCNT nem halad)') + '\r\n')
    else:
        data_count += 1
        if mode == 'extra' and data_count == 27:
            out(c + c)                       # egy bájt duplikálva: 51 bájt
        elif mode == 'swap' and data_count == 27:
            pending = c                      # a 27. bájtot a 28. után küldjük
        elif mode == 'swap' and pending is not None:
            out(c + pending); pending = None
        elif mode == 'drop' and data_count == 27:
            pass                             # egy bájt hiányzik
        else:
            out(c)
