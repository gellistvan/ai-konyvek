#!/usr/bin/env python3
# objdump -d --disassemble=SYM --no-show-raw-insn FILE helyettesítő (capstone), GNU-szerű kimenettel
import sys
from elftools.elf.elffile import ELFFile
from capstone import *
sym = [a.split('=',1)[1] for a in sys.argv if a.startswith('--disassemble=')][0]
f = ELFFile(open(sys.argv[-1], 'rb'))
s = [x for x in f.get_section_by_name('.symtab').iter_symbols() if x.name == sym][0]
data = f.get_section(s['st_shndx']).data()
end = s['st_value'] + s['st_size'] if s['st_size'] else len(data)
print(f"{s['st_value']:016x} <{sym}>:")
for i in Cs(CS_ARCH_ARM64, CS_MODE_ARM).disasm(data[s['st_value']:end], s['st_value']):
    print(f"{i.address:8x}:\t{i.mnemonic}\t{i.op_str}".rstrip())
