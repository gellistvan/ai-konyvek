#!/usr/bin/env python3
"""Minimal objdump -d substitute for Thumb (Cortex-M) ELF files, via capstone.

Usage: thumb-dump.py file.o|file.elf [section ...]   (default: every executable section)

Each line shows the address, the instruction as objdump prints it (16-bit
halfwords, first halfword first), the raw bytes in memory order, and the
disassembly. Data sections can be dumped as words with --words SECTION.
"""
import struct
import sys

from capstone import Cs, CS_ARCH_ARM, CS_MODE_THUMB, CS_MODE_MCLASS
from elftools.elf.elffile import ELFFile
from elftools.elf.sections import SymbolTableSection


def main(argv):
    words = []
    if '--words' in argv:
        i = argv.index('--words')
        words = [argv[i + 1]]
        del argv[i:i + 2]
    path, wanted = argv[0], argv[1:]
    md = Cs(CS_ARCH_ARM, CS_MODE_THUMB | CS_MODE_MCLASS)
    with open(path, 'rb') as f:
        elf = ELFFile(f)
        syms = {}
        for sec in elf.iter_sections():
            if isinstance(sec, SymbolTableSection):
                for s in sec.iter_symbols():
                    if s.name and not s.name.startswith('$') and s['st_info']['type'] in ('STT_FUNC', 'STT_NOTYPE', 'STT_OBJECT') \
                            and s['st_shndx'] not in ('SHN_UNDEF', 'SHN_ABS'):
                        syms.setdefault((s['st_shndx'], s['st_value'] & ~1), s.name)
        for idx, sec in enumerate(elf.iter_sections()):
            name = sec.name
            if name in words:
                data, base = sec.data(), sec['sh_addr']
                print(f'Contents of section {name} (32-bit little-endian words):')
                for off in range(0, len(data) - len(data) % 4, 4):
                    print(f'  {base + off:08x}: {struct.unpack_from("<I", data, off)[0]:08x}')
                continue
            if wanted and name not in wanted:
                continue
            if not wanted and not (sec['sh_flags'] & 0x4):  # SHF_EXECINSTR
                continue
            if sec['sh_type'] == 'SHT_NOBITS':
                continue
            data, base = sec.data(), sec['sh_addr']
            print(f'\nDisassembly of section {name}:')
            for insn in md.disasm(data, base):
                lab = syms.get((idx, insn.address))
                if lab:
                    print(f'\n{insn.address:08x} <{lab}>:')
                b = bytes(insn.bytes)
                hw = ' '.join(f'{struct.unpack_from("<H", b, i)[0]:04x}' for i in range(0, len(b), 2))
                raw = ' '.join(f'{x:02x}' for x in b)
                print(f'{insn.address:8x}:\t{hw:<10}\t[{raw:<11}]\t{insn.mnemonic}\t{insn.op_str}')


if __name__ == '__main__':
    main(sys.argv[1:])
