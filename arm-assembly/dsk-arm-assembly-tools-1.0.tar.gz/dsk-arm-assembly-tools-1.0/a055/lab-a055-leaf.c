/* lab-a055-leaf.c — levélfüggvény: nem hív mást, az LR-t nem menti */
unsigned long lab_leaf(unsigned long x) { return 3 * x + 1; }
