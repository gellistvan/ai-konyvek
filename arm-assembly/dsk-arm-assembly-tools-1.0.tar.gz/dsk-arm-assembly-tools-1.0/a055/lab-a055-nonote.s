// lab-a055-nonote.s — kézzel írt kiegészítő objektum, szándékosan feature-jegyzet nélkül
    .text
    .global lab_extra
    .type   lab_extra, %function
lab_extra:
    ret
    .size   lab_extra, . - lab_extra
    .section .note.GNU-stack,"",%progbits
