/* lab-a055-main.c — hívó és lab_sink; külön fordítási egység, ezért a
 * lab-a055-vuln.c fordításakor a lab_sink nem ágyazható be (LTO nélkül) */
#include <stdio.h>

void lab_vulnerable(const char *input, unsigned long len);

void lab_sink(const char *buf, unsigned long n)
{
    printf("lab_sink: %lu bajt: \"%.*s\"\n", n, (int)n, buf);
}

int main(void)
{
    lab_vulnerable("labor a055", 16);   /* 10 bájt + '\0': belefér a 16 bájtos pufferbe */
    return 0;
}
