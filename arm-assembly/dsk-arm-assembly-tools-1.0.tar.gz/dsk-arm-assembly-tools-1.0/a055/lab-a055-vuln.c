/* lab-a055-vuln.c — a vizsgált függvény; a puffert egy másik fordítási egység olvassa */
extern void lab_sink(const char *buf, unsigned long n);

void lab_vulnerable(const char *input, unsigned long len)
{
    char buf[16];
    unsigned long i;
    for (i = 0; i < len && input[i] != '\0'; i++)
        buf[i] = input[i];     /* hosszellenőrzés nincs: len > 16 esetén túlír */
    lab_sink(buf, i);          /* a puffer tartalma megfigyelhető: a tárolások maradnak */
}
