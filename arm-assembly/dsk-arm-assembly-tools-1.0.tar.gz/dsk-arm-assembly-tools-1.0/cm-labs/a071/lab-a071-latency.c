/* lab-a071-latency.c — szoftveres NVIC-pending latenciapróba (IRQ6),
 * megfigyelhető PASS/FAIL/SKIP kimenettel (semihosting) */
#include <stdint.h>
#define REG32(a) (*(volatile uint32_t *)(uintptr_t)(a))

#define DEMCR       REG32(0xE000EDFCu)
#define DWT_CTRL    REG32(0xE0001000u)
#define DWT_CYCCNT  REG32(0xE0001004u)
#define NVIC_ISER0  REG32(0xE000E100u)
#define NVIC_ISPR0  REG32(0xE000E200u)
#define TEST_IRQ    6u
#define N           256u

static volatile uint32_t t0, t1, done;
static volatile uint32_t hist[32], above_hist;

void lab_irq_isr(void)
{
    t1 = DWT_CYCCNT;
    uint32_t d = t1 - t0;
    if (d < 32u) hist[d]++;
    else above_hist++;
    done++;
}

static void sh_call(uint32_t op, const void *arg)
{
    register uint32_t r0 asm("r0") = op;
    register const void *r1 asm("r1") = arg;
    asm volatile ("bkpt 0xab" : "+r"(r0) : "r"(r1) : "memory");
}

_Noreturn static void finish(const char *line, int fail)
{
    sh_call(0x04u, line);                                          /* SYS_WRITE0 */
    sh_call(0x18u, (const void *)(fail ? 0x20023u : 0x20026u));    /* SYS_EXIT   */
    for (;;) { }
}

/* Egyetlen szoftveres pending; 1, ha a kezelő a korláton belül lefutott. */
static int trigger_once(void)
{
    uint32_t before = done;
    t0 = DWT_CYCCNT;
    NVIC_ISPR0 = 1u << TEST_IRQ;
    __asm volatile("dsb\n\tisb" ::: "memory");
    for (uint32_t limit = 1000000u; done == before && limit; --limit) { }
    return done != before;
}

int main(void)
{
    NVIC_ISER0 = 1u << TEST_IRQ;

    /* 1. Funkcionális próba, a DWT-től függetlenül: eléri-e a kérés a kezelőt? */
    if (!trigger_once())
        finish("LATENCY: FAIL (az IRQ6 kérés nem érte el a lab_irq_isr-t)\n", 1);

    /* 2. Halad-e a ciklusszámláló? Ha nem, mérni nem lehet: SKIP. */
    DEMCR |= 1u << 24;                    /* TRCENA    */
    DWT_CYCCNT = 0;
    DWT_CTRL |= 1u;                       /* CYCCNTENA */
    __asm volatile("dsb\n\tisb" ::: "memory");
    uint32_t before = DWT_CYCCNT;
    for (unsigned i = 0; i < 64; ++i) __asm volatile("nop");
    if (DWT_CYCCNT == before)
        finish("LATENCY: SKIP (a DWT CYCCNT nem halad; az IRQ6 kiszolgálása működik)\n", 0);

    /* 3. Mérés: N minta hisztogramba. */
    for (unsigned k = 0; k < 32; ++k) hist[k] = 0;
    above_hist = 0;
    for (uint32_t i = 0; i < N; i++)
        if (!trigger_once())
            finish("LATENCY: FAIL (elmaradt megszakítás a mérés közben)\n", 1);
    uint32_t sum = above_hist;
    for (unsigned k = 0; k < 32; ++k) sum += hist[k];
    if (sum != N)
        finish("LATENCY: FAIL (hist + above_hist != 256)\n", 1);
    finish("LATENCY: PASS (256 minta; a hist[] GDB-vel olvasható)\n", 0);
}
