/* lab-startup.s — a II. rész kanonikus startup kódja
 * ISA: Thumb-2 / Armv7-M; Target: qemu-system-arm -machine mps2-an385
 * Szerződés a lab-mps2.ld-vel: _sidata, _sdata, _edata, _sbss, _ebss
 * mind 4 bájtra igazított (a linker script ASSERT-tel ellenőrzi). */
    .syntax unified
    .cpu cortex-m3
    .thumb

    .section .vectors, "a", %progbits
    .align 2
    .global __vectors
__vectors:
    .word _estack                 /* 0x00: kezdeti SP (MSP)      */
    .word Reset_Handler           /* 0x04: Reset (bit0 = 1)      */
    .word NMI_Handler             /* 0x08: NMI                   */
    .word HardFault_Handler       /* 0x0C: HardFault             */
    .word MemManage_Handler       /* 0x10: MemManage             */
    .word BusFault_Handler        /* 0x14: BusFault              */
    .word UsageFault_Handler      /* 0x18: UsageFault            */
    .word 0, 0, 0, 0              /* 0x1C-0x28: fenntartott      */
    .word SVC_Handler             /* 0x2C: SVCall                */
    .word DebugMon_Handler        /* 0x30: DebugMonitor          */
    .word 0                       /* 0x34: fenntartott           */
    .word PendSV_Handler          /* 0x38: PendSV                */
    .word SysTick_Handler         /* 0x3C: SysTick               */
    /* 16-tól: külső IRQ-k; a tesztvonal IRQ6 = 22. index, előtte 6 helyet ki kell tölteni */
    .rept 6
    .word Default_Handler         /* 0x40-0x54: IRQ0-IRQ5 (itt nem használt) */
    .endr
    .word lab_irq_isr             /* 0x58: IRQ6 (szoftveres NVIC-pending)    */

    .text
    .thumb_func
    .global Reset_Handler
    .type   Reset_Handler, %function
Reset_Handler:
    /* 1. .data másolása FLASH (LMA) -> RAM (VMA), szavanként.
       Elöltesztelő ciklus, előjel nélküli összehasonlítással: üres
       szekciónál egyszer sem fut, és a végcímen pontosan megáll. */
    ldr   r0, =_sidata
    ldr   r1, =_sdata
    ldr   r2, =_edata
1:  cmp   r1, r2
    bhs   2f
    ldr   r3, [r0], #4
    str   r3, [r1], #4
    b     1b
    /* 2. .bss nullázása, szavanként. */
2:  ldr   r1, =_sbss
    ldr   r2, =_ebss
    movs  r3, #0
3:  cmp   r1, r2
    bhs   4f
    str   r3, [r1], #4
    b     3b
    /* 3. main(); ha visszatérne, végtelen ciklus. */
4:  bl    main
5:  b     5b
    .size Reset_Handler, . - Reset_Handler

    .thumb_func
    .global Default_Handler
    .type   Default_Handler, %function
Default_Handler:
    b     .
    .size Default_Handler, . - Default_Handler

    /* Gyenge aliasok: amit a firmware nem definiál, az a Default_Handlerre fut. */
    .macro lab_default_handler name
    .weak       \name
    .thumb_set  \name, Default_Handler
    .endm
    lab_default_handler NMI_Handler
    lab_default_handler HardFault_Handler
    lab_default_handler MemManage_Handler
    lab_default_handler BusFault_Handler
    lab_default_handler UsageFault_Handler
    lab_default_handler SVC_Handler
    lab_default_handler DebugMon_Handler
    lab_default_handler PendSV_Handler
    lab_default_handler SysTick_Handler
    lab_default_handler lab_irq_isr
