/* lab-a071-systick.c — kontrollált preempciós próba (2. feladat): az IRQ6-kérést
 * a magasabb prioritású SysTick kezelő ismert pontján adjuk ki */
#include <stdint.h>
#define REG32(a) (*(volatile uint32_t *)(uintptr_t)(a))

#define DEMCR       REG32(0xE000EDFCu)
#define DWT_CTRL    REG32(0xE0001000u)
#define DWT_CYCCNT  REG32(0xE0001004u)
#define NVIC_ISER0  REG32(0xE000E100u)
#define NVIC_ISPR0  REG32(0xE000E200u)
#define NVIC_IPR1   REG32(0xE000E404u)    /* IRQ4..IRQ7 prioritásbájtjai     */
#define SCB_ICSR    REG32(0xE000ED04u)    /* bit 26: PENDSTSET               */
#define SCB_SHPR3   REG32(0xE000ED20u)    /* bit 31:24: a SysTick prioritása */
#define TEST_IRQ    6u
#define WORK        400u                  /* a SysTick kezelő munkaegységei  */

static volatile uint32_t work, req_at, entry_at, t0, t1, done, req_point;

void SysTick_Handler(void)                /* nyers prioritás 0x20: magasabb  */
{
    for (uint32_t i = 0; i < WORK; i++) {
        if (i == req_point) {             /* ismert pont: időbélyeg, kérés   */
            req_at = work;
            t0 = DWT_CYCCNT;
            NVIC_ISPR0 = 1u << TEST_IRQ;  /* alacsonyabb prioritás: pending  */
        }
        work++;                           /* egy munkaegység                 */
    }
}

void lab_irq_isr(void)                    /* IRQ6, nyers prioritás 0x80      */
{
    t1 = DWT_CYCCNT;
    entry_at = work;
    done++;
}

static void sh_call(uint32_t op, const void *arg)
{
    register uint32_t r0 asm("r0") = op;
    register const void *r1 asm("r1") = arg;
    asm volatile ("bkpt 0xab" : "+r"(r0) : "r"(r1) : "memory");
}

static void put(const char *s) { sh_call(0x04u, s); }                 /* SYS_WRITE0 */

static void put_u32(uint32_t v)
{
    char buf[11], *p = buf + sizeof buf - 1;
    *p = '\0';
    do { *--p = (char)('0' + v % 10u); v /= 10u; } while (v);
    put(p);
}

_Noreturn static void finish(const char *line, int fail)
{
    put(line);
    sh_call(0x18u, (const void *)(fail ? 0x20023u : 0x20026u));    /* SYS_EXIT   */
    for (;;) { }
}

int main(void)
{
    SCB_SHPR3 = (SCB_SHPR3 & 0x00FFFFFFu) | (0x20u << 24);
    NVIC_IPR1 = (NVIC_IPR1 & ~(0xFFu << 16)) | (0x80u << 16);   /* IRQ6: bit 23:16  */
    NVIC_ISER0 = 1u << TEST_IRQ;

    DEMCR |= 1u << 24;                    /* TRCENA    */
    DWT_CYCCNT = 0;
    DWT_CTRL |= 1u;                       /* CYCCNTENA */
    __asm volatile("dsb\n\tisb" ::: "memory");
    uint32_t c0 = DWT_CYCCNT;
    for (unsigned i = 0; i < 64; ++i) __asm volatile("nop");
    int dwt = DWT_CYCCNT != c0;

    static const uint32_t pct[3] = { 25u, 50u, 75u };
    uint32_t lat[3];
    for (unsigned k = 0; k < 3; k++) {
        req_point = pct[k] * WORK / 100u;
        work = 0;
        uint32_t before = done;
        SCB_ICSR = 1u << 26;              /* SysTick szoftveres pendingelése */
        __asm volatile("dsb\n\tisb" ::: "memory");
        for (uint32_t limit = 1000000u; done == before && limit; --limit) { }
        if (done == before)
            finish("PREEMPT: FAIL (az IRQ6 nem futott le)\n", 1);
        /* Sorrend: t0 és a kérés a SysTick-ben, belépés csak a SysTick után. */
        if (entry_at != WORK || req_at != req_point)
            finish("PREEMPT: FAIL (az IRQ6 a SysTick vége előtt lépett be)\n", 1);
        lat[k] = t1 - t0;
        put("p = ");
        put_u32(pct[k]);
        put("%: hátralevő munka = ");
        put_u32(entry_at - req_at);
        put(" egység, t1 - t0 = ");
        if (dwt) { put_u32(lat[k]); put(" ciklus\n"); }
        else put("SKIP (a DWT CYCCNT nem halad)\n");
    }
    if (!dwt)
        finish("PREEMPT: PASS (sorrend), késés: SKIP (a DWT CYCCNT nem halad)\n", 0);
    if (!(lat[0] > lat[1] && lat[1] > lat[2]))
        finish("PREEMPT: FAIL (a késés nem csökken a hátralevő munkával)\n", 1);
    finish("PREEMPT: PASS (sorrend és csökkenő késés)\n", 0);
}
