// lab-uart.h
#ifndef LAB_UART_H
#define LAB_UART_H

#include <stdint.h>

#define UART0_BASE 0x40004000UL
#define UART0_IRQn 0  // AN385: UART0 RX = IRQ0, TX = IRQ1 (lásd a072/a079)

typedef struct {
    volatile uint32_t DATA;
    volatile uint32_t STATE;
    volatile uint32_t CTRL;
    volatile uint32_t INTSTATUS;
    volatile uint32_t BAUDDIV;
} CMSDK_UART_TypeDef;

#define UART0 ((CMSDK_UART_TypeDef *) UART0_BASE)

#define UART_CTRL_TXEN  (1U << 0)
#define UART_CTRL_RXEN  (1U << 1)
#define UART_CTRL_TXIE  (1U << 2)
#define UART_CTRL_RXIE  (1U << 3)

#define UART_STATE_TXFULL (1U << 0)
#define UART_STATE_RXFULL (1U << 1)

#define UART_INTSTATUS_TXINT (1U << 0)
#define UART_INTSTATUS_RXINT (1U << 1)

void uart_init(uint32_t uartclk, uint32_t baudrate);
void uart_putc(char c);
int  uart_getc(void);
int  uart_available(void);

#endif
