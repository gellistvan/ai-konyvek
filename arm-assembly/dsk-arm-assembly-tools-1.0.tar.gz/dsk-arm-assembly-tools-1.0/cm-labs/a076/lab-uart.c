// lab-uart.c
#include "lab-uart.h"

#define RX_BUF_SIZE 64  // 2 hatványa
static volatile char     rx_buf[RX_BUF_SIZE];
static volatile uint32_t rx_head = 0; // csak az ISR írja
static volatile uint32_t rx_tail = 0; // csak a fő ciklus írja

void uart_init(uint32_t uartclk, uint32_t baudrate) {
    UART0->CTRL = 0; // kikapcsolás
    UART0->BAUDDIV = uartclk / baudrate; // baudrate = UARTCLK / BAUDDIV
    UART0->CTRL = UART_CTRL_TXEN | UART_CTRL_RXEN | UART_CTRL_RXIE;
}

void uart_putc(char c) {
    while (UART0->STATE & UART_STATE_TXFULL) {
        // vár, amíg az adó puffer kiürül
    }
    UART0->DATA = (uint32_t)(uint8_t)c;
}

int uart_getc(void) {
    if (rx_head == rx_tail) {
        return -1;
    }
    uint8_t c = (uint8_t)rx_buf[rx_tail];
    rx_tail = (rx_tail + 1) & (RX_BUF_SIZE - 1);
    return (int)c;
}

int uart_available(void) {
    return (rx_head != rx_tail);
}

void UART0_Handler(void) {
    uint32_t status = UART0->INTSTATUS;
    if (status & UART_INTSTATUS_RXINT) {
        // write-1-to-clear: torli az INTSTATUS.RXINT-et
        UART0->INTSTATUS = UART_INTSTATUS_RXINT;
        char c = (char)(UART0->DATA & 0xFF);     // olvasás törli a STATE.RXFULL-t
        uint32_t next = (rx_head + 1) & (RX_BUF_SIZE - 1);
        if (next != rx_tail) {
            rx_buf[rx_head] = c;
            rx_head = next;
        }
        // else: túlcsordulás, a bájt elveszik
    }
    if (status & UART_INTSTATUS_TXINT) {
        UART0->INTSTATUS = UART_INTSTATUS_TXINT; // write-1-to-clear
        // Adási megszakítás kezelése; itt nem használjuk
    }
}
