// lab-main.c
#include "lab-uart.h"

static void nvic_enable_irq(int irqn) {
    volatile uint32_t *nvic_iser = (volatile uint32_t *)0xE000E100;
    nvic_iser[irqn / 32] = (1U << (irqn % 32));
}

int main(void) {
    uart_init(25000000, 115200); // feltételezett UARTCLK
    nvic_enable_irq(UART0_IRQn);

    const char *msg = "UART ready\r\n";
    for (const char *p = msg; *p; ++p) {
        uart_putc(*p);
    }

    while (1) {
        int c = uart_getc();
        if (c >= 0) {
            uart_putc((char)c); // echo
        }
    }
}
