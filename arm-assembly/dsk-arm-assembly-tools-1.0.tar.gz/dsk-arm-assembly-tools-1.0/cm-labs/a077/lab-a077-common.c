/* lab-a077-common.c — a két változat közös feladata */
#include "lab-a077-timer.h"

#define UART0_DATA    (*(volatile uint32_t *)0x40004000u)
#define UART0_STATE   (*(volatile uint32_t *)0x40004004u)
#define UART0_CTRL    (*(volatile uint32_t *)0x40004008u)
#define UART0_BAUDDIV (*(volatile uint32_t *)0x40004010u)

volatile uint32_t g_ticks;
volatile uint32_t g_blink;
static volatile uint32_t g_work_acc;

void lab_uart_init(void)
{
    UART0_BAUDDIV = 16u;
    UART0_CTRL    = 1u;                  /* TXEN */
}

void lab_uart_puts(const char *s)
{
    while (*s) {
        while (UART0_STATE & 1u) { }     /* amíg TXFULL = 1, várunk */
        UART0_DATA = (uint8_t)*s++;
    }
}

void lab_tick_task(uint32_t tick)
{
    if (tick % LAB_TICKS_PER_LINE == 0u) {   /* 100 tickenként (1 s): */
        g_blink ^= 1u;                       /*   állapotbillentés     */
        lab_uart_puts("tick\n");             /*   és egy kimeneti sor  */
    }
}

void lab_work_step(void)
{
    uint32_t acc = g_work_acc;               /* rögzített mennyiségű "hasznos munka" */
    for (uint32_t i = 0; i < 64u; i++)
        acc = acc * 1664525u + 1013904223u;
    g_work_acc = acc;
}
