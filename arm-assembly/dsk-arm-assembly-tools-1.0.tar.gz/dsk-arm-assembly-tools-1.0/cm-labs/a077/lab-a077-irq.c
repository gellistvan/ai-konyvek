/* lab-a077-irq.c — timer-megszakításos változat, versenymentes alvással.
 * LAB_MEASURE = 1 mellett KÜLÖN méri (1) az ISR törzsidejét a DWT CYCCNT-tel,
 * (2) egy közös, LAB_TICKS_PER_LINE tickes ablak teljes idejét és (3) az
 * ugyanebben az ablakban alvással töltött időt. A (2) és (3) időalapja a
 * szabadon futó TIMER1: ugyanazon az APB-órán jár, mint az ébresztő TIMER0. */
#include "lab-a077-timer.h"

#ifndef LAB_MEASURE
#define LAB_MEASURE 1
#endif

#define DEMCR       (*(volatile uint32_t *)0xE000EDFCu)
#define DWT_CTRL    (*(volatile uint32_t *)0xE0001000u)
#define DWT_CYCCNT  (*(volatile uint32_t *)0xE0001004u)
#define TIMER1      ((cmsdk_timer_t *)(uintptr_t)0x40001000u)   /* időalap, IRQ nélkül */

static int g_have_dwt, g_have_t1;                 /* futásidőben eldöntve */
static volatile uint32_t g_isr_body, g_isr_n;     /* ISR-törzs összesen [CYCCNT-ciklus] */
static uint32_t g_sleep;                          /* alvás a futó ablakban [TIMER1-ciklus] */

void timer0_init_periodic(uint32_t reload)
{
    TIMER0->CTRL      = 0;          /* állj, megszakítás tiltva */
    TIMER0->INTSTATUS = 1;          /* függő kérés törlése (INTCLEAR, W1C) */
    TIMER0->RELOAD    = reload;     /* a RELOAD írása az aktuális értéket is beállítja,
                                       ezért az első periódus is (reload+1) ciklus */
    TIMER0->CTRL      = TIMER_CTRL_ENABLE | TIMER_CTRL_INTEN;
}

void TIMER0_IRQHandler(void)
{
    uint32_t t_in = g_have_dwt ? DWT_CYCCNT : 0u;   /* mérőpont: a törzs eleje */
    TIMER0->INTSTATUS = 1;          /* nyugtázás - ELŐBB, mint a munka */
    g_ticks++;
    if (g_have_dwt) {
        g_isr_body += DWT_CYCCNT - t_in;            /* mérőpont: a törzs vége */
        g_isr_n++;
    }
}

static int dwt_start(void)
{
    DEMCR    |= 1u << 24;           /* TRCENA */
    DWT_CYCCNT = 0;
    DWT_CTRL |= 1u;                 /* CYCCNTENA */
    __asm volatile ("dsb\n\tisb" ::: "memory");
    uint32_t before = DWT_CYCCNT;
    for (int i = 0; i < 64; i++) __asm volatile ("nop");
    return DWT_CYCCNT != before;    /* aktív futás alatt halad-e? (alvásról nem mond semmit) */
}

static int timebase_start(void)     /* TIMER1: szabadon futó, 32 bites lefelé számláló */
{
    TIMER1->CTRL   = 0;
    TIMER1->RELOAD = 0xFFFFFFFFu;
    TIMER1->CTRL   = TIMER_CTRL_ENABLE;              /* megszakítás nélkül */
    uint32_t before = TIMER1->VALUE;
    for (uint32_t limit = 100000u; limit; --limit)   /* korlátos várakozás az első lépésre */
        if (TIMER1->VALUE != before)
            return 1;
    return 0;
}

static void put_u32(uint32_t v)
{
    char buf[11], *p = buf + 10;
    *p = '\0';
    do { *--p = (char)('0' + v % 10u); v /= 10u; } while (v);
    lab_uart_puts(p);
}

/* Egy teljes ablak jelentése. win és sleep ugyanabból az időalapból és ugyanarra
 * a [kezdet, vég) ablakra vonatkozik, ezért 0 <= sleep <= win. */
static void report(uint32_t win, uint32_t sleep, uint32_t cyc)
{
    const uint32_t expect = LAB_TICKS_PER_LINE * (reload_for_ms(LAB_TICK_MS) + 1u);
    if (win < expect - expect / 10u) {          /* az ismert ébresztési időközhöz képest */
        lab_uart_puts("SKIP: a TIMER1 alvas kozben nem jar, alvasmeres nincs\n");
        return;
    }
    uint32_t per_mille = (win - sleep) / (win / 1000u);
    if (per_mille > 1000u) per_mille = 1000u;
    lab_uart_puts("ablak=");          put_u32(win);
    lab_uart_puts(" alvas=");         put_u32(sleep);
    lab_uart_puts(" aktiv_ezrelek="); put_u32(per_mille);
    if (g_have_dwt) {
        lab_uart_puts(" isr_torzs_atlag="); put_u32(g_isr_body / g_isr_n);
        lab_uart_puts(cyc + win / 10u < win ? " cyccnt_alvasban=megall"
                                            : " cyccnt_alvasban=jar");
    }
    lab_uart_puts("\n");
}

int main(void)
{
    lab_uart_init();
    g_have_dwt = LAB_MEASURE && dwt_start();
    g_have_t1  = LAB_MEASURE && timebase_start();
    if (LAB_MEASURE && !g_have_dwt)
        lab_uart_puts("SKIP: DWT CYCCNT nem halad, ISR-torzsmeres nincs\n");
    if (LAB_MEASURE && !g_have_t1)
        lab_uart_puts("SKIP: a TIMER1 idoalap nem jar, ablak- es alvasmeres nincs\n");

    timer0_init_periodic(reload_for_ms(LAB_TICK_MS));
    *(volatile uint32_t *)0xE000E100u = 1u << TIMER0_IRQ;   /* NVIC_ISER0 */

    uint32_t seen = 0, win_t1 = 0, win_cyc = 0;
    int have_win = 0;
    for (;;) {
        while (seen != g_ticks) {           /* minden elmaradt tickre ugyanaz a munka */
            seen++;
            lab_tick_task(seen);
            lab_work_step();
            if (g_have_t1 && seen % LAB_TICKS_PER_LINE == 0u) {
                uint32_t now = TIMER1->VALUE;
                uint32_t now_cyc = g_have_dwt ? DWT_CYCCNT : 0u;
                if (have_win)                /* az első, részleges ablakot eldobjuk */
                    /* lefelé számol; modulo 2^32 */
                    report(win_t1 - now, g_sleep, now_cyc - win_cyc);
                /* az új ablak kezdete: mindkét mennyiség nulláról */
                win_t1 = now;
                win_cyc = now_cyc;
                g_sleep = 0;
                have_win = 1;
            }
        }
        __asm volatile ("cpsid i" ::: "memory");   /* versenymentes alvás (a075) */
        if (seen == g_ticks) {
            uint32_t t0 = g_have_t1 ? TIMER1->VALUE : 0u;
            __asm volatile ("dsb\n\twfi" ::: "memory");
            if (g_have_t1) g_sleep += t0 - TIMER1->VALUE;   /* még az ISR előtt (PRIMASK = 1) */
        }
        __asm volatile ("cpsie i" ::: "memory");
    }
}
