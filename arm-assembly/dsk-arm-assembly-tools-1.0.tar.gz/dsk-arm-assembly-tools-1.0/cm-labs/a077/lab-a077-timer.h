/* lab-a077-timer.h — CMSDK APB timer és a két változat közös része */
#include <stdint.h>

typedef struct {
    volatile uint32_t CTRL;       /* 0x000 */
    volatile uint32_t VALUE;      /* 0x004 — írás: az aktuális érték beállítása */
    volatile uint32_t RELOAD;     /* 0x008 — írás: a RELOAD ÉS az aktuális érték is */
    volatile uint32_t INTSTATUS;  /* 0x00C — olvasás: INTSTATUS; írás: INTCLEAR (W1C) */
} cmsdk_timer_t;

#define TIMER0_BASE  ((uintptr_t)0x40000000u)
#define TIMER0       ((cmsdk_timer_t *)TIMER0_BASE)
#define TIMER0_IRQ   8u

#define TIMER_CTRL_ENABLE   (1u << 0)
#define TIMER_CTRL_INTEN    (1u << 3)

/* A timer órajel-frekvenciája platformfüggő laborparaméter; 25 MHz illusztratív. */
#define TIMER_FREQ_HZ       25000000u
#define LAB_TICK_MS         10u        /* egy tick */
#ifndef LAB_TICKS_PER_LINE
#define LAB_TICKS_PER_LINE  100u       /* kimeneti periódus és mérési ablak: 100 tick = 1 s */
#endif

static inline uint32_t reload_for_ms(uint32_t ms)
{
    return (TIMER_FREQ_HZ / 1000u) * ms - 1u;   /* T = (RELOAD+1)/f */
}

extern volatile uint32_t g_ticks;    /* tickszámláló */
extern volatile uint32_t g_blink;    /* a periodikus feladat állapota */

void lab_uart_init(void);
void lab_uart_puts(const char *s);
void lab_tick_task(uint32_t tick);   /* AZONOS állapotváltozás és kimenet mindkét változatban */
void lab_work_step(void);            /* AZONOS hasznos munka tickenként mindkét változatban */
