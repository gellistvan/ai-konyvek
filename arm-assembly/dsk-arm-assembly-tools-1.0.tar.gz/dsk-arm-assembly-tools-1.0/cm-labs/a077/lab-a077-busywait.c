/* lab-a077-busywait.c — busy-wait változat: ugyanaz a tick, kimenet és munka */
#include "lab-a077-timer.h"

/* Iterációk egy tickhez. Az iteráció költsége (subs + bne + nop, plusz a
   betöltések) nem egy ciklus, és fordítófüggő: LAB_DELAY_ITERS = T * f / c,
   ahol c-t a disassemblyből becsüljük, majd hardveren DWT-vel mérjük. */
#ifndef LAB_DELAY_ITERS
#define LAB_DELAY_ITERS  (TIMER_FREQ_HZ / 1000u * LAB_TICK_MS / 4u)   /* c = 4 feltételezés */
#endif

static void delay_busywait(uint32_t n)
{
    while (n--) {
        __asm volatile ("nop");     /* a volatile asm miatt a ciklus nem tűnik el */
    }
}

int main(void)
{
    lab_uart_init();
    for (;;) {
        delay_busywait(LAB_DELAY_ITERS);    /* ~10 ms, ha c helyes */
        g_ticks++;
        lab_tick_task(g_ticks);             /* ugyanaz, mint az IRQ-változatban */
        lab_work_step();
    }
}
