/* lab-a070_isr.c  — Thumb-2 / Armv7-M ISA */
#include <stdint.h>

#define CMSDK_TIMER0_BASE     0x40000000UL   /* MPS2-AN385, CMSDK APB0 */
#define CMSDK_TIMER0_CTRL     (*(volatile uint32_t *)(CMSDK_TIMER0_BASE + 0x00))
#define CMSDK_TIMER0_RELOAD   (*(volatile uint32_t *)(CMSDK_TIMER0_BASE + 0x08))
/* Nincs külön INTCLR regiszter: az INTSTATUS-ba írt 1 törli a pendinget (write-1-to-clear). */
#define CMSDK_TIMER0_INTSTATUS (*(volatile uint32_t *)(CMSDK_TIMER0_BASE + 0x0C))

#define NVIC_ISER0           (*(volatile uint32_t *)0xE000E100UL)
#define TIMER0_IRQn          8u

#define TIMER_CTRL_ENABLE    (1u << 0)
#define TIMER_CTRL_IRQEN     (1u << 3)      /* bitpozíció: CMSDK spec. ellenőrizendő */

volatile uint32_t g_tick;       /* eseményszámláló: CSAK az ISR írja, monoton nő */
/* a főciklus által feldolgozott események; GDB-vel figyelhető */
volatile uint32_t g_events;

/* A szimbólumnév a vektortábla 0x60 offszetén lévő .word operandusa.   */
void TIMER0_IRQHandler(void)    /* nincs assembly trampolin, nincs prolog */
{
    CMSDK_TIMER0_INTSTATUS = 1u; /* 1. periféria pending-jelző törlése (write-1-to-clear) */
    g_tick++;                   /* 2. az esemény rögzítése; a főciklus ebből értesül */
}

int main(void)
{
    CMSDK_TIMER0_RELOAD  = 0x00FFFFFFu;         /* lassú, szemléltető periódus */
    CMSDK_TIMER0_CTRL    = TIMER_CTRL_ENABLE | TIMER_CTRL_IRQEN;
    /* esetleges korai pending törlése (write-1-to-clear) */
    CMSDK_TIMER0_INTSTATUS = 1u;
    NVIC_ISER0           = (1u << TIMER0_IRQn); /* engedélyezés, lásd a069 */

    uint32_t seen = 0;          /* a főciklus saját állapota: eddig látott események */
    for (;;) {
        uint32_t now = g_tick;  /* egyetlen igazított 32 bites olvasás */
        if (now != seen) {
            g_events += now - seen; /* az előző kör óta érkezett MINDEN esemény */
            seen = now;
        }
    }
}
