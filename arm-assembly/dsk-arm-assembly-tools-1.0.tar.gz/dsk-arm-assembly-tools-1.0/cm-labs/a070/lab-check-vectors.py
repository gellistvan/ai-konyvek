#!/usr/bin/env python3
"""lab-check-vectors.py — a vektortábla tulajdonságainak ellenőrzése egy ELF-en.

Használat: python3 lab-check-vectors.py lab-a064.elf [--relocated] [INDEX=SZIMBÓLUM ...]
Ellenőrzi: (1) van .vectors szekció, mérete szóhatáron van, és legalább a kezdeti
SP-t és a Reset-bejegyzést tartalmazza; (2) a .vectors a 0x00000000 címen kezdődik
(--relocated mellett ez nem kötelező); (3) a tábla bázisa VTOR-kompatibilis:
a 128 bájt és a táblaméretnél nem kisebb legkisebb kettőhatvány közül a nagyobbik
többszöröse; (4) a 0. szó (kezdeti SP) a RAM-régióba esik, vagy annak felső
határa, és 8 bájtra igazított; (5) az 1. szó (Reset) KÖTELEZŐ: nem nulla, páratlan
(Thumb-bit = 1), és a bit0 nélküli címe egy végrehajtható szekcióba esik;
(6) a fenntartott bejegyzések (7-10. és 13. index) nullák; (7) minden további nem
nulla kezelőbejegyzés páratlan, és kódszekcióba mutat (a nulla itt megengedett:
nincs kezelő); (8) minden INDEX=SZIMBÓLUM argumentumra a tábla INDEX-edik szava
létezik, és pontosan a SZIMBÓLUM értéke (pl. 1=Reset_Handler, 24=TIMER0_IRQHandler;
IRQn indexe 16 + n). Függőség: python3-pyelftools.
"""
import struct
import sys
from elftools.elf.elffile import ELFFile

RAM_LO, RAM_HI = 0x20000000, 0x20400000     # a kanonikus 4 MiB-os SRAM
RESERVED = (7, 8, 9, 10, 13)                # Armv7-M: fenntartott kivételszámok

args = [a for a in sys.argv[2:] if a != '--relocated']
relocated = '--relocated' in sys.argv[2:]
fails = 0
def check(ok, msg):
    global fails
    print(('OK   ' if ok else 'HIBA ') + msg)
    fails += not ok

with open(sys.argv[1], 'rb') as f:
    elf = ELFFile(f)
    vec = elf.get_section_by_name('.vectors')
    code = [(s['sh_addr'], s['sh_addr'] + s['sh_size'], s.name)
            for s in elf.iter_sections() if s['sh_flags'] & 0x4]      # SHF_EXECINSTR
    if vec is None:
        check(False, 'nincs .vectors szekció')
        sys.exit(1)
    size, base = vec['sh_size'], vec['sh_addr']
    if size % 4 or size < 8:
        check(False, f'.vectors mérete {size} bájt: nem szóhatáron végződik, '
                     'vagy kevesebb két szónál (SP + Reset)')
        sys.exit(1)
    check(True, f'.vectors mérete {size} bájt ({size // 4} szó)')
    check(relocated or base == 0, '.vectors a 0x00000000 címen' if not relocated
          else f'.vectors áthelyezve, bázis 0x{base:08x}')
    align = 128
    while align < size:
        align *= 2
    # VTOR: a bázis max(128, a táblaméretnél nem kisebb kettőhatvány) többszöröse
    check(base % align == 0, f'táblabázis 0x{base:08x}: {align} bájtra igazított (VTOR)')
    words = struct.unpack(f'<{size // 4}I', vec.data())
    sp = words[0]
    check(RAM_LO < sp <= RAM_HI and sp % 8 == 0,
          f'[0x00] kezdeti SP = 0x{sp:08x} (RAM, 8 bájtra igazított)')
    def in_code(w):
        target = w & ~1
        return target, next((n for lo, hi, n in code if lo <= target < hi), None)
    reset = words[1]
    target, sec = in_code(reset)
    check(reset != 0 and reset & 1 == 1 and sec is not None,
          f'[0x04] Reset (kötelező) 0x{reset:08x}: Thumb-bit={reset & 1}, cél 0x{target:08x} '
          + (f'a(z) {sec} szekcióban' if sec else 'NEM végrehajtható szekcióban'))
    nonzero_reserved = [i for i in RESERVED if i < len(words) and words[i] != 0]
    check(not nonzero_reserved, 'fenntartott bejegyzések (7–10., 13. index): '
          + ('mind 0' if not nonzero_reserved
             else 'NEM nulla: ' + ', '.join(map(str, nonzero_reserved))))
    for i, w in enumerate(words[2:], start=2):
        if w == 0 or i in RESERVED:
            continue
        target, sec = in_code(w)
        check(w & 1 == 1 and sec is not None,
              f'[0x{4 * i:02x}] 0x{w:08x}: Thumb-bit={w & 1}, cél 0x{target:08x} '
              + (f'a(z) {sec} szekcióban' if sec else 'NEM végrehajtható szekcióban'))
    symtab = elf.get_section_by_name('.symtab')
    for arg in args:
        idx, name = arg.split('=', 1)
        idx = int(idx, 0)
        syms = symtab.get_symbol_by_name(name) if symtab else None
        want = syms[0]['st_value'] if syms else None
        if idx >= len(words):
            check(False, f'[{idx}] = {name}: a tábla csak {len(words)} szó, '
                         f'a {idx}. slot hiányzik')
            continue
        got = words[idx]
        check(want is not None and got == want,
              f'[{idx}] = {name}: tábla 0x{got:08x}, szimbólum '
              + (f'0x{want:08x}' if want is not None else 'NINCS'))
    sys.exit(1 if fails else 0)
