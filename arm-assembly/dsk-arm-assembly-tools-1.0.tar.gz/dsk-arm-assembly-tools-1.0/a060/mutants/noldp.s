    .text
    .global lab_sgemm
lab_sgemm:
    stp x19, x20, [sp, #-32]!
    stp x21, x22, [sp, #16]
    mov x21, x0
    ldp x19, x20, [sp], #32
    ret
