    .text
    .global lab_sgemm
    .type lab_sgemm, %function
lab_sgemm:
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    add x0, x19, #1
    ldp x19, x20, [sp], #16
    ret
    .size lab_sgemm, .-lab_sgemm
