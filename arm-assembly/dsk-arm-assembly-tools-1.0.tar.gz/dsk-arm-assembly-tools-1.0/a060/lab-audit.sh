#!/bin/bash
# lab-audit.sh — a lab_sgemm ismert keretének statikus ellenőrzése
set -eu
python3 - "$@" <<'PY_AUDIT'
import argparse
import hashlib
import re
import subprocess
from pathlib import Path

# A callee-saved állapot (AAPCS64): X19-X29 és a V8-V15 alsó 64 bitje (D8-D15).
CALLEE = {f'x{i}' for i in range(19, 30)} | {f'd{i}' for i in range(8, 16)}
# Támogatott utasítások: amelyik nem ír általános vagy SIMD/FP regisztert ...
NOWRITE = {'str', 'strb', 'strh', 'stur', 'stp', 'stnp', 'st1', 'cmp', 'cmn', 'tst',
           'fcmp', 'fcmpe', 'ccmp', 'b', 'bl', 'blr', 'br', 'ret', 'cbz', 'cbnz', 'tbz',
           'tbnz', 'nop', 'dsb', 'dmb', 'isb', 'prfm', 'bti', 'paciasp', 'autiasp'}
# ... és amelyik az első operandusát (ldp/ld1 esetén a teljes listát) írja.
WRITE = {'add', 'adds', 'sub', 'subs', 'mul', 'madd', 'msub', 'umulh', 'smulh', 'udiv',
         'sdiv', 'lsl', 'lsr', 'asr', 'ror', 'and', 'ands', 'orr', 'eor', 'bic', 'mvn',
         'neg', 'mov', 'movz', 'movk', 'movn', 'adr', 'adrp', 'csel', 'cset', 'csinc',
         'ubfx', 'sbfx', 'bfi', 'uxtw', 'sxtw', 'ldr', 'ldrb', 'ldrh', 'ldrsw', 'ldur',
         'ldp', 'ld1', 'fmov', 'fadd', 'fsub', 'fmul', 'fdiv', 'fmadd', 'fmsub', 'fneg',
         'fabs', 'scvtf', 'ucvtf', 'fcvtzs', 'fcvtzu', 'movi', 'dup', 'ins', 'umov',
         'fmla', 'mla', 'addv', 'ext', 'rev64'}

def canon(reg):
    """W/X -> x<n>; B/H/S/D/Q/V (lane- és alakjelöléssel is) -> d<n>."""
    reg = reg.strip().lower()
    if (m := re.fullmatch(r'[wx](\d+)', reg)):
        return 'x' + m[1]
    if (m := re.fullmatch(r'[bhsdqv](\d+)(?:\.\w+)?(?:\[\d+\])?', reg)):
        return 'd' + m[1]
    return reg

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('image', type=Path, nargs='?', default=Path('lab_sgemm.o'))
parser.add_argument('--objdump', default='aarch64-linux-gnu-objdump')
parser.add_argument('--compare', type=Path)
args = parser.parse_args()
try:
    dump = subprocess.check_output(
        [args.objdump, '-d', '--disassemble=lab_sgemm', '--no-show-raw-insn',
         str(args.image)], text=True)
    if '<lab_sgemm>:' not in dump: raise ValueError('Hianyzik a lab_sgemm szimbolum')
    sp = 0; slots = {}; restored = set(); calls = False; returns = False
    written = set(); unsupported = set(); lowest = 0
    number = r'(-?(?:0x[0-9a-f]+|[0-9]+))'
    pair = re.compile(
        r'(stp|ldp)\s+([xd][0-9]+),\s*([xd][0-9]+),\s*'   # művelet és regiszterpár
        r'\[sp(?:,\s*#' + number + r')?\]'                 # [sp] vagy [sp, #off]
        r'(!)?'                                             # pre-index visszaírás
        r'(?:,\s*#' + number + r')?')                      # post-index lépés
    single = re.compile(r'(str|ldr)\s+([xd][0-9]+),\s*\[sp(?:,\s*#' + number + r')?\]')
    for line in dump.splitlines():
        match = re.match(r'\s*[0-9a-f]+:\s+(.*)', line)
        if not match: continue
        instruction = match[1].split('//')[0].strip()
        mnemonic, operands = (instruction.split(None, 1) + [''])[:2]
        calls |= mnemonic in ('bl', 'blr')
        returns |= instruction == 'ret'
        if (match := pair.fullmatch(instruction)) or (match := single.fullmatch(instruction)):
            op, regs = match[1], [r for r in match.groups()[1:3] if r and r[0] in 'xd']
            if op in ('stp', 'ldp'):
                offset, pre, post = int(match[4] or '0', 0), match[5], match[6]
            else:
                offset, pre, post = int(match[3] or '0', 0), None, None
            if pre: sp += offset
            lowest = min(lowest, sp)
            if sp % 16: raise ValueError('Nem 16 bajtos SP a memoriaeleresnel')
            address = sp + (0 if pre else offset)
            width = 8 * len(regs)
            if op in ('stp', 'str') and not (lowest <= address and address + width <= 0):
                raise ValueError(f'iras a keret hatarain kivul: SP0{address:+d}, {width} bajt')
            for register, position in zip(regs, (address, address + 8)):
                if op in ('stp', 'str'): slots[position] = register
                else:
                    if slots.get(position) != register:
                        raise ValueError(f'{register}: rossz visszaallitas '
                                         f'a(z) SP0{position:+d} helyrol')
                    restored.add(register)
            if post: sp += int(post, 0)
            lowest = min(lowest, sp)
            if sp % 16: raise ValueError('Nem 16 bajtos SP az utasitas utan')
            continue                                   # mentés/visszatöltés: nem törzsírás
        if (match := re.fullmatch(r'(add|sub)\s+sp,\s*sp,\s*#'+number, instruction)):
            amount = int(match[2],0); sp += amount if match[1]=='add' else -amount
            lowest = min(lowest, sp)
        elif mnemonic.startswith('b.') or mnemonic in NOWRITE:
            pass
        elif mnemonic in WRITE:
            if operands.startswith('{'):               # ld1 {v0.4s, v1.4s}, [...]
                dests = operands[1:operands.index('}')].split(',')
            elif mnemonic == 'ldp':
                dests = operands.split(',')[:2]
            else:
                dests = operands.split(',')[:1]
            for r in (canon(r) for r in dests):
                if r in restored:
                    raise ValueError(f'{r}: iras a visszaallitas utan')
                written.add(r)
        else:
            unsupported.add(mnemonic)
        if mnemonic in ('str', 'stp', 'st1', 'stur') and '[sp' in operands and not (
                pair.fullmatch(instruction) or single.fullmatch(instruction)):
            unsupported.add(mnemonic + ' [sp] (nem tamogatott alak)')
        if (wb := re.search(r'\[(\w+)(?:,[^\]]*)?\]!|\[(\w+)\],\s*#', instruction)):
            base = wb[1] or wb[2]                      # címzési visszaírás: a bázis is íródik
            if base != 'sp':
                if canon(base) in restored:
                    raise ValueError(f'{canon(base)}: iras a visszaallitas utan')
                written.add(canon(base))
        if sp % 16: raise ValueError('Nem 16 bajtos SP-igazitas')
    if sp or not returns: raise ValueError('Kiegyensulyozatlan verem vagy hianyzo RET')
    saved = set(slots.values())
    if not saved.issubset(restored): raise ValueError('Hianyzo regiszter-visszaallitas')
    if calls and 'x30' not in restored: raise ValueError('Beagyazott hivas LR-mentes nelkul')
    print('PASS: SP-egyensuly es 16 bajtos igazitas')
    print('PASS: mentett regiszterek es a visszatoltesi helyek egyeznek')
    print('PASS: LR-szerzodes ('+('mentett' if calls else 'level fuggveny')+')')
    if unsupported:
        print('SKIP: callee-saved megorzes (nem tamogatott utasitas: '
              + ', '.join(sorted(unsupported)) + ')')
    else:
        unsaved = sorted((written & CALLEE) - (saved & restored))
        if unsaved:
            raise ValueError('irt, de nem mentett/visszaallitott callee-saved regiszter: '
                             + ', '.join(unsaved))
        print('PASS: minden irt callee-saved regiszter mentve es visszaallitva ('
              + ', '.join(sorted(written & CALLEE)) + ')')
    if args.compare:
        digest_a = hashlib.sha256(args.image.read_bytes()).digest()
        digest_b = hashlib.sha256(args.compare.read_bytes()).digest()
        if digest_a != digest_b:
            raise ValueError('A ket explicit buildtermek elter')
        print('PASS: buildtermekek byte-azonosak')
    else:
        print('SKIP: build-reprodukálhatóság (nincs --compare fájl)')
except (OSError, ValueError, subprocess.CalledProcessError) as error:
    print('FAIL: '+str(error))
    raise SystemExit(1)
PY_AUDIT
