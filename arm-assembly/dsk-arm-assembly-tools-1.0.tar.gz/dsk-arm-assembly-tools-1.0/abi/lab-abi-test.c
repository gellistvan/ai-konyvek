/* lab-abi-test.c — az ABI-teszthívó önellenőrzése; cél: AArch64 Linux. */
#include <inttypes.h>
#include <stdio.h>
#include "lab-abi-call.h"

extern void lab_demo_good(void);
extern void lab_demo_bad_x19(void);
extern void lab_demo_bad_w20(void);
extern void lab_demo_bad_d8(void);
extern void lab_demo_bad_sp(void);
extern void lab_demo_bad_fp(void);
extern void lab_demo_bad_spfp(void);

/* Szerződéstartó C-hívott, amely maga is meghívja a teszthívót: a belső
 * hívásnak LAB_ABI_BUSY-t kell adnia (a horgony foglalt). */
static uint64_t lab_demo_reenter(void)
{
    uint64_t inner = 0;
    return lab_abi_call(lab_demo_good, 1, 2, 3, 0, 0, 0, &inner);
}

static int lab_expect(const char *name, lab_abi_fn fn,
                      uint64_t want_mask, uint64_t want_result)
{
    uint64_t result = 0;
    uint64_t mask = lab_abi_call(fn, 1, 2, 3, 0, 0, 0, &result);
    int ok = (mask == want_mask) && (result == want_result);

    printf("%-18s maszk=0x%05" PRIx64 " eredmeny=%" PRIu64 " %s\n",
           name, mask, result, ok ? "OK" : "HIBA");
    return ok;
}

int main(void)
{
    int ok = 1;

    ok &= lab_expect("lab_demo_good",    lab_demo_good,    0,             6);
    ok &= lab_expect("lab_demo_bad_x19", lab_demo_bad_x19, LAB_ABI_X19,   3);
    ok &= lab_expect("lab_demo_bad_w20", lab_demo_bad_w20, LAB_ABI_X19 << 1, 3);
    ok &= lab_expect("lab_demo_bad_d8",  lab_demo_bad_d8,  LAB_ABI_D8,    3);
    ok &= lab_expect("lab_demo_bad_sp",  lab_demo_bad_sp,  LAB_ABI_SP,    3);
    ok &= lab_expect("lab_demo_bad_fp",  lab_demo_bad_fp,  LAB_ABI_FP,    3);
    ok &= lab_expect("lab_demo_bad_spfp", lab_demo_bad_spfp, LAB_ABI_SP_FP, 3);
    ok &= lab_expect("lab_demo_reenter", (lab_abi_fn)lab_demo_reenter, 0, LAB_ABI_BUSY);
    ok &= lab_expect("lab_demo_good",    lab_demo_good,    0,             6);
    return ok ? 0 : 1;
}
