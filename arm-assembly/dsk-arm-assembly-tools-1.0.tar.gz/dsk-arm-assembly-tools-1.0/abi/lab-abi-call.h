/* lab-abi-call.h — közös AAPCS64 ABI-teszthívó; cél: AArch64 Linux, LP64. */
#ifndef LAB_ABI_CALL_H
#define LAB_ABI_CALL_H

#include <stdint.h>

/* Tetszőleges, legfeljebb hat egész/mutató argumentumú függvény címe.
 * A hívás az assemblyben történik, ezért a C oldalon csak a címet adjuk át. */
typedef void (*lab_abi_fn)(void);

/* A hibamaszk bitjei; 0 = a hívott betartotta a megőrzési szerződést. */
#define LAB_ABI_X19      (1u << 0)   /* bit 0..9: X19..X28 */
#define LAB_ABI_D8       (1u << 10)  /* bit 10..17: D8..D15 */
#define LAB_ABI_SP       (1u << 18)  /* SP nem a hívás előtti */
#define LAB_ABI_FP       (1u << 19)  /* X29 nem a hívás előtti */
#define LAB_ABI_SP_FP    (LAB_ABI_SP | LAB_ABI_FP)
#define LAB_ABI_BUSY     (1u << 20)  /* újrabelépés: fn nem hívódott meg */

/* Meghívja fn(a0, ..., a5)-öt úgy, hogy előtte X19–X28 és D8–D15 ismert,
 * magas biteket is tartalmazó mintát kap; visszatérés után ellenőrzi
 * a mintákat, valamint SP és X29 értékét. *result = a hívott X0-ja.
 *
 * NEM reentráns és nem szálbiztos: a hívás előtti keretcímet egyetlen
 * statikus horgony őrzi. Egymásba ágyazott hívásnál a belső hívás nem
 * hívja meg fn-t, LAB_ABI_BUSY-t ad vissza, *result = 0. */
uint64_t lab_abi_call(lab_abi_fn fn,
                      uint64_t a0, uint64_t a1, uint64_t a2,
                      uint64_t a3, uint64_t a4, uint64_t a5,
                      uint64_t *result);

#endif
