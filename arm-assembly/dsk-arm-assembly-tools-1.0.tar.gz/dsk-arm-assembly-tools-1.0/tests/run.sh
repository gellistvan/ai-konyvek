#!/bin/bash
# run.sh — a kísérőcsomag futtatható próbái, kizárólag a csomag fájljaiból, üres
# munkakönyvtárban. Két mód:
#   substitute  helyettesítő út: zig cc (Clang + ld.lld), tools/lab-run.py, tools/cm-run.py
#   gnu-qemu    a könyv fő útja: aarch64-linux-gnu-*, arm-none-eabi-*, qemu-aarch64,
#               qemu-system-arm -machine mps2-an385
# Használat (a csomag gyökeréből):  bash tests/run.sh substitute|gnu-qemu [napló]
# A napló alapértelmezésben: logs/<mód>-<dátum>.log. Kilépési kód: 0, ha nincs FAIL.
set -u
MODE=${1:-}
T=$(cd "$(dirname "$0")/.." && pwd)
case "$MODE" in substitute|gnu-qemu) ;; *) echo "használat: $0 substitute|gnu-qemu [napló]"; exit 64 ;; esac
LOG=${2:-$T/logs/$MODE-$(date +%Y%m%d-%H%M%S).log}
mkdir -p "$(dirname "$LOG")"
W=$(mktemp -d)
exec > >(tee "$LOG") 2>&1
PY=${PYTHON:-python3}
C=$T/cm-labs
CMFLAGS="-ffreestanding -nostdlib -O1"
fails=0 passes=0

if [ "$MODE" = substitute ]; then
    A64CC="$PY -m ziglang cc -target aarch64-linux-musl"
    CMCC="$PY -m ziglang cc -target thumb-freestanding-eabi -mcpu=cortex_m3 -fno-sanitize=undefined"
    a64run() { "$PY" "$T/lab-run.py" "$@"; }
    cmrun() { "$PY" "$T/cm-run.py" "$1" --max "${CM_MAX:-30000000}"; }       # 124 = limit
    printf '#!/bin/sh\nexec "%s" "%s" "$@"\n' "$PY" "$T/objdump-a64.py" > "$W/objdump"
    M19RUN="$PY $T/cm-run.py lab-m19.elf --uart-stdin --max 50000000000"
    M19FLAGS=--no-timing
else
    A64CC=aarch64-linux-gnu-gcc
    CMCC="arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb"
    a64run() { qemu-aarch64 "$@"; }
    cmrun() { timeout "${QEMU_TIMEOUT:-10}" qemu-system-arm -machine mps2-an385 -cpu cortex-m3 \
                  -nographic -semihosting -kernel "$1"; }                     # 124 = időkorlát
    printf '#!/bin/sh\nexec aarch64-linux-gnu-objdump "$@"\n' > "$W/objdump"
    M19RUN="qemu-system-arm -machine mps2-an385 -cpu cortex-m3 -display none -monitor none \
-serial stdio -kernel lab-m19.elf"
    M19FLAGS=
fi
chmod +x "$W/objdump"
OBJDUMP=$W/objdump
cmbuild() {  # $1 = kimenet, további: források; a linker script az első forrás könyvtárából
    local out=$1; shift
    $CMCC $CMFLAGS -T "$(dirname "$1")/lab-mps2.ld" -I"$(dirname "$1")" -o "$out" "$@"
}
export PY T C W A64CC CMCC CMFLAGS OBJDUMP
export -f a64run cmrun cmbuild

# check NÉV ELVÁRT_RC MINTA PARANCS   (a PARANCS egy bash-sor; a MINTA üres is lehet, grep -E)
check() {
    local name=$1 want=$2 pat=$3 cmd=$4
    local out=$W/out.txt
    bash -c "$cmd" > "$out" 2>&1 < /dev/null
    local rc=$? ok=1
    [ "$rc" = "$want" ] || ok=0
    [ -z "$pat" ] || grep -aEq "$pat" "$out" || ok=0
    if [ $ok = 1 ]; then passes=$((passes + 1)); echo "PASS  $name  [rc=$rc]"
    else fails=$((fails + 1)); echo "FAIL  $name  [rc=$rc, elvárt $want; minta: ${pat:-—}]"; fi
    grep -av 'argument unused\|entry symbol' "$out" | sed 's/^/        /' | tail -n "${SHOW:-4}"
}

echo "== Kísérőcsomag: $(cat "$T/VERSION")"
echo "== Mód: $MODE   dátum: $(date -Iseconds)   host: $(uname -srm)"
if (cd "$T" && sha256sum -c --quiet MANIFEST.sha256 > "$W/man.txt" 2>&1); then
    echo "== Manifest: OK ($(wc -l < "$T/MANIFEST.sha256") fájl)"
else
    echo "== Manifest: HIBA"; cat "$W/man.txt"; fails=$((fails + 1))
fi
echo "== Eszközök:"
"$PY" --version
"$PY" -c "import unicorn, capstone, elftools; print('unicorn', unicorn.__version__, \
'| capstone', capstone.__version__, '| pyelftools', elftools.__version__)" 2>&1
gcc --version | head -1
if [ "$MODE" = substitute ]; then
    echo "zig $("$PY" -m ziglang version)"
    "$PY" "$T/lab-run.py" --version | head -1
    "$PY" "$T/cm-run.py" --version | head -1
else
    aarch64-linux-gnu-gcc --version | head -1
    arm-none-eabi-gcc --version | head -1
    qemu-aarch64 --version | head -1
    qemu-system-arm --version | head -1
fi
echo
cd "$W" || exit 2

echo "== I. rész (AArch64)"
check "a029 ABI-teszthívó önellenőrzése" 0 'lab_demo_good +maszk=0x00000 ' \
    '$A64CC -std=c17 -O2 -static -I$T/abi $T/abi/lab-abi-test.c $T/abi/lab-abi-call.S \
     $T/abi/lab-abi-demo.S -o abi && a64run ./abi'
for v in seq stride; do
    check "a049 $v bejárás (kilépés 0 = az összeg N)" 0 '' \
        "\$A64CC -nostdlib -static -Wl,-e,_start -o $v \$T/a049/lab-$v-a049.s && a64run ./$v"
done
check "a049 lefedettségi próba (host gcc)" 0 'COVER: PASS' \
    'gcc -std=c11 -O2 -Wall -Wextra -o cover $T/a049/lab-cover-a049.c && ./cover'
a053() {  # $1 forrás, $2 másolási hossz (üres: a forrás alapértéke)
    $A64CC -nostdlib -static -Wl,-e,_start ${2:+-Wa,--defsym,COPY_LEN=$2} -o a053 "$1" && a64run ./a053
}
export -f a053
check "a053 alapdemó: 48 bájt, felülírt mentett LR (1 az elvárt)" 1 '' 'a053 $T/a053/lab-overflow.S'
for n in 0 32 33 40 48; do
    want=1; [ "$n" -le 32 ] && want=0
    check "a053 canary, $n bájtos prefix (elvárt állapot: $want)" $want '' \
        "a053 \$T/a053/lab-overflow-canary.S $n"
done
check "a053 canary-kontroll: guard-inicializálás nélkül (1 az elvárt)" 1 '' \
    'grep -v "str x6, \[sp, #32\]" $T/a053/lab-overflow-canary.S > m1.S && a053 m1.S 0'
check "a053 canary-kontroll: 64 bájtos SP-felszabadítás (2 az elvárt)" 2 '' \
    'sed "s/    add sp, sp, #80/    add sp, sp, #64/" $T/a053/lab-overflow-canary.S > m2.S && a053 m2.S 0'
check "a053 canary-kontroll: X29 = SP + 32 (2 az elvárt)" 2 '' \
    'sed "s/    add x29, sp, #48/    add x29, sp, #32/" $T/a053/lab-overflow-canary.S > m3.S && a053 m3.S 0'
for p in none standard; do
    check "a055 -mbranch-protection=$p" 0 'lab_sink: 10 bajt: "labor a055"' \
        "\$A64CC -O2 -fno-stack-protector -mbranch-protection=$p -c -o v.o \$T/a055/lab-a055-vuln.c \
         && \$A64CC -O2 -c -o m.o \$T/a055/lab-a055-main.c && \$A64CC -static -o a055 v.o m.o \
         && a64run ./a055"
done
SHOW=3 check "a059 lab_sgemm tesztkészlet" 0 'TESTS: PASS' \
    'export LAB_RUN_MAX=20000000000; $A64CC -O2 -c $T/zaro1/lab_sgemm.S -o lab_sgemm.o \
     && $A64CC -std=gnu17 -O2 -static -I$T/zaro1 $T/zaro1/lab_sgemm_test.c \
        $T/zaro1/lab_sgemm_check.c $T/zaro1/lab_sgemm_ref.c lab_sgemm.o -lm -o sgemm_test \
     && a64run ./sgemm_test'
check "a060 statikus audit, helyes lab_sgemm" 0 'PASS: minden irt callee-saved' \
    'bash $T/a060/lab-audit.sh lab_sgemm.o --objdump $OBJDUMP'
for m in mov_x21 fmov_d8 w21 postidx noldp; do
    check "a060 audit, mutáns $m (FAIL az elvárt)" 1 '^FAIL' \
        "\$A64CC -c \$T/a060/mutants/$m.s -o $m.o && bash \$T/a060/lab-audit.sh $m.o --objdump \$OBJDUMP"
done
check "a060 audit, mutáns sgemm_nosave_x27_x28 (FAIL az elvárt)" 1 'x27, x28' \
    '$A64CC -c $T/a060/mutants/sgemm_nosave_x27_x28.S -o nos.o \
     && bash $T/a060/lab-audit.sh nos.o --objdump $OBJDUMP'
check "a060 audit, nem támogatott utasítás (SKIP az elvárt)" 0 'SKIP: callee-saved' \
    '$A64CC -c $T/a060/mutants/ismeretlen.s -o isme.o \
     && bash $T/a060/lab-audit.sh isme.o --objdump $OBJDUMP'
check "a060 3. feladat: hibás farokciklus (TAIL: FAIL az elvárt)" 1 'n=11 \(n mod 4 = 3\) HIBA' \
    '$A64CC -O2 -static -o tail $T/zaro1/lab-a060-tail-test.c $T/zaro1/lab-a060-tail.s && a64run ./tail'
check "a061 lab_sum_u32, A64" 0 'SUMTEST: PASS' \
    '$A64CC -O1 -static -I$T/abi -o suma64 $T/pair/lab-sum-test.c $T/pair/lab-sum-a64.s \
     $T/abi/lab-abi-call.S && a64run ./suma64'
echo

echo "== II. rész (Cortex-M3)"
check "a061 lab_sum_u32, Thumb-2" 0 'SUMTEST: PASS' \
    'cmbuild t32.elf $C/canon/lab-startup.s $T/pair/lab-sum-t32.s $T/pair/lab-abi-call32.s \
     $T/pair/lab-sum-test.c -I$T/pair && cmrun t32.elf'
check "a061 lab_abi_call32 negatív teszt" 0 'ABI32-NEG: PASS' \
    'cmbuild neg.elf $C/canon/lab-startup.s $T/pair/lab-abi32-neg-test.c $T/pair/lab-abi32-neg.s \
     $T/pair/lab-abi-call32.s -I$T/pair && cmrun neg.elf'
lab() {  # $1 név, $2 ELF, $3 vektorfeltételek, $4 elvárt rc, $5 minta, további: források
    local name=$1 elf=$2 vecs=$3 want=$4 pat=$5; shift 5
    check "$name: build + vektortábla" 0 '' \
        "cmbuild $elf $* && \$PY \$C/canon/lab-check-vectors.py $elf $vecs"
    check "$name: futás" "$want" "$pat" "cmrun $elf"
}
lab "a070 Timer0 IRQ8 (boot, hibátlan futás a korlátig)" a070.elf \
    "1=Reset_Handler 24=TIMER0_IRQHandler" 124 '' $C/a070/lab-a070-startup.s $C/a070/lab-a070_isr.c
lab "a071 latenciapróba" a071.elf "1=Reset_Handler 22=lab_irq_isr" 0 'LATENCY: (PASS|SKIP)' \
    $C/a071/lab-a071-startup.s $C/a071/lab-a071-latency.c
lab "a071 kontrollált SysTick-preempció" a071s.elf \
    "1=Reset_Handler 15=SysTick_Handler 22=lab_irq_isr" 0 'PREEMPT: PASS' \
    $C/a071/lab-a071-startup.s $C/a071/lab-a071-systick.c
check "a071 SysTick-mutáns: IRQ6 magasabb prioritással (FAIL az elvárt)" 1 'a SysTick vége előtt' \
    'mkdir -p mut && cp $C/a071/lab-mps2.ld $C/a071/lab-a071-startup.s mut/ \
     && sed "s/(0x80u << 16)/(0x00u << 16)/" $C/a071/lab-a071-systick.c > mut/mut-prio.c \
     && cmbuild mut.elf mut/lab-a071-startup.s mut/mut-prio.c && cmrun mut.elf'
lab "a077 Timer0 megszakításos tick" a077i.elf "1=Reset_Handler 24=TIMER0_IRQHandler" 124 '^tick' \
    $C/a077/lab-a077-startup.s $C/a077/lab-a077-irq.c $C/a077/lab-a077-common.c
lab "a077 busy-wait tick" a077b.elf "1=Reset_Handler 24=Default_Handler" 124 '^tick' \
    $C/a077/lab-a077-startup.s $C/a077/lab-a077-busywait.c $C/a077/lab-a077-common.c
check "a076 UART driver: build + vektortábla" 0 '' \
    'cmbuild uart.elf $C/a076/lab-a076-startup.s $C/a076/lab-uart.c $C/a076/lab-main.c \
     && $PY $C/canon/lab-check-vectors.py uart.elf 1=Reset_Handler 16=UART0_Handler'
if [ "$MODE" = substitute ]; then
    UARTRUN='printf hello | $PY $T/cm-run.py uart.elf --uart-stdin --max 3000000'
else
    UARTRUN='(sleep 2; printf hello; sleep 2) | timeout 8 qemu-system-arm -machine mps2-an385 \
        -cpu cortex-m3 -display none -monitor none -serial stdio -kernel uart.elf'
fi
check "a076 UART driver: UART ready + echo" 0 'UART ready' \
    "$UARTRUN > uart.txt; cat uart.txt; grep -aq hello uart.txt"
echo

echo "== Záróprojekt II (lab-m19)"
mkdir -p m19 && cp "$T"/lab-m19/*.[chS] "$T"/lab-m19/*.ld "$T"/lab-m19/*.py "$T"/lab-m19/Makefile m19/
cd m19 || exit 2
check "a080 ringteszt (host gcc)" 0 'RINGTEST: PASS' 'make -s ringtest'
if [ "$MODE" = substitute ]; then
    check "a079 lab-m19 build" 0 '' '$CMCC -ffreestanding -nostdlib -O1 -T lab-m19.ld -o lab-m19.elf \
        lab-m19-startup.S lab-m19-drivers.c lab-m19-ring.c lab-m19-isr.c lab-m19-main.c'
else
    check "a079 lab-m19 build (make)" 0 '' 'make -s lab-m19.elf'
fi
SHOW=13 check "a080 rendszerteszt (boot, echo, burst, tick, reset, K5)" 0 'SYSTEST: PASS' \
    "\$PY lab-m19-systest.py $M19FLAGS --runner \"$M19RUN\""
SHOW=3 check "a080 K4 3 s hostkéséssel a reset után (PASS az elvárt)" 0 'PASS  K4 reset' \
    "\$PY lab-m19-systest.py $M19FLAGS --reset-delay 3 --runner \"$M19RUN\""
for m in extra swap drop noreset fast m-bad; do
    SHOW=1 check "a080 rendszerteszt-ellenpróba, protokoll-DUT '$m' (FAIL az elvárt)" 1 'SYSTEST: FAIL' \
        "\$PY lab-m19-systest.py --runner \"\$PY \$T/lab-m19/fake-dut.py $m\""
done
SHOW=1 check "a080 rendszerteszt, protokoll-DUT 'ok'" 0 'SYSTEST: PASS' \
    '$PY lab-m19-systest.py --runner "$PY $T/lab-m19/fake-dut.py ok"'
cd "$W" || exit 2
check "a080 2. megoldás: measure_line statisztika (host gcc)" 0 'random mean-ellenőrzés: 0 eltérés' \
    'gcc -std=c11 -O2 -Wall -Wextra -o stats $T/lab-m19/feladat2/measure-line-host-test.c && ./stats'
echo

echo "ÖSSZESEN: $passes PASS, $fails FAIL ($MODE; napló: ${LOG#"$T"/})"
rm -rf "$W"
[ "$fails" = 0 ]
