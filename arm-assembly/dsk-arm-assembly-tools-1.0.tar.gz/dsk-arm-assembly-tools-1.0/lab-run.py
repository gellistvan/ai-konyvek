#!/usr/bin/env python3
"""Minimal AArch64 Linux user-mode runner on top of Unicorn (static ELF only).

Usage: lab-run.py program.elf [args...]  -> guest stdout/stderr, exit code = guest status
Instruction limit: 200 million (exit 124); override with the LAB_RUN_MAX environment variable.
"""
import os
import struct
import sys

from elftools.elf.elffile import ELFFile
from unicorn import Uc, UcError, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_INTR, UC_PROT_ALL
from unicorn.arm64_const import *

VERSION = 'lab-run 1.1 (2026-10-19): AArch64 Linux user-mode, statikus ELF, Unicorn, LAB_RUN_MAX'

PAGE = 0x1000
STACK_TOP = 0x7FFF_0000_0000
STACK_SIZE = 8 * 1024 * 1024
MMAP_BASE = 0x7000_0000_0000


def align_up(x, a=PAGE):
    return (x + a - 1) & ~(a - 1)


class Runner:
    def __init__(self, path, argv):
        self.uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
        self.mapped = []
        self.exit_code = None
        with open(path, 'rb') as f:
            elf = ELFFile(f)
            if elf['e_machine'] != 'EM_AARCH64':
                raise SystemExit('not an AArch64 ELF')
            self.entry = elf['e_entry']
            phdrs = [s for s in elf.iter_segments()]
            self.phoff = elf['e_phoff']
            self.phnum = elf['e_phnum']
            self.phent = elf['e_phentsize']
            self.phdr_addr = None
            hi = 0
            for seg in phdrs:
                if seg['p_type'] != 'PT_LOAD':
                    continue
                start = seg['p_vaddr'] & ~(PAGE - 1)
                end = align_up(seg['p_vaddr'] + seg['p_memsz'])
                self.map(start, end - start)
                self.uc.mem_write(seg['p_vaddr'], seg.data())
                if seg['p_offset'] <= self.phoff < seg['p_offset'] + seg['p_filesz']:
                    self.phdr_addr = seg['p_vaddr'] + (self.phoff - seg['p_offset'])
                hi = max(hi, end)
            self.brk = self.brk_start = align_up(hi)
            self.map(self.brk, 64 * PAGE)
            self.brk_mapped = self.brk + 64 * PAGE
        self.mmap_next = MMAP_BASE
        self.map(STACK_TOP - STACK_SIZE, STACK_SIZE)
        self.sp = self.build_stack([path] + argv)
        # Enable FP/SIMD at EL0/EL1.
        self.uc.reg_write(UC_ARM64_REG_CPACR_EL1, 3 << 20)
        self.uc.hook_add(UC_HOOK_INTR, self.on_intr)

    def map(self, addr, size):
        for a in range(addr, addr + size, PAGE):
            if a in self.mapped_set():
                continue
            self.uc.mem_map(a, PAGE, UC_PROT_ALL)
            self.mapped.append(a)

    def mapped_set(self):
        if not hasattr(self, '_ms') or len(self._ms) != len(self.mapped):
            self._ms = set(self.mapped)
        return self._ms

    def build_stack(self, args):
        sp = STACK_TOP - 0x1000
        strs = []
        for a in args:
            b = a.encode() + b'\0'
            sp -= len(b)
            self.uc.mem_write(sp, b)
            strs.append(sp)
        sp -= 16
        rnd = sp
        self.uc.mem_write(rnd, bytes(range(16)))
        sp &= ~0xF
        auxv = [(3, self.phdr_addr or 0), (4, self.phent), (5, self.phnum), (6, PAGE),
                (9, self.entry), (11, 1000), (12, 1000), (13, 1000), (14, 1000),
                (23, 0), (25, rnd), (0, 0)]
        words = [len(args)] + strs + [0] + [0]  # argc, argv..., NULL, envp NULL
        for k, v in auxv:
            words += [k, v]
        sp -= 8 * len(words)
        sp &= ~0xF
        self.uc.mem_write(sp, b''.join(struct.pack('<Q', w) for w in words))
        return sp

    def rd(self, addr, n):
        return bytes(self.uc.mem_read(addr, n))

    def on_intr(self, uc, intno, _):
        if intno != 2:  # EXCP_SWI
            pc = uc.reg_read(UC_ARM64_REG_PC)
            sys.stderr.write(f'lab-run: unhandled exception {intno} at pc=0x{pc:x}\n')
            self.exit_code = 139
            uc.emu_stop()
            return
        nr = uc.reg_read(UC_ARM64_REG_X8)
        a = [uc.reg_read(getattr(sys.modules['unicorn.arm64_const'], f'UC_ARM64_REG_X{i}')) for i in range(6)]
        ret = self.syscall(nr, a)
        if ret is not None:
            uc.reg_write(UC_ARM64_REG_X0, ret & 0xFFFF_FFFF_FFFF_FFFF)

    def syscall(self, nr, a):
        if nr == 64:  # write
            data = self.rd(a[1], a[2])
            (sys.stdout if a[0] == 1 else sys.stderr).buffer.write(data)
            (sys.stdout if a[0] == 1 else sys.stderr).flush()
            return len(data)
        if nr == 66:  # writev
            total = 0
            for i in range(a[2]):
                base, ln = struct.unpack('<QQ', self.rd(a[1] + 16 * i, 16))
                data = self.rd(base, ln)
                (sys.stdout if a[0] == 1 else sys.stderr).buffer.write(data)
                total += ln
            sys.stdout.flush(); sys.stderr.flush()
            return total
        if nr in (93, 94):  # exit, exit_group
            self.exit_code = a[0] & 0xFF
            self.uc.emu_stop()
            return None
        if nr == 214:  # brk
            if a[0] == 0 or a[0] < self.brk_start:
                return self.brk
            new = a[0]
            if new > self.brk_mapped:
                self.map(self.brk_mapped, align_up(new) - self.brk_mapped)
                self.brk_mapped = align_up(new)
            self.brk = new
            return self.brk
        if nr == 222:  # mmap (anonymous only)
            size = align_up(a[1])
            addr = self.mmap_next
            self.map(addr, size)
            self.mmap_next += size + PAGE
            return addr
        if nr == 226:  # mprotect: page protections are enforced (guard pages fault)
            start = a[0] & ~(PAGE - 1)
            end = align_up(a[0] + a[1])
            try:
                self.uc.mem_protect(start, end - start, a[2] & 7)
            except UcError:
                return -12  # ENOMEM: range not mapped
            return 0
        if nr in (215, 135, 134, 96, 99, 233):  # munmap sigprocmask sigaction set_tid_address set_robust_list madvise
            return 0 if nr != 96 else 1
        if nr == 29:  # ioctl
            return -25  # ENOTTY: stdout is not a terminal
        if nr in (172, 178):
            return 1
        if nr == 160:  # uname
            buf = b''.join(s.ljust(65, b'\0') for s in [b'Linux', b'lab', b'6.8.0', b'#1', b'aarch64', b''])
            self.uc.mem_write(a[0], buf)
            return 0
        if nr == 56:  # openat
            path = self.rd(a[1], 256).split(b'\0')[0].decode()
            try:
                import os
                fd = os.open(path, a[2] & 0o3 | (os.O_CREAT if a[2] & 0o100 else 0) | (os.O_TRUNC if a[2] & 0o1000 else 0), a[3] or 0o644)
                return fd
            except OSError as e:
                return -e.errno
        if nr == 63:  # read
            import os
            try:
                data = os.read(a[0], a[2])
            except OSError as e:
                return -e.errno
            self.uc.mem_write(a[1], data)
            return len(data)
        if nr == 57:  # close
            import os
            if a[0] > 2:
                try:
                    os.close(a[0])
                except OSError as e:
                    return -e.errno
            return 0
        if nr == 113:  # clock_gettime
            import time
            t = time.monotonic_ns() if a[0] == 1 else time.time_ns()
            self.uc.mem_write(a[1], struct.pack('<qq', t // 10**9, t % 10**9))
            return 0
        if nr == 278:  # getrandom
            self.uc.mem_write(a[0], bytes(a[1]))
            return a[1]
        sys.stderr.write(f'lab-run: unsupported syscall {nr}\n')
        return -38  # ENOSYS

    def run(self):
        self.uc.reg_write(UC_ARM64_REG_SP, self.sp)
        try:
            self.uc.emu_start(self.entry, 0xFFFF_FFFF_FFFF_FFFF, count=int(os.environ.get('LAB_RUN_MAX', 200_000_000)))
        except UcError as e:
            pc = self.uc.reg_read(UC_ARM64_REG_PC)
            sys.stderr.write(f'lab-run: {e} at pc=0x{pc:x} (SIGSEGV)\n')
            return 139
        if self.exit_code is None:
            sys.stderr.write('lab-run: instruction limit reached (timeout)\n')
            return 124
        return self.exit_code


if __name__ == '__main__':
    if sys.argv[1:2] == ['--version']:
        print(VERSION)
        print(__doc__)
        sys.exit(0)
    r = Runner(sys.argv[1], sys.argv[2:])
    sys.exit(r.run())
